-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 08-Ago-2022 às 19:42
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `adevirp`
--
CREATE DATABASE IF NOT EXISTS `adevirp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `adevirp`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE `agenda` (
  `agenda_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL,
  `educando_id` int(11) NOT NULL,
  `agenda_titulo` varchar(50) NOT NULL,
  `agenda_dia` varchar(20) NOT NULL,
  `agenda_aula` int(11) NOT NULL,
  `agenda_inc_data` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`agenda_id`, `professor_id`, `educando_id`, `agenda_titulo`, `agenda_dia`, `agenda_aula`, `agenda_inc_data`) VALUES
(5, 9, 1, '', 'segunda-feira', 7, 1655111600),
(7, 9, 12, '', 'quinta-feira', 8, 1641092400),
(18, 9, 15, '', 'segunda-feira', 1, 1652519600),
(19, 9, 11, '', 'segunda-feira', 2, 1655863600),
(21, 9, 4, '', 'segunda-feira', 4, 1652519600),
(37, 10, 5, '', 'segunda-feira', 2, 1659753150),
(38, 10, 3, '', 'segunda-feira', 1, 1659753281),
(39, 10, 13, '', 'terca-feira', 3, 1658905267),
(40, 10, 6, '', 'terca-feira', 4, 1636696986),
(41, 10, 3, '', 'segunda-feira', 3, 1633460507),
(42, 10, 11, '', 'quarta-feira', 1, 1636859904),
(43, 10, 12, '', 'terca-feira', 2, 1658576660),
(44, 10, 14, '', 'quinta-feira', 8, 1657910637),
(45, 10, 15, '', 'quinta-feira', 1, 1646873114),
(46, 10, 1, '', 'quinta-feira', 2, 1642721788),
(47, 10, 15, '', 'quarta-feira', 3, 1651312218),
(48, 10, 15, '', 'quinta-feira', 3, 1646386208),
(49, 10, 11, '', 'quarta-feira', 4, 1635810205),
(50, 10, 4, '', 'quarta-feira', 5, 1657790129),
(51, 10, 5, '', 'quarta-feira', 6, 1643852952),
(52, 10, 1, '', 'quinta-feira', 4, 1658000273),
(53, 10, 15, '', 'terca-feira', 5, 1640369127),
(54, 10, 11, '', 'quinta-feira', 2, 1652407458);

-- --------------------------------------------------------

--
-- Estrutura da tabela `biblioteca_autor`
--

CREATE TABLE `biblioteca_autor` (
  `biblioteca_autor_id` int(11) NOT NULL,
  `biblioteca_autor_nome` varchar(100) NOT NULL,
  `biblioteca_autor_slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `biblioteca_categoria`
--

CREATE TABLE `biblioteca_categoria` (
  `biblioteca_categoria_id` int(11) NOT NULL,
  `biblioteca_categoria_nome` varchar(30) NOT NULL,
  `biblioteca_categoria_slug` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `biblioteca_livro`
--

CREATE TABLE `biblioteca_livro` (
  `biblioteca_livro_id` int(11) NOT NULL,
  `biblioteca_livro_capa` varchar(50) NOT NULL,
  `biblioteca_livro_titulo` varchar(100) NOT NULL,
  `biblioteca_livro_slug` varchar(100) NOT NULL,
  `biblioteca_livro_sinopse` text NOT NULL,
  `biblioteca_livro_arquivo` varchar(50) NOT NULL,
  `biblioteca_autor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `impressao`
--

CREATE TABLE `impressao` (
  `impressao_id` int(11) NOT NULL,
  `impressao_arquivo` varchar(50) NOT NULL,
  `impressao_descricao` text NOT NULL,
  `impressao_ampliada` tinyint(1) NOT NULL,
  `impressao_braille` tinyint(1) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `impressao_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `impressao`
--

INSERT INTO `impressao` (`impressao_id`, `impressao_arquivo`, `impressao_descricao`, `impressao_ampliada`, `impressao_braille`, `usuario_id`, `impressao_status`) VALUES
(1, 'Apostilha informática.docx', '', 1, 0, 2, 0),
(2, 'Apostilha informática.docx', '', 1, 0, 10, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro_categoria`
--

CREATE TABLE `livro_categoria` (
  `id` int(11) NOT NULL,
  `biblioteca_livro_id` int(11) NOT NULL,
  `biblioteca_categoria_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_token`
--

CREATE TABLE `login_token` (
  `token_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `login_token`
--

INSERT INTO `login_token` (`token_id`, `usuario_id`, `token`) VALUES
(11, 9, 'ad62f0904f2ecce');

-- --------------------------------------------------------

--
-- Estrutura da tabela `projeto`
--

CREATE TABLE `projeto` (
  `projeto_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `projeto_nome` varchar(30) NOT NULL,
  `projeto_descricao` text NOT NULL,
  `projeto_data` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `projeto`
--

INSERT INTO `projeto` (`projeto_id`, `usuario_id`, `projeto_nome`, `projeto_descricao`, `projeto_data`) VALUES
(2, 9, 'Apostila de Informática', 'Apostila de informática.', '26/07/2022');

-- --------------------------------------------------------

--
-- Estrutura da tabela `relatorio`
--

CREATE TABLE `relatorio` (
  `relatorio_id` int(11) NOT NULL,
  `relatorio_descricao` text NOT NULL,
  `relatorio_presenca` tinyint(1) NOT NULL,
  `relatorio_atendimento_data` int(11) NOT NULL,
  `relatorio_data` int(20) NOT NULL,
  `educando_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `relatorio`
--

INSERT INTO `relatorio` (`relatorio_id`, `relatorio_descricao`, `relatorio_presenca`, `relatorio_atendimento_data`, `relatorio_data`, `educando_id`, `professor_id`) VALUES
(4, 'Aula de soroban', 1, 20220201, 7, 15, 10),
(9, 'sklAJSKLSJL\r\n', 1, 20220101, 7, 15, 10),
(28, 'ldçajdkalkj', 1, 1655089200, 1659933831, 1, 9),
(30, '', 0, 1656298800, 1659934110, 1, 9);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo`
--

CREATE TABLE `tipo` (
  `tipo_id` int(11) NOT NULL,
  `tipo_nome` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipo`
--

INSERT INTO `tipo` (`tipo_id`, `tipo_nome`) VALUES
(1, 'Administrador'),
(2, 'Coordenador'),
(3, 'Professor'),
(4, 'Técnico'),
(5, 'Educando'),
(6, 'Voluntário');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL,
  `usuario_nome` varchar(20) NOT NULL,
  `usuario_sobrenome` varchar(20) NOT NULL,
  `usuario_email` varchar(50) NOT NULL,
  `usuario_celular` varchar(20) NOT NULL,
  `usuario_genero` varchar(10) NOT NULL,
  `usuario_visao` varchar(10) NOT NULL,
  `tipo_id` int(11) NOT NULL,
  `usuario_apelido` varchar(30) NOT NULL,
  `usuario_senha` varchar(60) NOT NULL,
  `usuario_slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `usuario_nome`, `usuario_sobrenome`, `usuario_email`, `usuario_celular`, `usuario_genero`, `usuario_visao`, `tipo_id`, `usuario_apelido`, `usuario_senha`, `usuario_slug`) VALUES
(1, 'Eduardo', 'Zagato', 'duzagatto@hotmail.com', '16988708149', 'Masculino', 'Baixa', 5, 'eduardozagato', '$2y$10$3bFVey1oLDq8S9LXY7DekOyB0NXM0R./pOeh37sYJfdxr.7PLHKLm', 'eduardo-zagato'),
(2, 'Administração', 'Adevirp', 'admin@adevirp.com', '1639131900', 'Masculino', 'Normal', 1, 'admin', '$2y$10$IsNgj1QOQVQxq0wnvElmye8OIykiRd/T96TQFSPN/h57wg1xL.tiy', 'administracao-adevirp'),
(3, 'Max', 'Verstappen', 'max@gmail.com', '16998381938', 'Masculino', 'Cego', 5, 'maxverstappen', '$2y$10$ZNQm87P9VVemlE4i4qCSI.aoAUxgF50TCJgsfMImUb36O77cc6qDy', 'max-verstappen'),
(4, 'Rogério', 'Ceni', 'rc@gmail.com', '16998389429', 'Masculino', 'Baixa', 5, 'rogerioceni', '$2y$10$hbOSv1ce43DmeHohgVeCWuE09q/nIyBEiBrTQTZNtEXR4ScoQ6Oku', 'rogerio-ceni'),
(5, 'Ayn', 'Rand', 'ayn@gmail.com', '15986838291', 'Feminino', 'Cego', 5, 'aynrand', '$2y$10$GAO.1MoAEdgZFsRD2gB6Gu3BXIohXXQx0gloQjIhmb0QR23zkHuIq', 'ayn-rand'),
(6, 'Joanne', 'Kathleen Rowling', 'jkrowling@gmail.com', '1699110022', 'Feminino', 'Cego', 5, 'jkrowling', '$2y$10$akvzN1tfTecmUYGO3t/JueTB5DSjEDEZkw3gd/nOZwadgc4ms0kHS', 'joanne-kathleen-rowling'),
(7, 'Jane', 'Austen', 'jane@gmail.com', '1999221100', 'Feminino', 'Normal', 6, 'jane', '$2y$10$EkNQcc7CfZ2RndW0Uak3IuxHT4kR1ZhKTSLWsKEujEPySZ4.lPkYi', 'jane-austen'),
(8, 'Magnus', 'Carlsen', 'magnus@gmail.com', '1699112200', 'Masculino', 'Baixa', 5, 'magnuscarlsen', '$2y$10$7wMjYObRHbhCpKeP01eaGOPeur1M2Rzv3a4rrUvxUiTEoGBmykHAK', 'magnus-carlsen'),
(9, 'João', 'Pedro', 'joaopedro@gmail.com', '1699221003', 'Masculino', 'Normal', 3, 'joaopedro', '$2y$10$S2jz5.ApfZGq9dznQmG6iOFw6z0RH3wTA6A6h/69taML5AHFtfLly', 'joao-pedro'),
(10, 'Guilherme', 'Sandrin', 'guilherme.sandrin@gmail.com', '1999221100', 'Masculino', 'Cego', 3, 'guilhermesandrin', '$2y$10$Zcpr028hfEM5tr9hCCJzC.8SJMr/r6h9lQ1JeYvjv88GSPhKVbTta', 'guilherme-sandrin'),
(11, 'Tess', 'Gerritsen', 'tess@gmail.com', '16988102929', 'Feminino', 'Cego', 5, 'tess', '$2y$10$8ZgHm7doEufnHMzYhdjfY.EkeNKRcS.zJ0GmIWy0mEIfWUT5bhqUm', 'tess-gerritsen'),
(12, 'Noel', 'Gallagher', 'noel@gmail.com', '16988102929', 'Masculino', 'Baixa', 5, 'noel', '$2y$10$SGUlvoT4ioCmxj6PN0lQVusClijqbFSR3t45El/JMk/BnanX8Y43q', 'noel-gallagher'),
(13, 'Jonathan', 'Calleri', 'jonathan@gmail.com', '1699110022', 'Masculino', 'Baixa', 5, 'calleri', '$2y$10$jlSVh2XRirMJ7w2lhE419eLD0n8kemwCDxS0m6m5RF0zvyGqo80Vq', 'jonathan-calleri'),
(14, 'Hermione', 'Granger', 'hermione@gmail.com', '1699110022', 'Feminino', 'Cego', 5, 'hermione', '$2y$10$P4FCqw/KydH1gmFRIEwCK.ak7hSjP.iIbu5YAE9Nkss0sluB89OLG', 'hermione-granger'),
(15, 'Kobe', 'Bryant', 'kobe@gmail.com', '16988102929', 'Masculino', 'Baixa', 5, 'kobe', '$2y$10$YRKnhV2YvAKLNT3nDLOmp.DUorfTF7EUEaVZ/EqiidTSkooE3QyCi', 'kobe-bryant'),
(16, 'Ludwig', 'Von Mises', 'ludwig@gmail.com', '16988102929', 'Masculino', 'Normal', 3, 'mises', '$2y$10$nHTx5et08JtjTbjaUdeIPu256kORIBU4nbvgU2ObYw92JoSR9ZK7G', 'ludwig-von-mises'),
(17, 'Edward', 'Snowden', 'edward@gmail.com', '16988102929', 'Masculino', 'Normal', 2, 'snowden', '$2y$10$lVKJhqv/4K.CKAoxWuNErO/MK0V6lnkSbrurY9qOCQZYgc8reaeOC', 'edward-snowden'),
(18, 'Axl', 'Rose', 'axl@gmail.com', '16988102929', 'Masculino', 'Baixa', 6, 'axl', '$2y$10$v61qt4jbPTHyxcLLuV2FzuZ5O919of2X1EZnNlAoV9bkK..lyQnvG', 'axl-rose');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`agenda_id`),
  ADD KEY `user_id` (`professor_id`),
  ADD KEY `agenda_ibfk_1` (`educando_id`);

--
-- Índices para tabela `biblioteca_autor`
--
ALTER TABLE `biblioteca_autor`
  ADD PRIMARY KEY (`biblioteca_autor_id`);

--
-- Índices para tabela `biblioteca_categoria`
--
ALTER TABLE `biblioteca_categoria`
  ADD PRIMARY KEY (`biblioteca_categoria_id`);

--
-- Índices para tabela `biblioteca_livro`
--
ALTER TABLE `biblioteca_livro`
  ADD PRIMARY KEY (`biblioteca_livro_id`),
  ADD KEY `biblioteca_autor_id` (`biblioteca_autor_id`);

--
-- Índices para tabela `impressao`
--
ALTER TABLE `impressao`
  ADD PRIMARY KEY (`impressao_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices para tabela `livro_categoria`
--
ALTER TABLE `livro_categoria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `biblioteca_categoria_id` (`biblioteca_categoria_id`),
  ADD KEY `biblioteca_livro_id` (`biblioteca_livro_id`);

--
-- Índices para tabela `login_token`
--
ALTER TABLE `login_token`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`usuario_id`);

--
-- Índices para tabela `projeto`
--
ALTER TABLE `projeto`
  ADD PRIMARY KEY (`projeto_id`);

--
-- Índices para tabela `relatorio`
--
ALTER TABLE `relatorio`
  ADD PRIMARY KEY (`relatorio_id`);

--
-- Índices para tabela `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`tipo_id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agenda`
--
ALTER TABLE `agenda`
  MODIFY `agenda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de tabela `biblioteca_autor`
--
ALTER TABLE `biblioteca_autor`
  MODIFY `biblioteca_autor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `biblioteca_categoria`
--
ALTER TABLE `biblioteca_categoria`
  MODIFY `biblioteca_categoria_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `biblioteca_livro`
--
ALTER TABLE `biblioteca_livro`
  MODIFY `biblioteca_livro_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `impressao`
--
ALTER TABLE `impressao`
  MODIFY `impressao_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `livro_categoria`
--
ALTER TABLE `livro_categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `login_token`
--
ALTER TABLE `login_token`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `projeto`
--
ALTER TABLE `projeto`
  MODIFY `projeto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `relatorio`
--
ALTER TABLE `relatorio`
  MODIFY `relatorio_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `tipo`
--
ALTER TABLE `tipo`
  MODIFY `tipo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `biblioteca_livro`
--
ALTER TABLE `biblioteca_livro`
  ADD CONSTRAINT `biblioteca_livro_ibfk_1` FOREIGN KEY (`biblioteca_autor_id`) REFERENCES `biblioteca_autor` (`biblioteca_autor_id`);

--
-- Limitadores para a tabela `livro_categoria`
--
ALTER TABLE `livro_categoria`
  ADD CONSTRAINT `livro_categoria_ibfk_1` FOREIGN KEY (`biblioteca_categoria_id`) REFERENCES `biblioteca_categoria` (`biblioteca_categoria_id`),
  ADD CONSTRAINT `livro_categoria_ibfk_2` FOREIGN KEY (`biblioteca_livro_id`) REFERENCES `biblioteca_livro` (`biblioteca_livro_id`);
--
-- Banco de dados: `admin`
--
CREATE DATABASE IF NOT EXISTS `admin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `admin`;
--
-- Banco de dados: `college`
--
CREATE DATABASE IF NOT EXISTS `college` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `college`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `class_result`
--

CREATE TABLE `class_result` (
  `class_result_id` int(11) NOT NULL,
  `roll_no` varchar(30) NOT NULL,
  `course_code` varchar(30) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `semester` varchar(11) NOT NULL,
  `total_marks` varchar(11) NOT NULL,
  `obtain_marks` varchar(11) NOT NULL,
  `result_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `class_result`
--

INSERT INTO `class_result` (`class_result_id`, `roll_no`, `course_code`, `subject_code`, `semester`, `total_marks`, `obtain_marks`, `result_date`) VALUES
(1, 'MCS-S19-1', 'MCS', 'OOP', '2', '100', '98', '10-03-20'),
(2, '25', 'MCS', 'OOP', '2', '100', '93', '10-03-20'),
(3, '27', 'MCS', 'OOP', '2', '100', '92', '10-03-20'),
(4, '29', 'MCS', 'OOP', '2', '100', '98', '10-03-20'),
(5, '31', 'MCS', 'OOP', '2', '100', '96', '10-03-20'),
(6, '33', 'MCS', 'OOP', '2', '100', '97', '10-03-20'),
(7, '34', 'MCS', 'OOP', '2', '100', '94', '10-03-20'),
(8, '35', 'MCS', 'OOP', '2', '100', '91', '10-03-20'),
(9, '36', 'MCS', 'OOP', '2', '100', '90', '10-03-20'),
(10, 'MCS-S19-1', 'MCS', 'DBMS', '2', '100', '98', '10-03-20'),
(11, '25', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(12, '27', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(13, '29', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(14, '31', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(15, '33', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(16, 'MCS-S19-1', 'MCS', 'SE', '2', '100', '64', '10-03-20'),
(17, '35', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(18, '36', 'MIT', 'ITP', '2', '100', '98', '10-03-20'),
(28, 'MCS-S19-1', 'MCS', 'DLD', '2', '100', '76', '29-03-20'),
(35, '', '', '', '', '', '', '29-03-20'),
(36, '', '', '', '', '', '', '29-03-20'),
(37, 'MCS-S19-1', 'MCS', 'SE', '2', '100', '80', '30-03-20'),
(38, '', '', '', '', '', '', '30-03-20'),
(39, '', '', '', '', '', '', '30-03-20'),
(40, '', '', '', '', '', '', '30-03-20'),
(41, '', '', '', '', '', '', '30-03-20'),
(42, '', '', '', '', '', '', '30-03-20'),
(43, '', '', '', '', '', '', '30-03-20'),
(44, '', '', '', '', '', '', '30-03-20'),
(45, '', '', '', '', '', '', '30-03-20'),
(46, 'MCS-S19-1', 'MCS', 'SE', '2', '100', '80', '30-03-20'),
(47, '', '', '', '', '', '', '30-03-20'),
(48, '', '', '', '', '', '', '30-03-20'),
(49, '', '', '', '', '', '', '30-03-20'),
(50, '', '', '', '', '', '', '30-03-20'),
(51, '', '', '', '', '', '', '30-03-20'),
(52, '', '', '', '', '', '', '30-03-20'),
(53, '', '', '', '', '', '', '30-03-20'),
(54, '', '', '', '', '', '', '30-03-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `semester_or_year` varchar(10) NOT NULL,
  `no_of_year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `courses`
--

INSERT INTO `courses` (`course_code`, `course_name`, `semester_or_year`, `no_of_year`) VALUES
('AHL', 'Allied Health Science', 'Semester', 4),
('B.Arch', 'Bachular in Architecture', 'Semester', 5),
('B.Fashion', 'Bachular in Fashion and Design', 'Semester', 4),
('BBA', 'Bachular in Business Administration', 'Semester', 2),
('BSAI', 'Bachular in Artificial Inteligence', 'Semester', 2),
('BSEE', 'Bachular in Electrical Engineering', 'Semester', 4),
('M.Arch', 'Masters in Architecture', 'Semester', 2),
('M.Com', 'Master in Commerce', 'Semester', 2),
('MCS', 'Master in Computer Science', 'Semester', 2),
('MIT', 'Master in Information Technology', 'Semester', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `course_subjects`
--

CREATE TABLE `course_subjects` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(10) NOT NULL,
  `credit_hours` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `course_subjects`
--

INSERT INTO `course_subjects` (`subject_code`, `subject_name`, `course_code`, `semester`, `credit_hours`) VALUES
('CSPD', 'Communication Skills and Personality Development', 'MCS', 1, 3),
('DBMS', 'Database Management System', 'MCS', 2, 4),
('DLD', 'Data Logic and Design', 'MCS', 2, 3),
('Ds', 'Discrete Structure', 'MCS', 1, 3),
('I2C', 'Introduction to Computer Science', 'MCS', 1, 4),
('ITP', 'IT Project Management System', 'MIT', 2, 3),
('MBAD', 'Mobile Application Development', 'MIT', 2, 4),
('OOP', 'Object Oriented Programming', 'MCS', 2, 4),
('PF', 'Programming Fundamental', 'BSAI', 1, 4),
('SE', 'Software Engineering', 'MCS', 2, 3),
('WEB', 'Web Development', 'MCS', 2, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `account` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`ID`, `user_id`, `Password`, `Role`, `account`) VALUES
(2, 'admin@gmail.com', 'admin123*', 'Admin', ''),
(5, 'staff1@gmail.com', 'teacher123*', 'Teacher', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mytable`
--

CREATE TABLE `mytable` (
  `id` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `course_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mytable`
--

INSERT INTO `mytable` (`id`, `name`, `course_code`) VALUES
('B.Fashion-S19-1', 'husnain', 'B.Fashion'),
('B.Fashion-S19-2', 'razarai663@gmail.com', 'B.Fashion'),
('MCS-S19-1', 'Muhammad Husnain Raza', 'MCS'),
('MCS-S19-2', 'razarai663@gmail.com', 'MCS'),
('MIT-S19-1', 'Muhammad Husnain Raza', 'MIT');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sessions`
--

CREATE TABLE `sessions` (
  `session_id` int(11) NOT NULL,
  `session` varchar(30) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sessions`
--

INSERT INTO `sessions` (`session_id`, `session`, `created_date`) VALUES
(1, 'S19', '2020-03-11 20:20:44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `student_attendance`
--

CREATE TABLE `student_attendance` (
  `attendance_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `attendance` int(11) NOT NULL,
  `attendance_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `student_attendance`
--

INSERT INTO `student_attendance` (`attendance_id`, `course_code`, `subject_code`, `semester`, `student_id`, `attendance`, `attendance_date`) VALUES
(1, 'MCS', 'DBMS', 2, 'MCS-S19-1', 1, '15-03-20'),
(2, 'MCS', 'DBMS', 2, 'MCS-S19-1', 1, '15-03-20'),
(3, 'MCS', 'DBMS', 2, 'MCS-S19-1', 1, '15-03-20'),
(4, 'MCS', 'DBMS', 2, 'MCS-S19-1', 0, '15-03-20'),
(5, 'MCS', 'DLD', 2, 'MCS-S19-1', 1, '15-03-20'),
(6, 'MCS', 'OOP', 2, 'MCS-S19-1', 1, '15-03-20'),
(7, 'MCS', 'SE', 2, 'MCS-S19-1', 0, '15-03-20'),
(8, 'MCS', 'WEB', 2, 'MCS-S19-1', 1, '15-03-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `student_courses`
--

CREATE TABLE `student_courses` (
  `student_course_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `roll_no` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `session` varchar(10) NOT NULL,
  `assign_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `student_courses`
--

INSERT INTO `student_courses` (`student_course_id`, `course_code`, `semester`, `roll_no`, `subject_code`, `session`, `assign_date`) VALUES
(1, 'MCS', 2, 'MCS-S19-1', 'OOP', 'S19', '15-03-20'),
(2, 'MCS', 2, 'MCS-S19-1', 'DBMS', 'S19', '15-03-20'),
(3, 'MCS', 2, 'MCS-S19-1', 'DLD', 'S19', '15-03-20'),
(4, 'MCS', 2, 'MCS-S19-1', 'SE', 'S19', '15-03-20'),
(5, 'MCS', 2, 'MCS-S19-1', 'WEB', 'S19', '15-03-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `student_fee`
--

CREATE TABLE `student_fee` (
  `fee_voucher` int(11) NOT NULL,
  `roll_no` varchar(30) NOT NULL,
  `amount` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `student_fee`
--

INSERT INTO `student_fee` (`fee_voucher`, `roll_no`, `amount`, `posting_date`, `status`) VALUES
(1, 'MCS-S19-1', 23455, '2020-03-29 11:24:36', 'Paid'),
(2, 'MCS-S19-1', 20093, '2020-03-30 12:35:39', 'Paid');

-- --------------------------------------------------------

--
-- Estrutura da tabela `student_info`
--

CREATE TABLE `student_info` (
  `roll_no` varchar(20) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `course_code` varchar(11) NOT NULL,
  `session` varchar(10) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `prospectus_issued` varchar(10) NOT NULL,
  `prospectus_amount` varchar(10) NOT NULL,
  `form_b` varchar(20) NOT NULL,
  `applicant_status` varchar(20) NOT NULL,
  `application_status` varchar(20) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `other_phone` varchar(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `permanent_address` varchar(150) NOT NULL,
  `current_address` varchar(150) NOT NULL,
  `place_of_birth` varchar(150) NOT NULL,
  `matric_complition_date` varchar(10) NOT NULL,
  `matric_awarded_date` varchar(10) NOT NULL,
  `matric_certificate` varchar(100) NOT NULL,
  `fa_complition_date` varchar(10) NOT NULL,
  `fa_awarded_date` varchar(10) NOT NULL,
  `fa_certificate` varchar(100) NOT NULL,
  `ba_complition_date` varchar(10) NOT NULL,
  `ba_awarded_date` varchar(10) NOT NULL,
  `ba_certificate` varchar(100) NOT NULL,
  `semester` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `obtain_marks` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `admission_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `teacher_attendance`
--

CREATE TABLE `teacher_attendance` (
  `attendance_id` int(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `attendance` int(11) NOT NULL,
  `attendance_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `teacher_attendance`
--

INSERT INTO `teacher_attendance` (`attendance_id`, `teacher_id`, `attendance`, `attendance_date`) VALUES
(1, '3', 1, '09-03-20'),
(2, '3', 1, '10-03-20'),
(3, '3', 1, '11-04-20'),
(4, '3', 1, '30-03-20'),
(5, '2', 0, '30-03-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `teacher_courses`
--

CREATE TABLE `teacher_courses` (
  `teacher_courses_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `teacher_id` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `assign_date` varchar(10) NOT NULL,
  `total_classes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `teacher_courses`
--

INSERT INTO `teacher_courses` (`teacher_courses_id`, `course_code`, `semester`, `teacher_id`, `subject_code`, `assign_date`, `total_classes`) VALUES
(1, 'MCS', 2, '3', 'OOP', '27-03-20', 30),
(2, 'MCS', 2, '1', 'DBMS', '27-03-20', 30),
(3, 'MCS', 2, '3', 'DLD', '27-03-20', 30),
(4, 'MCS', 2, '1', 'SE', '27-03-20', 30),
(5, 'MCS', 2, '3', 'WEB', '27-03-20', 30);

-- --------------------------------------------------------

--
-- Estrutura da tabela `teacher_info`
--

CREATE TABLE `teacher_info` (
  `teacher_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_no` varchar(11) NOT NULL,
  `profile_image` blob NOT NULL,
  `teacher_status` varchar(10) NOT NULL,
  `application_status` varchar(10) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `other_phone` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `permanent_address` varchar(100) NOT NULL,
  `current_address` varchar(100) NOT NULL,
  `place_of_birth` varchar(50) NOT NULL,
  `matric_complition_date` varchar(10) NOT NULL,
  `matric_awarded_date` varchar(10) NOT NULL,
  `matric_certificate` varchar(100) NOT NULL,
  `fa_complition_date` varchar(10) NOT NULL,
  `fa_awarded_date` varchar(10) NOT NULL,
  `fa_certificate` varchar(100) NOT NULL,
  `ba_complition_date` varchar(10) NOT NULL,
  `ba_awarded_date` varchar(10) NOT NULL,
  `ba_certificate` varchar(100) NOT NULL,
  `ma_complition_date` varchar(10) NOT NULL,
  `ma_awarded_date` varchar(100) NOT NULL,
  `ma_certificate` varchar(101) NOT NULL,
  `last_qualification` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `hire_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `teacher_info`
--

INSERT INTO `teacher_info` (`teacher_id`, `first_name`, `middle_name`, `last_name`, `father_name`, `email`, `phone_no`, `profile_image`, `teacher_status`, `application_status`, `cnic`, `dob`, `other_phone`, `gender`, `permanent_address`, `current_address`, `place_of_birth`, `matric_complition_date`, `matric_awarded_date`, `matric_certificate`, `fa_complition_date`, `fa_awarded_date`, `fa_certificate`, `ba_complition_date`, `ba_awarded_date`, `ba_certificate`, `ma_complition_date`, `ma_awarded_date`, `ma_certificate`, `last_qualification`, `state`, `hire_date`) VALUES
(2, 'Teacher', '1', '1', '', 'staff1@gmail.com', '9807367624', 0x696d616765732e706e67, 'Permanent', 'Yes', '8793', '1987-01-17', 0, 'Male', 'abc', 'def', 'ghij', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '18-06-21');

-- --------------------------------------------------------

--
-- Estrutura da tabela `teacher_salary_allowances`
--

CREATE TABLE `teacher_salary_allowances` (
  `teacher_id` int(11) NOT NULL,
  `basic_salary` int(11) NOT NULL,
  `medical_allowance` int(11) NOT NULL,
  `hr_allowance` int(11) NOT NULL,
  `scale` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `teacher_salary_allowances`
--

INSERT INTO `teacher_salary_allowances` (`teacher_id`, `basic_salary`, `medical_allowance`, `hr_allowance`, `scale`) VALUES
(1, 40000, 5, 10, 15),
(2, 55000, 7, 15, 18),
(3, 43000, 5, 8, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `teacher_salary_report`
--

CREATE TABLE `teacher_salary_report` (
  `salary_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `paid_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `teacher_salary_report`
--

INSERT INTO `teacher_salary_report` (`salary_id`, `teacher_id`, `total_amount`, `status`, `paid_date`) VALUES
(1, 1, 46000, 'Paid', '2020-03-27 11:28:57'),
(2, 2, 67100, 'Paid', '2020-03-27 11:50:13'),
(3, 3, 48590, 'Paid', '2020-03-27 11:55:58'),
(4, 1, 46000, 'Paid', '2020-03-27 12:33:39'),
(5, 3, 48590, 'Paid', '2020-03-28 08:26:59'),
(6, 2, 67100, 'Paid', '2020-03-28 08:30:46'),
(7, 2, 67100, 'Paid', '2020-03-28 08:32:06'),
(8, 2, 67100, 'Paid', '2020-03-28 08:32:46'),
(9, 2, 67100, 'Paid', '2020-03-28 08:33:59'),
(10, 2, 67100, 'Paid', '2020-03-28 08:35:54'),
(11, 2, 67100, 'Paid', '2020-03-28 08:38:17'),
(12, 2, 67100, 'Paid', '2020-03-28 08:39:22'),
(13, 2, 67100, 'Paid', '2020-03-28 08:40:44'),
(14, 2, 67100, 'Paid', '2020-03-28 08:41:26'),
(15, 2, 67100, 'Paid', '2020-03-28 08:42:25'),
(16, 2, 67100, 'Paid', '2020-03-28 08:43:32'),
(17, 2, 67100, 'Paid', '2020-03-28 08:44:03'),
(18, 2, 67100, 'Paid', '2020-03-28 08:44:39'),
(19, 2, 67100, 'Paid', '2020-03-28 08:45:09'),
(20, 2, 67100, 'Paid', '2020-03-28 08:45:22'),
(21, 2, 67100, 'Paid', '2020-03-28 08:45:36'),
(22, 2, 67100, 'Paid', '2020-03-28 08:45:45'),
(23, 2, 67100, 'Paid', '2020-03-28 08:45:59'),
(24, 2, 67100, 'Paid', '2020-03-28 08:47:42'),
(25, 2, 67100, 'Paid', '2020-03-28 08:48:11'),
(26, 3, 48590, 'Paid', '2020-03-28 08:48:22'),
(27, 3, 48590, 'Paid', '2020-03-28 08:48:40'),
(28, 3, 48590, 'Paid', '2020-03-28 10:48:28'),
(29, 3, 48590, 'Paid', '2020-03-28 10:49:47'),
(30, 3, 48590, 'Paid', '2020-03-30 12:37:11');

-- --------------------------------------------------------

--
-- Estrutura da tabela `time_table`
--

CREATE TABLE `time_table` (
  `id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `timing_from` varchar(10) NOT NULL,
  `timing_to` varchar(10) NOT NULL,
  `day` varchar(20) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `room_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `time_table`
--

INSERT INTO `time_table` (`id`, `course_code`, `semester`, `timing_from`, `timing_to`, `day`, `subject_code`, `room_no`) VALUES
(1, 'MCS', 2, '18:00', '21:00', '1', 'OOP', 21),
(2, 'MCS', 2, '18:00', '21:00', '2', 'DBMS', 21),
(3, 'MCS', 2, '18:00', '21:00', '3', 'DLD', 7),
(4, 'MCS', 2, '18:00', '21:00', '4', 'SE', 21),
(5, 'MCS', 2, '18:00', '21:00', '5', 'WEB', 21),
(6, 'MIT', 2, '18:00', '21:00', '4', 'MBAD', 12);

-- --------------------------------------------------------

--
-- Estrutura da tabela `weekdays`
--

CREATE TABLE `weekdays` (
  `day_id` int(11) NOT NULL,
  `day_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `weekdays`
--

INSERT INTO `weekdays` (`day_id`, `day_name`) VALUES
(1, 'Monday'),
(2, 'Tuesday'),
(3, 'Wednesday'),
(4, 'Thursday'),
(5, 'Friday'),
(6, 'Saturday'),
(7, 'Sunday');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `class_result`
--
ALTER TABLE `class_result`
  ADD PRIMARY KEY (`class_result_id`);

--
-- Índices para tabela `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Índices para tabela `course_subjects`
--
ALTER TABLE `course_subjects`
  ADD PRIMARY KEY (`subject_code`);

--
-- Índices para tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Índices para tabela `mytable`
--
ALTER TABLE `mytable`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Índices para tabela `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Índices para tabela `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`student_course_id`),
  ADD KEY `course_code` (`course_code`);

--
-- Índices para tabela `student_fee`
--
ALTER TABLE `student_fee`
  ADD PRIMARY KEY (`fee_voucher`),
  ADD KEY `roll_no` (`roll_no`);

--
-- Índices para tabela `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`roll_no`);

--
-- Índices para tabela `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Índices para tabela `teacher_courses`
--
ALTER TABLE `teacher_courses`
  ADD PRIMARY KEY (`teacher_courses_id`);

--
-- Índices para tabela `teacher_info`
--
ALTER TABLE `teacher_info`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Índices para tabela `teacher_salary_allowances`
--
ALTER TABLE `teacher_salary_allowances`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Índices para tabela `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  ADD PRIMARY KEY (`salary_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Índices para tabela `time_table`
--
ALTER TABLE `time_table`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `weekdays`
--
ALTER TABLE `weekdays`
  ADD PRIMARY KEY (`day_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `class_result`
--
ALTER TABLE `class_result`
  MODIFY `class_result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `sessions`
--
ALTER TABLE `sessions`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `student_courses`
--
ALTER TABLE `student_courses`
  MODIFY `student_course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `student_fee`
--
ALTER TABLE `student_fee`
  MODIFY `fee_voucher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `teacher_courses`
--
ALTER TABLE `teacher_courses`
  MODIFY `teacher_courses_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `teacher_info`
--
ALTER TABLE `teacher_info`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  MODIFY `salary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `time_table`
--
ALTER TABLE `time_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `weekdays`
--
ALTER TABLE `weekdays`
  MODIFY `day_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  ADD CONSTRAINT `teacher_salary_report_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher_salary_allowances` (`teacher_id`);
--
-- Banco de dados: `eglub`
--
CREATE DATABASE IF NOT EXISTS `eglub` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci;
USE `eglub`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_tokens`
--

CREATE TABLE `login_tokens` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `token` char(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `login_tokens`
--

INSERT INTO `login_tokens` (`id`, `id_user`, `token`) VALUES
(5, 14, 'baf711b0c4f5de5b08191b98bbeb1500ab901643'),
(10, 14, '75a3bcf26d7be8597af21c2e7b67e5558ecf6551'),
(11, 14, '167870b9cfe4536dd912e50d4da7ec218950cb89'),
(12, 14, 'fc6d14f06c2ccd3483a4e0c34ab9b19981788881'),
(13, 14, 'e6ad7c27dc1a3a448d81e94cc8aca6cb79e26b49'),
(14, 14, '3c8fcab46615aab55f6d4687e0daaa57635c5110'),
(15, 14, 'd52741bb21e1b3ac18e2d36ff85b925b435998ed'),
(16, 14, '9248283b709a1ccb21638ae3f84c1a97ac754c04'),
(17, 14, '747d137d8a88766ef1045bab87c6d3ff46158715'),
(18, 14, 'c65dfb195cf06ff14fbac335538b82f33d4f71b6'),
(19, 14, 'f7d2e1bfe69611945e9917fa62a1b05b2e265019'),
(20, 14, '0932b80a934215dbc665281f28dad426790e3f98');

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment_systems`
--

CREATE TABLE `payment_systems` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `months_interval` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `schools`
--

CREATE TABLE `schools` (
  `id` int(11) NOT NULL,
  `id_owner` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `profile_image` varchar(40) NOT NULL,
  `cover_image` varchar(40) NOT NULL,
  `presentation_video` varchar(40) NOT NULL,
  `sale_system` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `schools`
--

INSERT INTO `schools` (`id`, `id_owner`, `name`, `slug`, `description`, `profile_image`, `cover_image`, `presentation_video`, `sale_system`, `date`) VALUES
(1, 14, 'final fantasy', 'final-fantasy', 'kdlsajdaldjadjklaldjk', '569545c52be5a56c7457022b57c64572.jpg', 'e743242ae695804552b8a79b6dfe760e.png', '6510352878e9422377b0cf59da688eed.mp4', 1, '2020-09-12 08:48:44'),
(3, 14, 'Slkjasdlkadj', 'Lkajdlkasjdlasdja', '4b2323bb8b68a8a657c113c2b80cdd1b.png', '', '', '1', 0, '2020-09-12 15:30:23'),
(5, 14, 'Academia Rafael Leitão', 'Aprenda xadrez com o melhor jo', 'c1c81d5d51a47c2e1594dc5791732daa.jpg', '3bafed95d6ab382a4e0e4564df4eee1a.jpg', '2f30379820bd5b82cca7ea096001dce4.mp4', '3', 0, '2020-09-12 15:36:04'),
(6, 14, 'Academia Rafael Leitão', 'Aprenda xadrez com o melhor jo', '46a390e4de9e46a1e54881172c90117b.jpg', '0c382817b09fa6b6916773501c5525e0.jpg', '8dc2eb2879813d135c853321eba1f1d8.mp4', '3', 0, '2020-09-12 15:36:35'),
(7, 14, 'Academia Rafael Leitão', 'Aprenda xadrez com o melhor jo', 'd8fb35fafa4b9503e8e4dfcc904d772a.jpg', '4bec75d7acb46ee4b6b77eae01151116.jpg', '6c6aca1f6fea6cea05aac2fb335160ac.mp4', '3', 0, '2020-09-12 15:38:09'),
(8, 14, 'Academia Rafael Leitão', 'çkdasdkd', 'fff096a9cec9eb095e7ad4c682535240.jpg', '', '', '1', 0, '2020-09-12 15:39:33'),
(9, 14, 'Academia Rafael Leitão', 'çkdasdkd', '9a3c3c9ca0f7c4cfc85c97d1ceb0bcf8.jpg', '', '', '1', 0, '2020-09-12 15:40:18'),
(10, 14, 'Academia Rafael Leitão', 'çkdasdkd', 'cb2675aafe78f0c58da496e0ed604d8c.jpg', '', '', '1', 0, '2020-09-12 15:40:45'),
(11, 14, 'Academia Rafael Leitão', 'Lkjkljl', 'abc3bbd403b241f4f9f6e41794fbd419.jpg', '', '', '1', 0, '2020-09-12 15:43:27'),
(12, 14, 'Academia Rafael Leitão', 'Lkjkljl', '3c37f8ff9ae8c193336c8665826bc1a5.jpg', '', '', '1', 0, '2020-09-12 15:43:38'),
(13, 14, 'DevTips', 'Aprenda desenvolvimento WEB.', 'f9e02f5bec02e29770057b9eb6dae33e.jpg', '152f5f25c07a06f21082124af9749414.png', 'a1293388473e254580e16bda9763c5d0.mp4', '2', 0, '2020-09-17 15:29:06'),
(15, 14, 'Ciência Todo Dia', 'ciencia-todo-dia', 'Cursos de física, química, astronomia e outras ciências naturais.', '4d009616d3cde6f4c4428f7f45e435b9.png', '024d88826b332eb3c208030451ba4dff.jpg', '', 3, '2020-09-17 15:43:42'),
(16, 14, 'Só História', 'so-historia', 'Aulas e cursos de história para você.', '20c4fef36d94b1c007a404065209b806.jpg', '16db7e0512f5eaff735f56df85b92e0e.jpg', '', 2, '2020-09-17 16:08:13'),
(17, 14, 'Só Ciência', 'so-ciencia', 'Aulas e cursos de ciência para você.', '82134b9488cdef0825f0960d40794370.jpg', '02a425ad296cd7cf1a7fe9c80d0b3b5f.jpg', '', 2, '2020-09-17 16:09:22'),
(18, 14, 'Saia da Matrix', 'saia-da-matrix', 'Cursos de Marxismo e esquerdismo', '4980145c8b53e63f41fa46b459cc6941.jpg', '', '', 1, '2020-09-17 16:09:54'),
(19, 14, 'Academia Eduardo Zagato Junior', 'academia-eduardo-zagato-junior', 'Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '11ce0273f1a9a8fee2e29f0b56b14813.png', '9ea748e1f4b9dbfde35dba5b711c2a38.jpg', '', 1, '2020-09-18 10:09:06'),
(20, 14, 'Academia Eduardo Junior', 'academia-eduardo-junior', 'Aprenda tudo aqui', '53d6d96071a7aa9d3fe3f66bfa3bd514.png', '', '', 2, '2020-09-18 10:16:39'),
(21, 14, 'Academia Eduardo', 'academia-eduardo', 'Aprenda tudo aqui', '207e2a6f6c3e8d28e5d8740d762a98d4.png', '', '', 2, '2020-09-18 10:17:45'),
(22, 14, 'Aprenda tudo', 'aprenda-tudo', 'Aprenda tudo aqui', '38003d601751d99b74912043b5e6699b.jpg', 'c4c3f597fbc8b1174798bf1a3ea33cb4.png', '', 1, '2020-09-18 10:18:16'),
(23, 14, 'Metaforando', 'metaforando', 'Aprenda a analisar expressões faciais e descobrir se a pessoa está mentindo ou não.', 'f783ba6d4af10ca88ded8dba2a1ebe4a.jpg', '1fa5f263f47aff7f92689bb630577adf.jpg', '', 3, '2020-09-18 10:20:05'),
(24, 14, 'Ler antes de morrer', 'ler-antes-de-morrer', 'Aprenda literatura com a menina mais linda do mundo.', '275a7d0ec2ee7f3e71e5544021388545.jpg', '', '', 2, '2020-09-18 10:25:36');

-- --------------------------------------------------------

--
-- Estrutura da tabela `schools_follows`
--

CREATE TABLE `schools_follows` (
  `id` int(11) NOT NULL,
  `id_school` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `schools_plans`
--

CREATE TABLE `schools_plans` (
  `id` int(11) NOT NULL,
  `id_school` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `schools_students`
--

CREATE TABLE `schools_students` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `schools_values`
--

CREATE TABLE `schools_values` (
  `id` int(11) NOT NULL,
  `id_school` int(11) NOT NULL,
  `value` float NOT NULL,
  `sale` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_profile_image` int(11) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `user_confirm` int(11) NOT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `id_profile_image`, `first_name`, `last_name`, `username`, `email`, `password`, `user_confirm`, `date`) VALUES
(14, 0, '', '', '', 'du.zagatto@hotmail.com', '$2y$10$/A16GDd2GwqDATigoJ7VO.6SzjA8nWZGvI.1r8eAVrndVLKuJDno6', 1, '2020-09-06 04:39:35'),
(15, 0, '', '', '', 'edu@hotmail.com', '$2y$10$fpefMPWM5ICfEsZvzpGn8O789l7TlN3Rd7TP88mTj2ppItsoBbca.', 0, '2020-09-06 06:12:29'),
(16, 0, '', '', '', 'eduardo@hotmail.com', '$2y$10$2Gspk7KyNLlG9WnZMhjfUuuP5mydE.nW86MpYqkhKR9sr1xD3iFJi', 1, '2020-09-06 06:21:49'),
(17, 0, '', '', '', 'duzagatto@hotmail.com', '$2y$10$jrExF4adEhPxF9GeVydff.kTUHT1e9NzXxVWJmaknBEF..8Lm27eK', 1, '2020-09-06 06:49:27'),
(18, 0, '', '', '', 'rosangela@hotmail.com', '$2y$10$U8Qgru46T7rM41gTSJIQ3OSS3eujvxl5.TFueeqxAfshzKc7UZSzO', 1, '2020-09-06 07:04:48');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_activation`
--

CREATE TABLE `users_activation` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `token` char(4) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users_activation`
--

INSERT INTO `users_activation` (`id`, `id_user`, `token`, `date`) VALUES
(9, 15, 'd5b7', '2020-09-06 06:12:29');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `login_tokens`
--
ALTER TABLE `login_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `payment_systems`
--
ALTER TABLE `payment_systems`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_owner` (`id_owner`),
  ADD KEY `payment_system` (`sale_system`);

--
-- Índices para tabela `schools_follows`
--
ALTER TABLE `schools_follows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_school` (`id_school`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `schools_plans`
--
ALTER TABLE `schools_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_school` (`id_school`);

--
-- Índices para tabela `schools_students`
--
ALTER TABLE `schools_students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_school` (`id_school`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `schools_values`
--
ALTER TABLE `schools_values`
  ADD KEY `id_school` (`id_school`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_activation`
--
ALTER TABLE `users_activation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `login_tokens`
--
ALTER TABLE `login_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `payment_systems`
--
ALTER TABLE `payment_systems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `schools_follows`
--
ALTER TABLE `schools_follows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `schools_plans`
--
ALTER TABLE `schools_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `schools_students`
--
ALTER TABLE `schools_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `users_activation`
--
ALTER TABLE `users_activation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `login_tokens`
--
ALTER TABLE `login_tokens`
  ADD CONSTRAINT `login_tokens_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `schools`
--
ALTER TABLE `schools`
  ADD CONSTRAINT `schools_ibfk_1` FOREIGN KEY (`id_owner`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `schools_follows`
--
ALTER TABLE `schools_follows`
  ADD CONSTRAINT `schools_follows_ibfk_1` FOREIGN KEY (`id_school`) REFERENCES `schools` (`id`),
  ADD CONSTRAINT `schools_follows_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `schools_plans`
--
ALTER TABLE `schools_plans`
  ADD CONSTRAINT `schools_plans_ibfk_1` FOREIGN KEY (`id_school`) REFERENCES `schools` (`id`);

--
-- Limitadores para a tabela `schools_students`
--
ALTER TABLE `schools_students`
  ADD CONSTRAINT `schools_students_ibfk_1` FOREIGN KEY (`id_school`) REFERENCES `schools` (`id`),
  ADD CONSTRAINT `schools_students_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `schools_values`
--
ALTER TABLE `schools_values`
  ADD CONSTRAINT `schools_values_ibfk_1` FOREIGN KEY (`id_school`) REFERENCES `schools` (`id`);

--
-- Limitadores para a tabela `users_activation`
--
ALTER TABLE `users_activation`
  ADD CONSTRAINT `users_activation_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);
--
-- Banco de dados: `employee`
--
CREATE DATABASE IF NOT EXISTS `employee` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `employee`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `empeducation`
--

CREATE TABLE `empeducation` (
  `Id` int(11) NOT NULL,
  `EmpID` int(10) DEFAULT NULL,
  `CoursePG` varchar(45) DEFAULT NULL,
  `SchoolCollegePG` varchar(45) DEFAULT NULL,
  `YearPassingPG` varchar(45) DEFAULT NULL,
  `PercentagePG` varchar(4) DEFAULT NULL,
  `CourseGra` varchar(45) DEFAULT NULL,
  `SchoolCollegeGra` varchar(45) DEFAULT NULL,
  `YearPassingGra` varchar(45) DEFAULT NULL,
  `PercentageGra` varchar(4) DEFAULT NULL,
  `CourseSSC` varchar(45) DEFAULT NULL,
  `SchoolCollegeSSC` varchar(45) DEFAULT NULL,
  `YearPassingSSC` varchar(45) DEFAULT NULL,
  `PercentageSSC` varchar(4) DEFAULT NULL,
  `CourseHSC` varchar(45) DEFAULT NULL,
  `SchoolCollegeHSC` varchar(45) DEFAULT NULL,
  `YearPassingHSC` varchar(45) DEFAULT NULL,
  `PercentageHSC` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `empeducation`
--

INSERT INTO `empeducation` (`Id`, `EmpID`, `CoursePG`, `SchoolCollegePG`, `YearPassingPG`, `PercentagePG`, `CourseGra`, `SchoolCollegeGra`, `YearPassingGra`, `PercentageGra`, `CourseSSC`, `SchoolCollegeSSC`, `YearPassingSSC`, `PercentageSSC`, `CourseHSC`, `SchoolCollegeHSC`, `YearPassingHSC`, `PercentageHSC`) VALUES
(1, 4, 'NA', 'NA', 'NA', 'NA', 'B.Tech(IT)', 'LPU', '2014', '86%', 'Science', 'ABC Senoir secondary School', '2010', '64%', 'Science', 'abcd', '2008', '98%'),
(2, 2, 'abc', 'ghf', '2016', '89%', 'B.Tech(IT)', 'LPU', '2013', '86%', 'Science', 'DPS Senoir secondary School', '2009', '64%', 'Science', 'DPS Senoir secondary School', '2008', '90%'),
(3, 3, 'Master in charted accountant', 'Bhavi CA college', '2004', '89%', 'Bachelor in charted accountant', 'Bhavi CA college', '1996', '95%', 'Science', 'graimia convent school', '1993', '75%', 'Science', 'graimia convent school', '1991', '89%'),
(4, 7, 'MCA', 'KITE Ghaziabad', '1990', '64 %', 'BCA', 'TVN', '1997', '68 %', 'Science', 'TVN', '1992', '76 %', 'Science', 'TVN', '2010', '89 %'),
(5, 12, 'NA', 'NA', 'NA', 'NA', 'B.Tech', 'VIT', '1996', '75%', 'Science', 'GHI convent school', '1993', '66%', 'Science', 'GHI convent school', '1990', '65%'),
(6, 13, 'MBA', 'SMU', '2018', '70', 'B.Tech', 'LPU', '2015', '80', 'PCM', 'Test', '2010', '74', 'PCM', 'ABC', '2008', '85');

-- --------------------------------------------------------

--
-- Estrutura da tabela `empexpireince`
--

CREATE TABLE `empexpireince` (
  `ID` int(11) NOT NULL,
  `EmpID` varchar(5) DEFAULT NULL,
  `Employer1Name` varchar(75) DEFAULT NULL,
  `Employer1Designation` varchar(50) DEFAULT NULL,
  `Employer1CTC` varchar(50) DEFAULT NULL,
  `Employer1WorkDuration` varchar(11) DEFAULT NULL,
  `Employer2Name` varchar(75) DEFAULT NULL,
  `Employer2Designation` varchar(50) DEFAULT NULL,
  `Employer2CTC` varchar(50) DEFAULT NULL,
  `Employer2WorkDuration` varchar(11) DEFAULT NULL,
  `Employer3Name` varchar(75) DEFAULT NULL,
  `Employer3Designation` varchar(50) DEFAULT NULL,
  `Employer3CTC` varchar(50) DEFAULT NULL,
  `Employer3WorkDuration` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `empexpireince`
--

INSERT INTO `empexpireince` (`ID`, `EmpID`, `Employer1Name`, `Employer1Designation`, `Employer1CTC`, `Employer1WorkDuration`, `Employer2Name`, `Employer2Designation`, `Employer2CTC`, `Employer2WorkDuration`, `Employer3Name`, `Employer3Designation`, `Employer3CTC`, `Employer3WorkDuration`) VALUES
(2, '4', 'abc.pvt.td', 'software tester', '20,000 p/m', '4 yrs', 'tch.pvt.td', 'software tester', '32000 p/m', '4 yrs', 'dfg.pvt.td', 'SR.software tester', '45000 p/m', '7 yrs'),
(7, '2', 'SAR pvt.ltd', 'Software Developer', '25000 p/m', '3 yrs', 'abc enterprise', 'software developer', '30000 p/m', '3 yrs', 'dgfhgfg.pt.ltd', 'software developer', '35000 p/m', '2 yrs till '),
(8, '3', 'GHA pvt.ltd', 'accountant', '25000', '5 yrs', 'HRCH pvt.ltd', 'accountant', '75000', '5 yrs', 'TCGHB pvt ltd', 'Sr.Accountant', '95000 ', '8 yrs till'),
(9, '7', 'FAG pvt.ltd', 'HR Executive', '25000 p/m', '6 yrs', 'TYS', 'HR Executive', '35000 p/m', '7 yrs', 'hirp pvt.ltd', 'HR Executive', '45000 p/m', '4 yrs till'),
(10, '12', 'dfg.pvt.ltd', 'accountant', '25000 p/m', '1 yrs', 'fghpvt.ltd', 'accountant', '30000 p/m', '3 yrs', 'fghpvt.ltd', 'accountant', '45000 p/m', '5 yrs till'),
(11, '13', 'ABC', 'Developer', '12000 ', '2 years', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `employeedetail`
--

CREATE TABLE `employeedetail` (
  `ID` int(11) NOT NULL,
  `EmpFname` varchar(50) DEFAULT NULL,
  `EmpLName` varchar(50) NOT NULL,
  `EmpCode` varchar(50) DEFAULT NULL,
  `EmpDept` varchar(120) DEFAULT NULL,
  `EmpDesignation` varchar(120) DEFAULT NULL,
  `EmpContactNo` bigint(10) DEFAULT NULL,
  `EmpGender` enum('Male','Female') DEFAULT NULL,
  `EmpEmail` varchar(200) DEFAULT NULL,
  `EmpPassword` varchar(100) DEFAULT NULL,
  `EmpJoingdate` date DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `employeedetail`
--

INSERT INTO `employeedetail` (`ID`, `EmpFname`, `EmpLName`, `EmpCode`, `EmpDept`, `EmpDesignation`, `EmpContactNo`, `EmpGender`, `EmpEmail`, `EmpPassword`, `EmpJoingdate`, `PostingDate`) VALUES
(1, 'Subhash', 'Pandey', '123465', 'IT', 'Software Developer', 825099421, 'Male', 'abc@gmail.com', 'Test@12345', '2019-01-02', '2019-02-06 06:31:49'),
(2, 'Anuj', 'Kumar', '123465558', 'CS', 'Software Developer', 825099421, 'Male', 'anuj@gmail.com', '123', '2017-03-23', '2019-02-06 06:41:42'),
(3, 'Ankush', 'Pandey', '123467', 'IT', 'Software Developer', 825099421, 'Male', 'ankush@gmail.com', '89756', '2010-09-13', '2019-02-06 06:42:15'),
(4, 'Sarita', 'Pandey', '12346012', 'IT', 'Software Developer', 825099421, '', 'abhi@gmail.com', '156975', NULL, '2019-02-06 06:42:47'),
(6, 'Manu', 'Ramesh', '369874', NULL, NULL, NULL, NULL, 'manu@gmail.com', '987563', NULL, '2019-02-06 12:00:50'),
(7, 'Ragunath', 'Shahye', '63', NULL, NULL, NULL, NULL, 'shahye@gmail.com', '99999', NULL, '2019-02-08 07:22:40'),
(8, '1345556', '', '', NULL, NULL, NULL, NULL, '', '', NULL, '2019-02-11 05:08:40'),
(9, 'Garuv', 'Bhatia', '89745', NULL, NULL, NULL, NULL, 'jk@gmail.com', '12', NULL, '2019-02-11 05:12:28'),
(10, 'Khusi', 'Dev', '1234', NULL, NULL, NULL, NULL, 'hjk@gmail.com', '1990', NULL, '2019-02-11 05:18:08'),
(11, 'SARITA', 'pANDEY', '789', NULL, NULL, NULL, NULL, 'PANDEY@GMAIL.COM', '1111', NULL, '2019-02-11 08:50:55'),
(12, 'Dinesh', 'Karthik', '56989', NULL, NULL, NULL, NULL, 'dinesh@gmail.com', '8989', NULL, '2019-02-11 12:30:50'),
(13, 'Test', 'User', '2131231', 'IT', 'Software Developer', 1234567890, 'Male', 'testuser@gmail.com', 'Test@123', '2018-10-09', '2019-02-11 16:21:58');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(11) NOT NULL,
  `AdminName` varchar(50) DEFAULT NULL,
  `AdminuserName` varchar(50) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `AdminuserName`, `Password`, `AdminRegdate`) VALUES
(1, 'Sarita Pandey', 'Admin', 'Test@123', '2019-02-07 16:52:45');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `empeducation`
--
ALTER TABLE `empeducation`
  ADD PRIMARY KEY (`Id`);

--
-- Índices para tabela `empexpireince`
--
ALTER TABLE `empexpireince`
  ADD PRIMARY KEY (`ID`);

--
-- Índices para tabela `employeedetail`
--
ALTER TABLE `employeedetail`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `EmpCode` (`EmpCode`);

--
-- Índices para tabela `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `empeducation`
--
ALTER TABLE `empeducation`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `empexpireince`
--
ALTER TABLE `empexpireince`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `employeedetail`
--
ALTER TABLE `employeedetail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Banco de dados: `erp`
--
CREATE DATABASE IF NOT EXISTS `erp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `erp`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(0, 'Keyboard'),
(1, 'Mouse'),
(2, 'Monitor'),
(3, 'Motherboard'),
(4, 'Processor'),
(5, 'Power Supply'),
(6, 'Headset'),
(7, 'CPU'),
(9, 'Others');

-- --------------------------------------------------------

--
-- Estrutura da tabela `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_first_name` varchar(50) DEFAULT NULL,
  `customer_last_name` varchar(50) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_first_name`, `customer_last_name`, `customer_phone`) VALUES
(9, 'Hailee', 'Steinfield', '09394566543'),
(11, 'A Walk in Customer', 'Store', '09399887711'),
(14, 'Chuchay', 'Jusay', '09781633451'),
(15, 'Kimbert', 'Duyag', '09956288467'),
(16, 'Dieqcohr', 'Rufino', '09891344576'),
(17, 'Tom', 'Brady', '09399887711'),
(18, 'Bill', 'Bellichik', '09998239281'),
(22, 'Lance', 'Stroll', '19992887011');

-- --------------------------------------------------------

--
-- Estrutura da tabela `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `employee_first_name` varchar(50) DEFAULT NULL,
  `employee_last_name` varchar(50) DEFAULT NULL,
  `employee_gender` varchar(50) DEFAULT NULL,
  `employee_email` varchar(100) DEFAULT NULL,
  `employee_phone` varchar(11) DEFAULT NULL,
  `employee_role_id` int(11) DEFAULT NULL,
  `employee_hired_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `employee`
--

INSERT INTO `employee` (`employee_id`, `employee_first_name`, `employee_last_name`, `employee_gender`, `employee_email`, `employee_phone`, `employee_role_id`, `employee_hired_date`) VALUES
(1, 'Rexx', 'rexx', 'Male', 'rexx@gmail.com', '09124033805', 1, '2021-08-20'),
(6, 'Eduardo', 'Zagato', 'male', 'duzagatto@hotmail.com', '2999112929', 2, '2020-10-29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location_state` varchar(100) DEFAULT NULL,
  `location_city` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `locations`
--

INSERT INTO `locations` (`location_id`, `location_state`, `location_city`) VALUES
(111, 'Negros Occidental', 'Bacolod City'),
(112, 'Negros Occidental', 'Bacolod City'),
(113, 'dfdfdfd', 'Binalbagan'),
(114, 'Negros Occidental', 'Himamaylan'),
(115, 'Negros Oriental', 'Dumaguette City'),
(116, 'Negros Occidental', 'Isabella'),
(126, 'Negros Occidental', 'Binalbagan'),
(130, 'Cebu', 'Bogo City'),
(131, 'Negros Occidental', 'Himamaylan'),
(132, 'Negros', 'Jupiter'),
(133, 'Aincrad', 'Floor 91'),
(134, 'negros', 'binalbagan'),
(135, 'hehe', 'tehee'),
(136, 'PLANET YEKOK', 'KOKEY'),
(137, 'Camiguin', 'Catarman'),
(138, 'Camiguin', 'Catarman'),
(139, 'Negros Occidental', 'Binalbagan'),
(140, 'Batangas', 'Lemery'),
(141, 'Capiz', 'Panay'),
(142, 'Camarines Norte', 'Labo'),
(143, 'Camarines Norte', 'Labo'),
(144, 'Camarines Norte', 'Labo'),
(145, 'Camarines Norte', 'Labo'),
(146, 'Capiz', 'Pilar'),
(147, 'Negros Occidental', 'Moises Padilla'),
(148, 'a', 'a'),
(149, '1', '1'),
(150, 'Negros Occidental', 'Himamaylan'),
(151, 'Masbate', 'Mandaon'),
(152, 'Aklanas', 'Madalagsasa'),
(153, 'Batangas', 'Mabini'),
(154, 'Bataan', 'Morong'),
(155, 'Capiz', 'Pillar'),
(156, 'UTTAR PRADESH', 'noida'),
(157, 'Camarines Norte', 'Labo'),
(158, 'Negros Occidental', 'Binalbagan');

-- --------------------------------------------------------

--
-- Estrutura da tabela `manager`
--

CREATE TABLE `manager` (
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `manager`
--

INSERT INTO `manager` (`FIRST_NAME`, `LAST_NAME`, `LOCATION_ID`, `EMAIL`, `PHONE_NUMBER`) VALUES
('Prince Ly', 'Cesar', 113, 'PC@00', '09124033805'),
('Emman', 'Adventures', 116, 'emman@', '09123346576'),
('Bruce', 'Willis', 113, 'bruce@', NULL),
('Regine', 'Santos', 111, 'regine@', '09123456789');

-- --------------------------------------------------------

--
-- Estrutura da tabela `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_description` text NOT NULL,
  `product_price` int(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_description`, `product_price`, `category_id`, `supplier_id`) VALUES
(3, 'Predator Helios 300 Gaming Laptop', 'Windows 10 Home\r\nIntelÂ® Coreâ„¢ i7-8750H processor Hexa-core 2.20 GHz\r\n15.6\" Full HD (1920 x 1080) ', 77850, 7, 15),
(12, 'Fantech EG1', 'a', 895, 6, 13),
(15, 'Newmen E120', 'haha', 550, 0, 15),
(22, 'Lenovo ideapad 20059', 'hehe', 32999, 7, 12),
(27, 'A4tech OP-720', 'normal mouse', 289, 1, 16),
(29, 'Notebook Acer', 'asdjadlk', 1200, 0, 11),
(30, 'Notebook Samsung', 'askdjsadlk', 1200, 9, 11),
(31, 'Notebook Apple', 'Notebook incrivel', 1200000, 0, 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role_title` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `role`
--

INSERT INTO `role` (`role_id`, `role_title`) VALUES
(1, 'Manager'),
(2, 'Cashier');

-- --------------------------------------------------------

--
-- Estrutura da tabela `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_company_name` varchar(50) DEFAULT NULL,
  `supplier_phone` varchar(20) NOT NULL,
  `supplier_location_state` varchar(50) DEFAULT NULL,
  `supplier_location_city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_company_name`, `supplier_phone`, `supplier_location_state`, `supplier_location_city`) VALUES
(11, 'InGame Tech', '09457488521', 'Arizona', 'Glendale'),
(12, 'Asus', '09635877412', 'New York', 'New York'),
(13, 'Razer Co.', '09587855685', 'Colorado', 'Denver'),
(15, 'Strategic Technology Co.', '09124033805', 'Texas', 'Austin'),
(16, 'A4tech', '09775673257', 'New York', 'New York');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transaction`
--

CREATE TABLE `transaction` (
  `TRANS_ID` int(50) NOT NULL,
  `CUST_ID` int(11) DEFAULT NULL,
  `NUMOFITEMS` varchar(250) NOT NULL,
  `SUBTOTAL` varchar(50) NOT NULL,
  `LESSVAT` varchar(50) NOT NULL,
  `NETVAT` varchar(50) NOT NULL,
  `ADDVAT` varchar(50) NOT NULL,
  `GRANDTOTAL` varchar(250) NOT NULL,
  `CASH` varchar(250) NOT NULL,
  `DATE` varchar(50) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transaction`
--

INSERT INTO `transaction` (`TRANS_ID`, `CUST_ID`, `NUMOFITEMS`, `SUBTOTAL`, `LESSVAT`, `NETVAT`, `ADDVAT`, `GRANDTOTAL`, `CASH`, `DATE`, `TRANS_D_ID`) VALUES
(3, 16, '3', '456,982.00', '48,962.36', '408,019.64', '48,962.36', '456,982.00', '500000', '2019-03-18', '0318160336'),
(4, 11, '2', '1,967.00', '210.75', '1,756.25', '210.75', '1,967.00', '2000', '2019-03-18', '0318160622'),
(5, 14, '1', '550.00', '58.93', '491.07', '58.93', '550.00', '550', '2019-03-18', '0318170309'),
(6, 15, '1', '77,850.00', '8,341.07', '69,508.93', '8,341.07', '77,850.00', '80000', '2019-03-18', '0318170352'),
(7, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170511'),
(8, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170524'),
(9, 14, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170551'),
(10, 11, '1', '289.00', '30.96', '258.04', '30.96', '289.00', '500', '2019-03-18', '0318170624'),
(11, 9, '2', '1,148.00', '123.00', '1,025.00', '123.00', '1,148.00', '2000', '2019-03-18', '0318170825'),
(12, 9, '1', '5,500.00', '589.29', '4,910.71', '589.29', '5,500.00', '6000', '2019-03-18 19:40 pm', '0318194016'),
(13, 14, '3', '78,998.00', '8,464.07', '70,533.93', '8,464.07', '78,998.00', '1111', '2021-08-20 06:42 am', '082064328');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transactions_details`
--

CREATE TABLE `transactions_details` (
  `ID` int(11) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL,
  `PRODUCTS` varchar(250) NOT NULL,
  `QTY` varchar(250) NOT NULL,
  `PRICE` varchar(250) NOT NULL,
  `EMPLOYEE` varchar(250) NOT NULL,
  `ROLE` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transactions_details`
--

INSERT INTO `transactions_details` (`ID`, `TRANS_D_ID`, `PRODUCTS`, `QTY`, `PRICE`, `EMPLOYEE`, `ROLE`) VALUES
(7, '0318160336', 'Lenovo ideapad 20059', '2', '32999', 'Prince Ly', 'Manager'),
(8, '0318160336', 'Predator Helios 300 Gaming Laptop', '5', '77850', 'Prince Ly', 'Manager'),
(9, '0318160336', 'A4tech OP-720', '6', '289', 'Prince Ly', 'Manager'),
(10, '0318160622', 'Newmen E120', '2', '550', 'Prince Ly', 'Manager'),
(11, '0318160622', 'A4tech OP-720', '3', '289', 'Prince Ly', 'Manager'),
(12, '0318170309', 'Newmen E120', '1', '550', 'Prince Ly', 'Manager'),
(13, '0318170352', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'Prince Ly', 'Manager'),
(14, '0318170511', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(15, '0318170524', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(16, '0318170551', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(17, '0318170624', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(18, '0318170825', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(19, '0318170825', 'Fantech EG1', '1', '859', 'Prince Ly', 'Manager'),
(20, '0318194016', 'Newmen E120', '10', '550', 'Josuey', 'Cashier'),
(21, '082064328', 'A4tech OP-720', '1', '289', 'vicor', 'Cashier'),
(22, '082064328', 'Fantech EG1', '1', '859', 'vicor', 'Cashier'),
(23, '082064328', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'vicor', 'Cashier');

-- --------------------------------------------------------

--
-- Estrutura da tabela `type`
--

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `type`
--

INSERT INTO `type` (`type_id`, `type`) VALUES
(0, 'Cashier'),
(1, 'Admin'),
(2, 'Manager');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `user_login` varchar(50) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`user_id`, `employee_id`, `user_login`, `user_password`, `type_id`) VALUES
(1, 1, 'admin@admin', '8cb2237d0679ca88db6464eac60da96345513964', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Índices para tabela `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Índices para tabela `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `EMPLOYEE_ID` (`employee_id`),
  ADD UNIQUE KEY `PHONE_NUMBER` (`employee_phone`),
  ADD KEY `JOB_ID` (`employee_role_id`);

--
-- Índices para tabela `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Índices para tabela `manager`
--
ALTER TABLE `manager`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Índices para tabela `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `CATEGORY_ID` (`category_id`),
  ADD KEY `SUPPLIER_ID` (`supplier_id`);

--
-- Índices para tabela `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Índices para tabela `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Índices para tabela `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANS_ID`),
  ADD KEY `TRANS_DETAIL_ID` (`TRANS_D_ID`),
  ADD KEY `CUST_ID` (`CUST_ID`);

--
-- Índices para tabela `transactions_details`
--
ALTER TABLE `transactions_details`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TRANS_D_ID` (`TRANS_D_ID`) USING BTREE;

--
-- Índices para tabela `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`type_id`);

--
-- Índices para tabela `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `TYPE_ID` (`type_id`),
  ADD KEY `EMPLOYEE_ID` (`employee_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT de tabela `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TRANS_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `transactions_details`
--
ALTER TABLE `transactions_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`employee_role_id`) REFERENCES `role` (`role_id`);

--
-- Limitadores para a tabela `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `locations` (`location_id`);

--
-- Limitadores para a tabela `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Limitadores para a tabela `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CUST_ID`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`TRANS_D_ID`) REFERENCES `transactions_details` (`TRANS_D_ID`);

--
-- Limitadores para a tabela `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_3` FOREIGN KEY (`type_id`) REFERENCES `type` (`TYPE_ID`),
  ADD CONSTRAINT `user_ibfk_4` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`);
--
-- Banco de dados: `erp3`
--
CREATE DATABASE IF NOT EXISTS `erp3` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `erp3`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `category`
--

CREATE TABLE `category` (
  `CATEGORY_ID` int(11) NOT NULL,
  `CNAME` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `CNAME`) VALUES
(0, 'Keyboard'),
(1, 'Mouse'),
(2, 'Monitor'),
(3, 'Motherboard'),
(4, 'Processor'),
(5, 'Power Supply'),
(6, 'Headset'),
(7, 'CPU'),
(9, 'Others');

-- --------------------------------------------------------

--
-- Estrutura da tabela `customer`
--

CREATE TABLE `customer` (
  `CUST_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `customer`
--

INSERT INTO `customer` (`CUST_ID`, `FIRST_NAME`, `LAST_NAME`, `PHONE_NUMBER`) VALUES
(9, 'Hailee', 'Steinfield', '09394566543'),
(11, 'A Walk in Customer', NULL, NULL),
(14, 'Chuchay', 'Jusay', '09781633451'),
(15, 'Kimbert', 'Duyag', '09956288467'),
(16, 'Dieqcohr', 'Rufino', '09891344576');

-- --------------------------------------------------------

--
-- Estrutura da tabela `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `GENDER` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL,
  `JOB_ID` int(11) DEFAULT NULL,
  `HIRED_DATE` varchar(50) NOT NULL,
  `LOCATION_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `GENDER`, `EMAIL`, `PHONE_NUMBER`, `JOB_ID`, `HIRED_DATE`, `LOCATION_ID`) VALUES
(1, 'Rexx', 'rexx', 'Male', 'rexx@gmail.com', '09124033805', 1, '2021-08-20', 113),
(2, 'test', 'kumar', 'Female', 'test@yahoo.com', '09015501897', 2, '2019-01-28', 156),
(4, 'Monica', 'Empinado', 'Female', 'monicapadernal@gmail.com', '09123357105', 1, '2019-03-06', 158);

-- --------------------------------------------------------

--
-- Estrutura da tabela `job`
--

CREATE TABLE `job` (
  `JOB_ID` int(11) NOT NULL,
  `JOB_TITLE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `job`
--

INSERT INTO `job` (`JOB_ID`, `JOB_TITLE`) VALUES
(1, 'Manager'),
(2, 'Cashier');

-- --------------------------------------------------------

--
-- Estrutura da tabela `location`
--

CREATE TABLE `location` (
  `LOCATION_ID` int(11) NOT NULL,
  `PROVINCE` varchar(100) DEFAULT NULL,
  `CITY` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `location`
--

INSERT INTO `location` (`LOCATION_ID`, `PROVINCE`, `CITY`) VALUES
(111, 'Negros Occidental', 'Bacolod City'),
(112, 'Negros Occidental', 'Bacolod City'),
(113, 'dfdfdfd', 'Binalbagan'),
(114, 'Negros Occidental', 'Himamaylan'),
(115, 'Negros Oriental', 'Dumaguette City'),
(116, 'Negros Occidental', 'Isabella'),
(126, 'Negros Occidental', 'Binalbagan'),
(130, 'Cebu', 'Bogo City'),
(131, 'Negros Occidental', 'Himamaylan'),
(132, 'Negros', 'Jupiter'),
(133, 'Aincrad', 'Floor 91'),
(134, 'negros', 'binalbagan'),
(135, 'hehe', 'tehee'),
(136, 'PLANET YEKOK', 'KOKEY'),
(137, 'Camiguin', 'Catarman'),
(138, 'Camiguin', 'Catarman'),
(139, 'Negros Occidental', 'Binalbagan'),
(140, 'Batangas', 'Lemery'),
(141, 'Capiz', 'Panay'),
(142, 'Camarines Norte', 'Labo'),
(143, 'Camarines Norte', 'Labo'),
(144, 'Camarines Norte', 'Labo'),
(145, 'Camarines Norte', 'Labo'),
(146, 'Capiz', 'Pilar'),
(147, 'Negros Occidental', 'Moises Padilla'),
(148, 'a', 'a'),
(149, '1', '1'),
(150, 'Negros Occidental', 'Himamaylan'),
(151, 'Masbate', 'Mandaon'),
(152, 'Aklanas', 'Madalagsasa'),
(153, 'Batangas', 'Mabini'),
(154, 'Bataan', 'Morong'),
(155, 'Capiz', 'Pillar'),
(156, 'UTTAR PRADESH', 'noida'),
(157, 'Camarines Norte', 'Labo'),
(158, 'Negros Occidental', 'Binalbagan');

-- --------------------------------------------------------

--
-- Estrutura da tabela `manager`
--

CREATE TABLE `manager` (
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `manager`
--

INSERT INTO `manager` (`FIRST_NAME`, `LAST_NAME`, `LOCATION_ID`, `EMAIL`, `PHONE_NUMBER`) VALUES
('Prince Ly', 'Cesar', 113, 'PC@00', '09124033805'),
('Emman', 'Adventures', 116, 'emman@', '09123346576'),
('Bruce', 'Willis', 113, 'bruce@', NULL),
('Regine', 'Santos', 111, 'regine@', '09123456789');

-- --------------------------------------------------------

--
-- Estrutura da tabela `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_CODE` varchar(20) NOT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(250) NOT NULL,
  `QTY_STOCK` int(50) DEFAULT NULL,
  `ON_HAND` int(250) NOT NULL,
  `PRICE` int(50) DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `DATE_STOCK_IN` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_CODE`, `NAME`, `DESCRIPTION`, `QTY_STOCK`, `ON_HAND`, `PRICE`, `CATEGORY_ID`, `SUPPLIER_ID`, `DATE_STOCK_IN`) VALUES
(1, '20191001', 'Lenovo ideapad 20059', 'Windows 8', 1, 1, 32999, 7, 15, '2019-03-02'),
(3, '20191003', 'Predator Helios 300 Gaming Laptop', 'Windows 10 Home\r\nIntelÂ® Coreâ„¢ i7-8750H processor Hexa-core 2.20 GHz\r\n15.6\" Full HD (1920 x 1080) ', 1, 1, 77850, 7, 15, '2019-03-02'),
(4, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-02'),
(5, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 15, '2019-03-03'),
(6, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(8, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-05'),
(9, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(10, '20191004', 'Fantech EG1', 'BEST FOR MOBILE PHONE GAMERS\r\nSPEAKER:10mm\r\nIMPEDANCE: 18+-15%\r\nFREQUENCY RESPONSE: 20 TO 20khz\r\nMICROPHONE : OMNI DIRECTIONAL\r\nJACK: AUDIO+MICROPHONE\r\nCOMBINED JACK 3.5 WIRE\r\nWIRE LENGTH: 1.3M\r\nWhat in inside:-1 pcs Female 3.5mm to Audio and\r\nmicrop', 1, 1, 859, 6, 13, '2019-03-06'),
(11, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(12, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(13, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(14, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(15, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(16, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(17, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(18, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(19, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(20, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(21, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(22, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(23, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(24, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(25, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(26, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(27, '20191005', 'A4tech OP-720', 'normal mouse', 1, 1, 289, 1, 16, '2019-03-13'),
(28, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(29, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(30, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(31, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(32, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(33, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(34, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(35, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(36, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10'),
(37, '91823012', 'Intel i5', 'Intel i5', 1, 1, 799, 4, 16, '2022-12-10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `supplier`
--

CREATE TABLE `supplier` (
  `SUPPLIER_ID` int(11) NOT NULL,
  `COMPANY_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `supplier`
--

INSERT INTO `supplier` (`SUPPLIER_ID`, `COMPANY_NAME`, `LOCATION_ID`, `PHONE_NUMBER`) VALUES
(11, 'InGame Tech', 114, '09457488521'),
(12, 'Asus', 115, '09635877412'),
(13, 'Razer Co.', 111, '09587855685'),
(15, 'Strategic Technology Co.', 116, '09124033805'),
(16, 'A4tech', 155, '09775673257');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transaction`
--

CREATE TABLE `transaction` (
  `TRANS_ID` int(50) NOT NULL,
  `CUST_ID` int(11) DEFAULT NULL,
  `NUMOFITEMS` varchar(250) NOT NULL,
  `SUBTOTAL` varchar(50) NOT NULL,
  `LESSVAT` varchar(50) NOT NULL,
  `NETVAT` varchar(50) NOT NULL,
  `ADDVAT` varchar(50) NOT NULL,
  `GRANDTOTAL` varchar(250) NOT NULL,
  `CASH` varchar(250) NOT NULL,
  `DATE` varchar(50) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transaction`
--

INSERT INTO `transaction` (`TRANS_ID`, `CUST_ID`, `NUMOFITEMS`, `SUBTOTAL`, `LESSVAT`, `NETVAT`, `ADDVAT`, `GRANDTOTAL`, `CASH`, `DATE`, `TRANS_D_ID`) VALUES
(3, 16, '3', '456,982.00', '48,962.36', '408,019.64', '48,962.36', '456,982.00', '500000', '2019-03-18', '0318160336'),
(4, 11, '2', '1,967.00', '210.75', '1,756.25', '210.75', '1,967.00', '2000', '2019-03-18', '0318160622'),
(5, 14, '1', '550.00', '58.93', '491.07', '58.93', '550.00', '550', '2019-03-18', '0318170309'),
(6, 15, '1', '77,850.00', '8,341.07', '69,508.93', '8,341.07', '77,850.00', '80000', '2019-03-18', '0318170352'),
(7, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170511'),
(8, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170524'),
(9, 14, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170551'),
(10, 11, '1', '289.00', '30.96', '258.04', '30.96', '289.00', '500', '2019-03-18', '0318170624'),
(11, 9, '2', '1,148.00', '123.00', '1,025.00', '123.00', '1,148.00', '2000', '2019-03-18', '0318170825'),
(12, 9, '1', '5,500.00', '589.29', '4,910.71', '589.29', '5,500.00', '6000', '2019-03-18 19:40 pm', '0318194016'),
(13, 14, '3', '78,998.00', '8,464.07', '70,533.93', '8,464.07', '78,998.00', '1111', '2021-08-20 06:42 am', '082064328'),
(14, 14, '2', '839.00', '89.89', '749.11', '89.89', '839.00', '850', '2022-06-28 12:35 pm', '0628123653'),
(15, 16, '2', '78,400.00', '8,400.00', '70,000.00', '8,400.00', '78,400.00', '80000', '2022-07-11 19:29 pm', '0711192959');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transaction_details`
--

CREATE TABLE `transaction_details` (
  `ID` int(11) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL,
  `PRODUCTS` varchar(250) NOT NULL,
  `QTY` varchar(250) NOT NULL,
  `PRICE` varchar(250) NOT NULL,
  `EMPLOYEE` varchar(250) NOT NULL,
  `ROLE` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transaction_details`
--

INSERT INTO `transaction_details` (`ID`, `TRANS_D_ID`, `PRODUCTS`, `QTY`, `PRICE`, `EMPLOYEE`, `ROLE`) VALUES
(7, '0318160336', 'Lenovo ideapad 20059', '2', '32999', 'Prince Ly', 'Manager'),
(8, '0318160336', 'Predator Helios 300 Gaming Laptop', '5', '77850', 'Prince Ly', 'Manager'),
(9, '0318160336', 'A4tech OP-720', '6', '289', 'Prince Ly', 'Manager'),
(10, '0318160622', 'Newmen E120', '2', '550', 'Prince Ly', 'Manager'),
(11, '0318160622', 'A4tech OP-720', '3', '289', 'Prince Ly', 'Manager'),
(12, '0318170309', 'Newmen E120', '1', '550', 'Prince Ly', 'Manager'),
(13, '0318170352', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'Prince Ly', 'Manager'),
(14, '0318170511', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(15, '0318170524', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(16, '0318170551', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(17, '0318170624', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(18, '0318170825', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(19, '0318170825', 'Fantech EG1', '1', '859', 'Prince Ly', 'Manager'),
(20, '0318194016', 'Newmen E120', '10', '550', 'Josuey', 'Cashier'),
(21, '082064328', 'A4tech OP-720', '1', '289', 'vicor', 'Cashier'),
(22, '082064328', 'Fantech EG1', '1', '859', 'vicor', 'Cashier'),
(23, '082064328', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'vicor', 'Cashier'),
(24, '0628123653', 'Newmen E120', '1', '550', 'test', 'Cashier'),
(25, '0628123653', 'A4tech OP-720', '1', '289', 'test', 'Cashier'),
(26, '0711192959', 'Newmen E120', '1', '550', 'Rexx', 'Manager'),
(27, '0711192959', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'Rexx', 'Manager');

-- --------------------------------------------------------

--
-- Estrutura da tabela `type`
--

CREATE TABLE `type` (
  `TYPE_ID` int(11) NOT NULL,
  `TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `type`
--

INSERT INTO `type` (`TYPE_ID`, `TYPE`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `USERNAME` varchar(50) DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `TYPE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`ID`, `EMPLOYEE_ID`, `USERNAME`, `PASSWORD`, `TYPE_ID`) VALUES
(1, 1, 'admin@admin', '8cb2237d0679ca88db6464eac60da96345513964', 1),
(7, 2, 'test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 2),
(9, 4, 'mncpdrnl', '8cb2237d0679ca88db6464eac60da96345513964', 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CATEGORY_ID`);

--
-- Índices para tabela `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CUST_ID`);

--
-- Índices para tabela `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`),
  ADD KEY `JOB_ID` (`JOB_ID`);

--
-- Índices para tabela `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`JOB_ID`);

--
-- Índices para tabela `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- Índices para tabela `manager`
--
ALTER TABLE `manager`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Índices para tabela `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `CATEGORY_ID` (`CATEGORY_ID`),
  ADD KEY `SUPPLIER_ID` (`SUPPLIER_ID`);

--
-- Índices para tabela `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SUPPLIER_ID`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Índices para tabela `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANS_ID`),
  ADD KEY `TRANS_DETAIL_ID` (`TRANS_D_ID`),
  ADD KEY `CUST_ID` (`CUST_ID`);

--
-- Índices para tabela `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TRANS_D_ID` (`TRANS_D_ID`) USING BTREE;

--
-- Índices para tabela `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`TYPE_ID`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TYPE_ID` (`TYPE_ID`),
  ADD KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `category`
--
ALTER TABLE `category`
  MODIFY `CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `customer`
--
ALTER TABLE `customer`
  MODIFY `CUST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `employee`
--
ALTER TABLE `employee`
  MODIFY `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `location`
--
ALTER TABLE `location`
  MODIFY `LOCATION_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT de tabela `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de tabela `supplier`
--
ALTER TABLE `supplier`
  MODIFY `SUPPLIER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TRANS_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`JOB_ID`) REFERENCES `job` (`JOB_ID`);

--
-- Limitadores para a tabela `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Limitadores para a tabela `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`SUPPLIER_ID`) REFERENCES `supplier` (`SUPPLIER_ID`);

--
-- Limitadores para a tabela `supplier`
--
ALTER TABLE `supplier`
  ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Limitadores para a tabela `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CUST_ID`) REFERENCES `customer` (`CUST_ID`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`TRANS_D_ID`) REFERENCES `transaction_details` (`TRANS_D_ID`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`TYPE_ID`) REFERENCES `type` (`TYPE_ID`),
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`);
--
-- Banco de dados: `fantastic_school_admin_db`
--
CREATE DATABASE IF NOT EXISTS `fantastic_school_admin_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `fantastic_school_admin_db`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `branch`
--

CREATE TABLE `branch` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `AccountNumber` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `branch`
--

INSERT INTO `branch` (`id`, `Name`, `AccountNumber`) VALUES
(0, 'Bank of America', '00000132254545'),
(1, 'Equity Bank', '351672718822'),
(2, 'KCB Bank', '98262891719');

-- --------------------------------------------------------

--
-- Estrutura da tabela `classattendance`
--

CREATE TABLE `classattendance` (
  `id` int(10) UNSIGNED NOT NULL,
  `Subject` int(10) UNSIGNED NOT NULL,
  `Student` int(10) UNSIGNED NOT NULL,
  `RegNo` int(10) UNSIGNED DEFAULT NULL,
  `Class` int(10) UNSIGNED DEFAULT NULL,
  `Stream` int(10) UNSIGNED DEFAULT NULL,
  `Attended` varchar(40) DEFAULT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `classattendance`
--

INSERT INTO `classattendance` (`id`, `Subject`, `Student`, `RegNo`, `Class`, `Stream`, `Attended`, `Date`) VALUES
(0, 1, 1, 1, 1, 1, '1', '2018-07-22');

-- --------------------------------------------------------

--
-- Estrutura da tabela `classes`
--

CREATE TABLE `classes` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `classes`
--

INSERT INTO `classes` (`id`, `Name`) VALUES
(0, '12'),
(1, 'Form One'),
(2, 'Form Two');

-- --------------------------------------------------------

--
-- Estrutura da tabela `events`
--

CREATE TABLE `events` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Date` date NOT NULL,
  `Details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `events`
--

INSERT INTO `events` (`id`, `Name`, `Date`, `Details`) VALUES
(0, 'Bootcamp', '2018-07-30', '<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec maximus sollicitudin quam, vitae iaculis est pretium quis. Aliquam eget sapien odio. Sed erat augue, sollicitudin nec justo vel, dictum elementum nisi. Nunc augue ligula, bibendum egestas elit vel, egestas blandit velit. Donec tincidunt scelerisque lorem vel luctus. Phasellus eu tincidunt tellus, non tincidunt risus. Cras at eros orci. Proin sit amet malesuada mauris. Nunc massa velit, pellentesque id mi quis, efficitur semper dui.</p><br class=\"Apple-interchange-newline\">');

-- --------------------------------------------------------

--
-- Estrutura da tabela `examcategories`
--

CREATE TABLE `examcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `examcategories`
--

INSERT INTO `examcategories` (`id`, `Name`) VALUES
(1, 'End Term 1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `examresults`
--

CREATE TABLE `examresults` (
  `id` int(10) UNSIGNED NOT NULL,
  `student` int(10) UNSIGNED NOT NULL,
  `RegNo` int(10) UNSIGNED DEFAULT NULL,
  `Class` int(10) UNSIGNED DEFAULT NULL,
  `Stream` int(10) UNSIGNED DEFAULT NULL,
  `Category` int(10) UNSIGNED DEFAULT NULL,
  `Subject` int(10) UNSIGNED DEFAULT NULL,
  `Marks` int(11) NOT NULL,
  `Term` int(10) UNSIGNED NOT NULL,
  `AcademicYear` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `feescollection`
--

CREATE TABLE `feescollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `Student` int(10) UNSIGNED NOT NULL,
  `Class` int(10) UNSIGNED DEFAULT NULL,
  `Session` int(10) UNSIGNED NOT NULL,
  `PaidAmount` int(11) NOT NULL,
  `Balance` int(10) UNSIGNED DEFAULT NULL,
  `Branch` int(10) UNSIGNED NOT NULL,
  `Date` date DEFAULT NULL,
  `Remarks` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `feescollection`
--

INSERT INTO `feescollection` (`id`, `Student`, `Class`, `Session`, `PaidAmount`, `Balance`, `Branch`, `Date`, `Remarks`) VALUES
(0, 0, 0, 1, 11000, 0, 1, '2018-07-30', 'Paid'),
(1, 1, 1, 1, 1000, 1, 1, '2018-05-02', NULL),
(2, 1, 1, 1, 3000, 1, 2, '2018-05-03', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `hostels`
--

CREATE TABLE `hostels` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `hostels`
--

INSERT INTO `hostels` (`id`, `Name`, `Status`) VALUES
(0, 'Demo', 'Available'),
(1, 'Reez', 'Available');

-- --------------------------------------------------------

--
-- Estrutura da tabela `membership_grouppermissions`
--

CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membership_grouppermissions`
--

INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 2, 'students', 1, 3, 3, 3),
(2, 2, 'feescollection', 1, 3, 3, 3),
(3, 2, 'branch', 1, 3, 3, 3),
(4, 2, 'teachers', 1, 3, 3, 3),
(5, 2, 'subjects', 1, 3, 3, 3),
(6, 2, 'classes', 1, 3, 3, 3),
(7, 2, 'streams', 1, 3, 3, 3),
(8, 2, 'hostels', 1, 3, 3, 3),
(9, 2, 'timetable', 1, 3, 3, 3),
(10, 2, 'events', 1, 3, 3, 3),
(11, 2, 'notices', 1, 3, 3, 3),
(12, 2, 'examresults', 1, 3, 3, 3),
(13, 2, 'parents', 1, 3, 3, 3),
(14, 2, 'examcategories', 1, 3, 3, 3),
(15, 2, 'sessions', 1, 3, 3, 3),
(16, 2, 'studentcategories', 1, 3, 3, 3),
(17, 2, 'classattendance', 1, 3, 3, 3),
(18, 2, 'fee_structure', 1, 3, 3, 3),
(19, 2, 'fee_structure', 1, 3, 3, 3),
(20, 2, 'fee_structure', 1, 3, 3, 3),
(21, 2, 'schoolmoney', 1, 3, 3, 3),
(40, 3, 'students', 0, 3, 0, 0),
(41, 3, 'feescollection', 0, 3, 0, 0),
(42, 3, 'branch', 1, 3, 0, 0),
(43, 3, 'teachers', 0, 3, 0, 0),
(44, 3, 'subjects', 0, 3, 0, 0),
(45, 3, 'classes', 0, 3, 0, 0),
(46, 3, 'streams', 0, 3, 0, 0),
(47, 3, 'hostels', 0, 3, 0, 0),
(48, 3, 'timetable', 0, 3, 0, 0),
(49, 3, 'events', 1, 3, 0, 0),
(50, 3, 'notices', 0, 3, 0, 0),
(51, 3, 'examresults', 0, 3, 0, 0),
(52, 3, 'parents', 0, 3, 0, 0),
(53, 3, 'examcategories', 0, 3, 0, 0),
(54, 3, 'sessions', 0, 3, 0, 0),
(55, 3, 'studentcategories', 0, 3, 0, 0),
(56, 3, 'classattendance', 0, 3, 0, 0),
(57, 3, 'schoolmoney', 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `membership_groups`
--

CREATE TABLE `membership_groups` (
  `groupID` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membership_groups`
--

INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES
(1, 'anonymous', 'Anonymous group created automatically on 2018-05-02', 0, 0),
(2, 'Admins', 'Admin group created automatically on 2018-05-02', 0, 1),
(3, 'users', 'all test users', 1, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `membership_userpermissions`
--

CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `membership_userrecords`
--

CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) UNSIGNED NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) UNSIGNED DEFAULT NULL,
  `dateUpdated` bigint(20) UNSIGNED DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membership_userrecords`
--

INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES
(1, 'classes', '1', 'admin', 1525280850, 1525280850, 2),
(2, 'classes', '2', 'admin', 1525280867, 1525280867, 2),
(3, 'streams', '1', 'admin', 1525280880, 1525280880, 2),
(4, 'streams', '2', 'admin', 1525280893, 1525280893, 2),
(5, 'branch', '1', 'admin', 1525280912, 1525280912, 2),
(6, 'branch', '2', 'admin', 1525280926, 1525280926, 2),
(7, 'sessions', '1', 'admin', 1525280952, 1525314825, 2),
(8, 'fee_structure', '1', 'admin', 1525281199, 1525281199, 2),
(9, 'students', '1', 'admin', 1525281461, 1525306816, 2),
(10, 'feescollection', '1', 'admin', 1525281522, 1525306950, 2),
(11, 'hostels', '1', 'admin', 1525281663, 1525281663, 2),
(12, 'subjects', '1', 'admin', 1525294277, 1525294277, 2),
(13, 'schoolmoney', '1', 'admin', 1525306280, 1525306280, 2),
(14, 'examcategories', '1', 'admin', 1525310012, 1525310012, 2),
(15, 'feescollection', '2', 'admin', 1525314888, 1525314888, 2),
(0, 'classattendance', '0', 'admin', 1532241827, 1532241827, 2),
(0, 'schoolmoney', '0', 'admin', 1532945263, 1532945263, 2),
(0, 'classes', '0', 'admin', 1532945290, 1532945290, 2),
(0, 'studentcategories', '0', 'admin', 1532945324, 1532945324, 2),
(0, 'parents', '0', 'admin', 1532945398, 1532945398, 2),
(0, 'students', '0', 'admin', 1532945405, 1532945405, 2),
(0, 'teachers', '0', 'admin', 1532956950, 1532956950, 2),
(0, 'subjects', '0', 'admin', 1532956992, 1532956992, 2),
(0, 'notices', '0', 'admin', 1532957308, 1532957308, 2),
(0, 'hostels', '0', 'admin', 1532957327, 1532957327, 2),
(0, 'feescollection', '0', 'admin', 1532957665, 1532957665, 2),
(0, 'branch', '0', 'admin', 1532957704, 1532957704, 2),
(0, 'events', '0', 'admin', 1532958930, 1532958930, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `membership_users`
--

CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) UNSIGNED DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text DEFAULT NULL,
  `custom2` text DEFAULT NULL,
  `custom3` text DEFAULT NULL,
  `custom4` text DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membership_users`
--

INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES
('admin', 'af359ab8f3da5f33ffa01f6736e8c02d', 'ronniengoda@gmail.com', '2018-05-02', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-05-02\nRecord updated automatically on 2018-05-03', NULL, NULL),
('guest', NULL, NULL, '2018-05-02', 1, 0, 1, NULL, NULL, NULL, NULL, 'Anonymous member created automatically on 2018-05-02', NULL, NULL),
('kelvin', 'bdf0a027d5e138c2428f5acd68d7d600', 'kevo@gmail.com', '2018-05-03', 3, 0, 1, '', '', '', '', 'member signed up through the registration form.', NULL, NULL),
('harry', 'd3915844cde56f2dccfd24c7d34d12f0', 'harry@den.com', '2018-07-05', 3, 0, 1, '', '', '', '', 'member signed up through the registration form.', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `notices`
--

CREATE TABLE `notices` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Date` date NOT NULL,
  `Details` text NOT NULL,
  `Posted_By` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `notices`
--

INSERT INTO `notices` (`id`, `Name`, `Date`, `Details`, `Posted_By`) VALUES
(0, 'Spirng Carnival', '2018-07-30', 'To inform all the students about the Spring Carnival Event which is going to be held on school premises. All the students are requested to take part in different activities. For more details contact RTE.', 'admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `parents`
--

CREATE TABLE `parents` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Phone` varchar(40) NOT NULL,
  `Email` varchar(80) DEFAULT NULL,
  `HomeAddress` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `parents`
--

INSERT INTO `parents` (`id`, `Name`, `Phone`, `Email`, `HomeAddress`) VALUES
(0, 'Demo', '123456789', NULL, 'demo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `schoolmoney`
--

CREATE TABLE `schoolmoney` (
  `id` int(10) UNSIGNED NOT NULL,
  `Class` int(10) UNSIGNED NOT NULL,
  `Particulars` text NOT NULL,
  `Total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `schoolmoney`
--

INSERT INTO `schoolmoney` (`id`, `Class`, `Particulars`, `Total`) VALUES
(1, 1, 'All fees-15000', '15000.00'),
(0, 2, 'demo', '15000.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sessions`
--

CREATE TABLE `sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `Year` varchar(40) NOT NULL,
  `Term` varchar(40) NOT NULL,
  `status` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sessions`
--

INSERT INTO `sessions` (`id`, `Year`, `Term`, `status`) VALUES
(1, '2018', '2', 'active');

-- --------------------------------------------------------

--
-- Estrutura da tabela `streams`
--

CREATE TABLE `streams` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `streams`
--

INSERT INTO `streams` (`id`, `Name`) VALUES
(1, 'East'),
(2, 'Central');

-- --------------------------------------------------------

--
-- Estrutura da tabela `studentcategories`
--

CREATE TABLE `studentcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `studentcategories`
--

INSERT INTO `studentcategories` (`id`, `Name`) VALUES
(0, 'Demo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `FullName` varchar(40) NOT NULL,
  `Gender` varchar(40) NOT NULL,
  `DOB` date NOT NULL,
  `Photo` varchar(40) DEFAULT NULL,
  `RegNo` varchar(40) NOT NULL,
  `Class` int(10) UNSIGNED NOT NULL,
  `Stream` int(10) UNSIGNED DEFAULT NULL,
  `Hostel` int(10) UNSIGNED DEFAULT NULL,
  `DOJ` date NOT NULL,
  `Category` int(10) UNSIGNED DEFAULT NULL,
  `AcademicYear` int(10) UNSIGNED NOT NULL,
  `TotalFees` int(10) UNSIGNED NOT NULL,
  `AdvanceFees` int(11) NOT NULL,
  `Balance` int(11) DEFAULT NULL,
  `Parent` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `students`
--

INSERT INTO `students` (`id`, `FullName`, `Gender`, `DOB`, `Photo`, `RegNo`, `Class`, `Stream`, `Hostel`, `DOJ`, `Category`, `AcademicYear`, `TotalFees`, `AdvanceFees`, `Balance`, `Parent`) VALUES
(1, 'Wafula Chebukati', 'Male', '1916-01-18', NULL, 'IEBC/2017', 1, 2, 1, '2018-05-02', NULL, 1, 1, 10500, 500, NULL),
(0, 'Harry Den', 'Male', '1996-02-05', NULL, '852', 0, 2, 1, '2018-07-30', 0, 1, 1, 500, 3500, 0),
(0, 'Christine Gray', 'Female', '1997-04-17', '04619000_1532957454.jpg', '123', 0, 2, 0, '2018-07-30', 0, 1, 0, 5000, 3500, 0),
(0, 'Johnny Doe', 'Male', '1996-03-16', '68070100_1532957566.png', '80', 0, 1, 1, '2018-07-30', 0, 1, 1, 6000, 3500, 0),
(0, 'Bruno Den', 'Male', '1996-12-18', '24894200_1532957631.png', '366', 0, 2, 1, '2018-07-30', 0, 1, 1, 2000, 3500, 0),
(0, 'William Carter', 'Male', '1996-09-15', '08808400_1532959007.png', '852', 0, 2, 0, '2018-07-30', 0, 1, 0, 1500, 13500, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `subjects`
--

CREATE TABLE `subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `subjects`
--

INSERT INTO `subjects` (`id`, `Name`) VALUES
(1, 'Tec 104'),
(0, 'Database');

-- --------------------------------------------------------

--
-- Estrutura da tabela `teachers`
--

CREATE TABLE `teachers` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Gender` varchar(40) NOT NULL,
  `Age` int(11) NOT NULL,
  `Phone` varchar(40) NOT NULL,
  `Email` varchar(80) DEFAULT NULL,
  `StaffNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `teachers`
--

INSERT INTO `teachers` (`id`, `Name`, `Gender`, `Age`, `Phone`, `Email`, `StaffNumber`) VALUES
(0, 'John Doe', 'Male', 29, '7531598522', 'johndoe@gmail.com', 12),
(0, 'Benedict Cober', 'Male', 33, '1597534560', 'iambenedict@mail.com', 13);

-- --------------------------------------------------------

--
-- Estrutura da tabela `timetable`
--

CREATE TABLE `timetable` (
  `id` int(10) UNSIGNED NOT NULL,
  `Time_Table` varchar(40) NOT NULL,
  `Class` int(10) UNSIGNED NOT NULL,
  `Stream` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `classattendance`
--
ALTER TABLE `classattendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Subject` (`Subject`),
  ADD KEY `Student` (`Student`);

--
-- Índices para tabela `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `examcategories`
--
ALTER TABLE `examcategories`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `examresults`
--
ALTER TABLE `examresults`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student` (`student`),
  ADD KEY `Category` (`Category`),
  ADD KEY `Subject` (`Subject`),
  ADD KEY `Term` (`Term`);

--
-- Índices para tabela `feescollection`
--
ALTER TABLE `feescollection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Student` (`Student`),
  ADD KEY `Session` (`Session`),
  ADD KEY `Branch` (`Branch`);

--
-- Índices para tabela `hostels`
--
ALTER TABLE `hostels`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Índices para tabela `membership_groups`
--
ALTER TABLE `membership_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Índices para tabela `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Índices para tabela `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  ADD UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`),
  ADD KEY `pkValue` (`pkValue`),
  ADD KEY `tableName` (`tableName`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Índices para tabela `membership_users`
--
ALTER TABLE `membership_users`
  ADD KEY `groupID` (`groupID`);
--
-- Banco de dados: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Extraindo dados da tabela `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"adevirp\",\"table\":\"tipo\"},{\"db\":\"adevirp\",\"table\":\"colaborador\"},{\"db\":\"adevirp\",\"table\":\"user\"},{\"db\":\"adevirp\",\"table\":\"type\"},{\"db\":\"adevirp\",\"table\":\"educando\"},{\"db\":\"adevirp\",\"table\":\"student\"},{\"db\":\"adevirp\",\"table\":\"agenda\"},{\"db\":\"adevirp\",\"table\":\"schelude\"},{\"db\":\"adevirp\",\"table\":\"projeto\"},{\"db\":\"adevirp\",\"table\":\"project\"}]');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

--
-- Extraindo dados da tabela `pma__table_info`
--

INSERT INTO `pma__table_info` (`db_name`, `table_name`, `display_field`) VALUES
('adevirp', 'agenda', 'agenda_dia'),
('adevirp', 'colaborador', 'colaborador_nome'),
('adevirp', 'educando', 'educando_visao'),
('adevirp', 'projeto', 'projeto_nome'),
('erp', 'employee', 'employee_first_name'),
('erp', 'supplier', 'supplier_company_name');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Extraindo dados da tabela `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'erp', 'product', '{\"sorted_col\":\"`products`.`product_name` ASC\"}', '2022-07-10 15:10:26'),
('root', 'erp', 'supplier', '{\"sorted_col\":\"`suppliers`.`supplier_company_name` ASC\"}', '2022-07-10 19:32:10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Extraindo dados da tabela `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2022-07-24 12:23:31', '{\"Console\\/Mode\":\"show\",\"lang\":\"pt\",\"NavigationWidth\":242}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Índices para tabela `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Índices para tabela `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Índices para tabela `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Índices para tabela `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Índices para tabela `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Índices para tabela `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Índices para tabela `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Índices para tabela `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Índices para tabela `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Índices para tabela `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Índices para tabela `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Índices para tabela `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Índices para tabela `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Índices para tabela `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Índices para tabela `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Índices para tabela `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Índices para tabela `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Banco de dados: `prince`
--
CREATE DATABASE IF NOT EXISTS `prince` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `prince`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `category`
--

CREATE TABLE `category` (
  `CATEGORY_ID` int(11) NOT NULL,
  `CNAME` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `CNAME`) VALUES
(0, 'Keyboard'),
(1, 'Mouse'),
(2, 'Monitor'),
(3, 'Motherboard'),
(4, 'Processor'),
(5, 'Power Supply'),
(6, 'Headset'),
(7, 'CPU'),
(9, 'Others');

-- --------------------------------------------------------

--
-- Estrutura da tabela `customer`
--

CREATE TABLE `customer` (
  `CUST_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `customer`
--

INSERT INTO `customer` (`CUST_ID`, `FIRST_NAME`, `LAST_NAME`, `PHONE_NUMBER`) VALUES
(9, 'Hailee', 'Steinfield', '09394566543'),
(11, 'A Walk in Customer', NULL, NULL),
(14, 'Chuchay', 'Jusay', '09781633451'),
(15, 'Kimbert', 'Duyag', '09956288467'),
(16, 'Dieqcohr', 'Rufino', '09891344576');

-- --------------------------------------------------------

--
-- Estrutura da tabela `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `GENDER` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL,
  `JOB_ID` int(11) DEFAULT NULL,
  `HIRED_DATE` varchar(50) NOT NULL,
  `LOCATION_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `GENDER`, `EMAIL`, `PHONE_NUMBER`, `JOB_ID`, `HIRED_DATE`, `LOCATION_ID`) VALUES
(1, 'Prince Ly', 'Cesar', 'Male', 'princelycesar23@gmail.com', '09124033805', 1, '0000-00-00', 113),
(2, 'Josuey', 'Mag-asos', 'Male', 'jmagaso@yahoo.com', '09091245761', 2, '2019-01-28', 156),
(4, 'Monica', 'Empinado', 'Female', 'monicapadernal@gmail.com', '09123357105', 1, '2019-03-06', 158);

-- --------------------------------------------------------

--
-- Estrutura da tabela `job`
--

CREATE TABLE `job` (
  `JOB_ID` int(11) NOT NULL,
  `JOB_TITLE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `job`
--

INSERT INTO `job` (`JOB_ID`, `JOB_TITLE`) VALUES
(1, 'Manager'),
(2, 'Cashier');

-- --------------------------------------------------------

--
-- Estrutura da tabela `location`
--

CREATE TABLE `location` (
  `LOCATION_ID` int(11) NOT NULL,
  `PROVINCE` varchar(100) DEFAULT NULL,
  `CITY` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `location`
--

INSERT INTO `location` (`LOCATION_ID`, `PROVINCE`, `CITY`) VALUES
(111, 'Negros Occidental', 'Bacolod City'),
(112, 'Negros Occidental', 'Bacolod City'),
(113, 'Negros Occidental', 'Binalbagan'),
(114, 'Negros Occidental', 'Himamaylan'),
(115, 'Negros Oriental', 'Dumaguette City'),
(116, 'Negros Occidental', 'Isabella'),
(126, 'Negros Occidental', 'Binalbagan'),
(130, 'Cebu', 'Bogo City'),
(131, 'Negros Occidental', 'Himamaylan'),
(132, 'Negros', 'Jupiter'),
(133, 'Aincrad', 'Floor 91'),
(134, 'negros', 'binalbagan'),
(135, 'hehe', 'tehee'),
(136, 'PLANET YEKOK', 'KOKEY'),
(137, 'Camiguin', 'Catarman'),
(138, 'Camiguin', 'Catarman'),
(139, 'Negros Occidental', 'Binalbagan'),
(140, 'Batangas', 'Lemery'),
(141, 'Capiz', 'Panay'),
(142, 'Camarines Norte', 'Labo'),
(143, 'Camarines Norte', 'Labo'),
(144, 'Camarines Norte', 'Labo'),
(145, 'Camarines Norte', 'Labo'),
(146, 'Capiz', 'Pilar'),
(147, 'Negros Occidental', 'Moises Padilla'),
(148, 'a', 'a'),
(149, '1', '1'),
(150, 'Negros Occidental', 'Himamaylan'),
(151, 'Masbate', 'Mandaon'),
(152, 'Aklanas', 'Madalagsasa'),
(153, 'Batangas', 'Mabini'),
(154, 'Bataan', 'Morong'),
(155, 'Capiz', 'Pillar'),
(156, 'Negros Occidental', 'Bacolod'),
(157, 'Camarines Norte', 'Labo'),
(158, 'Negros Occidental', 'Binalbagan');

-- --------------------------------------------------------

--
-- Estrutura da tabela `manager`
--

CREATE TABLE `manager` (
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `manager`
--

INSERT INTO `manager` (`FIRST_NAME`, `LAST_NAME`, `LOCATION_ID`, `EMAIL`, `PHONE_NUMBER`) VALUES
('Prince Ly', 'Cesar', 113, 'PC@00', '09124033805'),
('Emman', 'Adventures', 116, 'emman@', '09123346576'),
('Bruce', 'Willis', 113, 'bruce@', NULL),
('Regine', 'Santos', 111, 'regine@', '09123456789');

-- --------------------------------------------------------

--
-- Estrutura da tabela `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_CODE` varchar(20) NOT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(250) NOT NULL,
  `QTY_STOCK` int(50) DEFAULT NULL,
  `ON_HAND` int(250) NOT NULL,
  `PRICE` int(50) DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `DATE_STOCK_IN` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_CODE`, `NAME`, `DESCRIPTION`, `QTY_STOCK`, `ON_HAND`, `PRICE`, `CATEGORY_ID`, `SUPPLIER_ID`, `DATE_STOCK_IN`) VALUES
(1, '20191001', 'Lenovo ideapad 20059', 'Windows 8', 1, 1, 32999, 7, 15, '2019-03-02'),
(3, '20191003', 'Predator Helios 300 Gaming Laptop', 'Windows 10 Home\r\nIntelÂ® Coreâ„¢ i7-8750H processor Hexa-core 2.20 GHz\r\n15.6\" Full HD (1920 x 1080) ', 1, 1, 77850, 7, 15, '2019-03-02'),
(4, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-02'),
(5, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 15, '2019-03-03'),
(6, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(8, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-05'),
(9, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(10, '20191004', 'Fantech EG1', 'BEST FOR MOBILE PHONE GAMERS\r\nSPEAKER:10mm\r\nIMPEDANCE: 18+-15%\r\nFREQUENCY RESPONSE: 20 TO 20khz\r\nMICROPHONE : OMNI DIRECTIONAL\r\nJACK: AUDIO+MICROPHONE\r\nCOMBINED JACK 3.5 WIRE\r\nWIRE LENGTH: 1.3M\r\nWhat in inside:-1 pcs Female 3.5mm to Audio and\r\nmicrop', 1, 1, 859, 6, 13, '2019-03-06'),
(11, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(12, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(13, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(14, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(15, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(16, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(17, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(18, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(19, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(20, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(21, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(22, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(23, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(24, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(25, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(26, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(27, '20191005', 'A4tech OP-720', 'normal mouse', 1, 1, 289, 1, 16, '2019-03-13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `supplier`
--

CREATE TABLE `supplier` (
  `SUPPLIER_ID` int(11) NOT NULL,
  `COMPANY_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `supplier`
--

INSERT INTO `supplier` (`SUPPLIER_ID`, `COMPANY_NAME`, `LOCATION_ID`, `PHONE_NUMBER`) VALUES
(11, 'InGame Tech', 114, '09457488521'),
(12, 'Asus', 115, '09635877412'),
(13, 'Razer Co.', 111, '09587855685'),
(15, 'Strategic Technology Co.', 116, '09124033805'),
(16, 'A4tech', 155, '09775673257');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transaction`
--

CREATE TABLE `transaction` (
  `TRANS_ID` int(50) NOT NULL,
  `CUST_ID` int(11) DEFAULT NULL,
  `NUMOFITEMS` varchar(250) NOT NULL,
  `SUBTOTAL` varchar(50) NOT NULL,
  `LESSVAT` varchar(50) NOT NULL,
  `NETVAT` varchar(50) NOT NULL,
  `ADDVAT` varchar(50) NOT NULL,
  `GRANDTOTAL` varchar(250) NOT NULL,
  `CASH` varchar(250) NOT NULL,
  `DATE` varchar(50) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transaction`
--

INSERT INTO `transaction` (`TRANS_ID`, `CUST_ID`, `NUMOFITEMS`, `SUBTOTAL`, `LESSVAT`, `NETVAT`, `ADDVAT`, `GRANDTOTAL`, `CASH`, `DATE`, `TRANS_D_ID`) VALUES
(3, 16, '3', '456,982.00', '48,962.36', '408,019.64', '48,962.36', '456,982.00', '500000', '2019-03-18', '0318160336'),
(4, 11, '2', '1,967.00', '210.75', '1,756.25', '210.75', '1,967.00', '2000', '2019-03-18', '0318160622'),
(5, 14, '1', '550.00', '58.93', '491.07', '58.93', '550.00', '550', '2019-03-18', '0318170309'),
(6, 15, '1', '77,850.00', '8,341.07', '69,508.93', '8,341.07', '77,850.00', '80000', '2019-03-18', '0318170352'),
(7, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170511'),
(8, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170524'),
(9, 14, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170551'),
(10, 11, '1', '289.00', '30.96', '258.04', '30.96', '289.00', '500', '2019-03-18', '0318170624'),
(11, 9, '2', '1,148.00', '123.00', '1,025.00', '123.00', '1,148.00', '2000', '2019-03-18', '0318170825'),
(12, 9, '1', '5,500.00', '589.29', '4,910.71', '589.29', '5,500.00', '6000', '2019-03-18 19:40 pm', '0318194016');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transaction_details`
--

CREATE TABLE `transaction_details` (
  `ID` int(11) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL,
  `PRODUCTS` varchar(250) NOT NULL,
  `QTY` varchar(250) NOT NULL,
  `PRICE` varchar(250) NOT NULL,
  `EMPLOYEE` varchar(250) NOT NULL,
  `ROLE` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `transaction_details`
--

INSERT INTO `transaction_details` (`ID`, `TRANS_D_ID`, `PRODUCTS`, `QTY`, `PRICE`, `EMPLOYEE`, `ROLE`) VALUES
(7, '0318160336', 'Lenovo ideapad 20059', '2', '32999', 'Prince Ly', 'Manager'),
(8, '0318160336', 'Predator Helios 300 Gaming Laptop', '5', '77850', 'Prince Ly', 'Manager'),
(9, '0318160336', 'A4tech OP-720', '6', '289', 'Prince Ly', 'Manager'),
(10, '0318160622', 'Newmen E120', '2', '550', 'Prince Ly', 'Manager'),
(11, '0318160622', 'A4tech OP-720', '3', '289', 'Prince Ly', 'Manager'),
(12, '0318170309', 'Newmen E120', '1', '550', 'Prince Ly', 'Manager'),
(13, '0318170352', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'Prince Ly', 'Manager'),
(14, '0318170511', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(15, '0318170524', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(16, '0318170551', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(17, '0318170624', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(18, '0318170825', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(19, '0318170825', 'Fantech EG1', '1', '859', 'Prince Ly', 'Manager'),
(20, '0318194016', 'Newmen E120', '10', '550', 'Josuey', 'Cashier');

-- --------------------------------------------------------

--
-- Estrutura da tabela `type`
--

CREATE TABLE `type` (
  `TYPE_ID` int(11) NOT NULL,
  `TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `type`
--

INSERT INTO `type` (`TYPE_ID`, `TYPE`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `USERNAME` varchar(50) DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `TYPE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`ID`, `EMPLOYEE_ID`, `USERNAME`, `PASSWORD`, `TYPE_ID`) VALUES
(1, 1, 'unguardable', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1),
(7, 2, 'test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 2),
(9, 4, 'mncpdrnl', '8cb2237d0679ca88db6464eac60da96345513964', 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CATEGORY_ID`);

--
-- Índices para tabela `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CUST_ID`);

--
-- Índices para tabela `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`),
  ADD KEY `JOB_ID` (`JOB_ID`);

--
-- Índices para tabela `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`JOB_ID`);

--
-- Índices para tabela `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- Índices para tabela `manager`
--
ALTER TABLE `manager`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Índices para tabela `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `CATEGORY_ID` (`CATEGORY_ID`),
  ADD KEY `SUPPLIER_ID` (`SUPPLIER_ID`);

--
-- Índices para tabela `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SUPPLIER_ID`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Índices para tabela `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANS_ID`),
  ADD KEY `TRANS_DETAIL_ID` (`TRANS_D_ID`),
  ADD KEY `CUST_ID` (`CUST_ID`);

--
-- Índices para tabela `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TRANS_D_ID` (`TRANS_D_ID`) USING BTREE;

--
-- Índices para tabela `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`TYPE_ID`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TYPE_ID` (`TYPE_ID`),
  ADD KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `category`
--
ALTER TABLE `category`
  MODIFY `CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `customer`
--
ALTER TABLE `customer`
  MODIFY `CUST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `employee`
--
ALTER TABLE `employee`
  MODIFY `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `location`
--
ALTER TABLE `location`
  MODIFY `LOCATION_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT de tabela `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `supplier`
--
ALTER TABLE `supplier`
  MODIFY `SUPPLIER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TRANS_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`JOB_ID`) REFERENCES `job` (`JOB_ID`);

--
-- Limitadores para a tabela `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Limitadores para a tabela `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`SUPPLIER_ID`) REFERENCES `supplier` (`SUPPLIER_ID`);

--
-- Limitadores para a tabela `supplier`
--
ALTER TABLE `supplier`
  ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Limitadores para a tabela `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CUST_ID`) REFERENCES `customer` (`CUST_ID`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`TRANS_D_ID`) REFERENCES `transaction_details` (`TRANS_D_ID`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`TYPE_ID`) REFERENCES `type` (`TYPE_ID`),
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`);
--
-- Banco de dados: `school`
--
CREATE DATABASE IF NOT EXISTS `school` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `school`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_type`
--

CREATE TABLE `users_type` (
  `id` int(11) NOT NULL,
  `name_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_type`
--
ALTER TABLE `users_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users_type`
--
ALTER TABLE `users_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Banco de dados: `stockphp`
--
CREATE DATABASE IF NOT EXISTS `stockphp` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `stockphp`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `dept_details` varchar(255) NOT NULL,
  `added_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`, `password`, `role`, `dept_details`, `added_at`) VALUES
(1, 'Stock Administrator', '12345', 1, 'default stock department', '2018-03-27'),
(2, 'Department 2', '3875', 0, 'Dept 2', '2018-04-05'),
(10, 'Department 3', '12345', 0, 'Dept 3', '2018-04-04'),
(16, 'Department 4', '12345', 0, 'Dept 4', '2018-04-19');

-- --------------------------------------------------------

--
-- Estrutura da tabela `item`
--

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `item_cat` varchar(30) NOT NULL,
  `item_detail` varchar(255) NOT NULL,
  `bill_no` varchar(30) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL DEFAULT 1,
  `supplied_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `item`
--

INSERT INTO `item` (`item_id`, `item_name`, `item_cat`, `item_detail`, `bill_no`, `supplier_id`, `dept_id`, `supplied_at`) VALUES
(465, 'Item One', ' First Category', 'Demo Details 12345', '100', 3, 2, '2021-07-29'),
(466, 'Item Two', ' Second Category', 'Demo Details Demo', '101', 1, 16, '2021-07-29'),
(467, 'Item Three', ' Third Category', 'Demo Item Details', '103', 9, 1, '2021-08-01'),
(468, 'Item Four', ' Fourth Category', 'Demo Details', '104', 3, 1, '2021-08-01'),
(469, 'Item Five', ' Second Category', 'Demo Demo Demo', '105', 2, 1, '2021-08-01'),
(470, 'Item Six', ' Third Category', 'Demo Demo', '106', 2, 1, '2021-08-01'),
(471, 'Item Seven', ' First Category', 'Demo Demo', '107', 6, 1, '2021-08-01'),
(472, 'Item Eight', ' First Category', 'Demo Details', '108', 7, 1, '2021-08-01'),
(473, 'Item Nine', ' Fourth Category', 'Demo Details N', '109', 3, 1, '2021-08-01'),
(474, 'Item Ten', ' Fifth Category', 'This is a demo detail', '110', 5, 1, '2021-08-01'),
(475, 'Item Eleven', ' Fourth Category', 'Demo Details..', '111', 4, 1, '2021-08-01'),
(476, 'Item Twelve', ' Fifth Category', 'Demo Cntn', '112', 6, 1, '2021-08-01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(30) NOT NULL,
  `supplier_details` varchar(255) NOT NULL,
  `added_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `supplier_details`, `added_at`) VALUES
(1, 'Fozzby', '984 Woodstock Drive', '2019-04-12'),
(2, 'Redsupplies', '4407 Jerry Toth Drive', '2019-02-01'),
(3, 'MegaGoods Supplies', '1908 Leo Street', '2020-01-17'),
(4, 'Mooszer Electronics', '1491 Shinn Avenue', '2019-12-06'),
(5, 'AEC Components', '1743 Washburn Street', '2019-12-13'),
(6, 'MG Foods', '2617 Happy Hollow Road', '2019-10-18'),
(7, 'Vista Suppliers', '2820 Sunset Drive', '2019-02-07'),
(8, 'Edens Collection', '4407 Jerry Toth Drive', '2019-03-01'),
(9, 'USPharma', '2781 Leverton Cove Road', '2019-05-04');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `dept_name` (`dept_name`),
  ADD KEY `dept_name_2` (`dept_name`);

--
-- Índices para tabela `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `item_cat` (`item_cat`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `dept_id` (`dept_id`),
  ADD KEY `supplier_id_2` (`supplier_id`);

--
-- Índices para tabela `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`),
  ADD UNIQUE KEY `supplier_name` (`supplier_name`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=477;

--
-- AUTO_INCREMENT de tabela `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `item_ibfk_2` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON UPDATE CASCADE;
--
-- Banco de dados: `studenttransdb`
--
CREATE DATABASE IF NOT EXISTS `studenttransdb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `studenttransdb`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ay`
--

CREATE TABLE `ay` (
  `AY_ID` int(11) NOT NULL,
  `ACADYR` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `class`
--

CREATE TABLE `class` (
  `CLASS_ID` int(11) NOT NULL,
  `CLASS_CODE` varchar(30) NOT NULL,
  `SUBJ_ID` int(11) NOT NULL,
  `INST_ID` int(11) NOT NULL,
  `SYID` int(11) NOT NULL,
  `AY` varchar(11) NOT NULL,
  `DAY` varchar(20) NOT NULL,
  `C_TIME` varchar(11) NOT NULL,
  `IDNO` int(11) NOT NULL,
  `ROOM` varchar(30) NOT NULL DEFAULT 'NONE',
  `SECTION` varchar(30) NOT NULL DEFAULT 'NONE'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `class`
--

INSERT INTO `class` (`CLASS_ID`, `CLASS_CODE`, `SUBJ_ID`, `INST_ID`, `SYID`, `AY`, `DAY`, `C_TIME`, `IDNO`, `ROOM`, `SECTION`) VALUES
(3, 'Spiral Filipino', 438, 1, 0, '2013-2014', 'MWF', '7:30-8:30', 0, 'Room01', 'A'),
(4, 'Spiral English', 439, 1, 0, '2013-2014', 'NONE', 'NONE', 0, 'NONE', 'NONE');

-- --------------------------------------------------------

--
-- Estrutura da tabela `course`
--

CREATE TABLE `course` (
  `COURSE_ID` int(11) NOT NULL,
  `COURSE_NAME` varchar(30) NOT NULL,
  `COURSE_LEVEL` int(11) NOT NULL DEFAULT 1,
  `COURSE_MAJOR` varchar(30) NOT NULL DEFAULT 'None',
  `COURSE_DESC` varchar(255) NOT NULL,
  `DEPT_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `course`
--

INSERT INTO `course` (`COURSE_ID`, `COURSE_NAME`, `COURSE_LEVEL`, `COURSE_MAJOR`, `COURSE_DESC`, `DEPT_ID`) VALUES
(47, 'Grade 7', 7, '', 'Grade 7', 1),
(48, 'Grade 8', 8, '', 'Grade 8 ', 1),
(49, 'Grade 9', 9, '', 'Grade 9', 1),
(50, 'Grade 10', 10, '', 'Grade 10', 1),
(53, 'Grade 11', 11, '', 'Grade 11 ', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `department`
--

CREATE TABLE `department` (
  `DEPT_ID` int(11) NOT NULL,
  `DEPARTMENT_NAME` varchar(30) NOT NULL,
  `DEPARTMENT_DESC` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `department`
--

INSERT INTO `department` (`DEPT_ID`, `DEPARTMENT_NAME`, `DEPARTMENT_DESC`) VALUES
(1, 'High School', 'High School Department');

-- --------------------------------------------------------

--
-- Estrutura da tabela `grades`
--

CREATE TABLE `grades` (
  `GRADE_ID` int(11) NOT NULL,
  `IDNO` int(11) NOT NULL,
  `SUBJ_ID` int(11) NOT NULL,
  `INST_ID` int(11) NOT NULL,
  `SYID` int(30) NOT NULL,
  `FIRST` int(11) NOT NULL,
  `SECOND` int(11) NOT NULL,
  `THIRD` int(11) NOT NULL,
  `FOURTH` int(11) NOT NULL,
  `AVE` float NOT NULL,
  `DAY` varchar(30) NOT NULL,
  `G_TIME` time NOT NULL,
  `ROOM` varchar(30) NOT NULL,
  `REMARKS` text NOT NULL,
  `COMMENT` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `grades`
--

INSERT INTO `grades` (`GRADE_ID`, `IDNO`, `SUBJ_ID`, `INST_ID`, `SYID`, `FIRST`, `SECOND`, `THIRD`, `FOURTH`, `AVE`, `DAY`, `G_TIME`, `ROOM`, `REMARKS`, `COMMENT`) VALUES
(1, 20004277, 438, 0, 0, 0, 0, 0, 0, 0, 'NONE', '00:00:00', '', 'NONE', ''),
(2, 20004277, 439, 0, 0, 0, 0, 0, 0, 0, 'NONE', '00:00:00', '', 'NONE', ''),
(3, 20004207, 438, 0, 0, 0, 0, 0, 0, 0, 'NONE', '00:00:00', '', 'NONE', ''),
(4, 20004207, 439, 0, 0, 0, 0, 0, 0, 0, 'NONE', '00:00:00', '', 'NONE', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `instructor`
--

CREATE TABLE `instructor` (
  `INST_ID` int(30) NOT NULL,
  `INST_FULLNAME` varchar(255) NOT NULL,
  `INST_ADDRESS` varchar(255) NOT NULL,
  `INST_SEX` varchar(20) NOT NULL DEFAULT 'Male',
  `INST_STATUS` varchar(20) NOT NULL DEFAULT 'Single',
  `SPECIALIZATION` text NOT NULL,
  `INST_EMAIL` varchar(255) NOT NULL,
  `EMPLOYMENT_STATUS` varchar(40) NOT NULL DEFAULT 'Probationary'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `instructor`
--

INSERT INTO `instructor` (`INST_ID`, `INST_FULLNAME`, `INST_ADDRESS`, `INST_SEX`, `INST_STATUS`, `SPECIALIZATION`, `INST_EMAIL`, `EMPLOYMENT_STATUS`) VALUES
(1, 'Joken Villanueva', 'Suay Himamaylan City', 'M', 'Single', 'Computer Etc.', 'joken000189561@gmail.com', 'Probationary'),
(2, 'Erick jason Batuto', 'Kabanakalan City', 'M', 'Married', 'Computer ekc...', 'ejbatuto@hotmail.com', 'Regular'),
(3, 'Joel Bagolcol', 'KCC-TC', 'M', 'Single', 'Automotive', 'joel@yahoo.com', 'Probationary');

-- --------------------------------------------------------

--
-- Estrutura da tabela `level`
--

CREATE TABLE `level` (
  `YR_ID` int(11) NOT NULL,
  `LEVEL` varchar(30) NOT NULL,
  `LEVEL_DESCRIPTION` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `major`
--

CREATE TABLE `major` (
  `MAJOR_ID` int(11) NOT NULL,
  `MAJOR` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `major`
--

INSERT INTO `major` (`MAJOR_ID`, `MAJOR`) VALUES
(1, 'English'),
(2, 'General'),
(3, 'Marketing Management'),
(4, 'Financial Management'),
(5, 'Filipino'),
(6, 'Philosophy'),
(7, 'Math');

-- --------------------------------------------------------

--
-- Estrutura da tabela `photo`
--

CREATE TABLE `photo` (
  `PHOTO_ID` int(11) NOT NULL,
  `FILENAME` text NOT NULL,
  `TYPE` varchar(30) NOT NULL,
  `SIZE` int(30) NOT NULL,
  `CAPTION` varchar(255) NOT NULL,
  `IDNO` int(11) NOT NULL,
  `PRIMARY` varchar(20) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `room`
--

CREATE TABLE `room` (
  `ROOM_ID` int(11) NOT NULL,
  `ROOM_NAME` varchar(30) NOT NULL,
  `ROOM_DESC` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `room`
--

INSERT INTO `room` (`ROOM_ID`, `ROOM_NAME`, `ROOM_DESC`) VALUES
(2, 'Room02', 'Room 02'),
(4, 'Room 03', 'Room 03'),
(5, 'Room01', 'Room01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `schoolyr`
--

CREATE TABLE `schoolyr` (
  `SYID` int(11) NOT NULL,
  `AY` varchar(30) NOT NULL,
  `SEMESTER` varchar(20) NOT NULL,
  `COURSE_ID` int(11) NOT NULL,
  `IDNO` int(30) NOT NULL,
  `CATEGORY` varchar(30) NOT NULL DEFAULT 'ENROLLED',
  `DATE_RESERVED` datetime NOT NULL,
  `DATE_ENROLLED` datetime NOT NULL,
  `STATUS` varchar(30) NOT NULL DEFAULT 'New'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `schoolyr`
--

INSERT INTO `schoolyr` (`SYID`, `AY`, `SEMESTER`, `COURSE_ID`, `IDNO`, `CATEGORY`, `DATE_RESERVED`, `DATE_ENROLLED`, `STATUS`) VALUES
(1, '2013-2014', 'First', 47, 20004277, 'ENROLLED', '2014-03-12 02:10:03', '0000-00-00 00:00:00', 'New'),
(2, '2013-2014', 'First', 47, 20004207, 'ENROLLED', '2014-03-12 02:32:19', '0000-00-00 00:00:00', 'New');

-- --------------------------------------------------------

--
-- Estrutura da tabela `semester`
--

CREATE TABLE `semester` (
  `SEM_ID` int(11) NOT NULL,
  `SEM` varchar(15) NOT NULL DEFAULT 'First'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `semester`
--

INSERT INTO `semester` (`SEM_ID`, `SEM`) VALUES
(1, 'First'),
(2, 'Second'),
(3, 'Summer');

-- --------------------------------------------------------

--
-- Estrutura da tabela `studentsubjects`
--

CREATE TABLE `studentsubjects` (
  `STUDSUBJ_ID` int(11) NOT NULL,
  `IDNO` int(11) NOT NULL,
  `SUBJ_ID` int(11) NOT NULL,
  `LEVEL` int(11) NOT NULL,
  `SEMESTER` varchar(30) NOT NULL,
  `SY` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `studentsubjects`
--

INSERT INTO `studentsubjects` (`STUDSUBJ_ID`, `IDNO`, `SUBJ_ID`, `LEVEL`, `SEMESTER`, `SY`) VALUES
(6, 20004207, 11, 1, 'First', '2013-2014'),
(8, 20004207, 13, 1, 'First', '2013-2014'),
(9, 20004207, 14, 1, 'First', '2013-2014'),
(10, 20004207, 15, 1, 'First', '2013-2014'),
(13, 20004277, 13, 1, 'First', '2013-2014'),
(14, 20004277, 14, 1, 'First', '2013-2014'),
(15, 20004277, 15, 1, 'First', '2013-2014');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subject`
--

CREATE TABLE `subject` (
  `SUBJ_ID` int(11) NOT NULL,
  `SUBJ_CODE` varchar(30) NOT NULL,
  `SUBJ_DESCRIPTION` varchar(255) NOT NULL,
  `UNIT` int(2) NOT NULL,
  `PRE_REQUISITE` varchar(30) NOT NULL DEFAULT 'None',
  `COURSE_ID` int(11) NOT NULL,
  `AY` varchar(30) NOT NULL,
  `SEMESTER` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `subject`
--

INSERT INTO `subject` (`SUBJ_ID`, `SUBJ_CODE`, `SUBJ_DESCRIPTION`, `UNIT`, `PRE_REQUISITE`, `COURSE_ID`, `AY`, `SEMESTER`) VALUES
(438, 'Spiral Filipino', 'Filipino for Grade 7 - Spiral Filipino', 3, '', 47, '2013-2014', 'First'),
(439, 'Spiral English', 'English for Grade 7', 3, '', 47, '2013-2014', 'First'),
(440, 'Spiral Mathematics', 'Mathematics for Grade 7 - Spiral Math', 3, '', 47, '2013-2014', 'First'),
(441, 'Spiral Science', 'Science for Grade 7', 3, '', 47, '2013-2014', 'First'),
(442, 'Spiral T.L.E', 'T.L.E for Grade 7', 3, '', 47, '2013-2014', 'First'),
(443, 'Spiral A.P', 'Araling Panlipunan for Grade 7', 3, '', 47, '2013-2014', 'First'),
(444, 'Spiral Religion', 'rekligion for Grade 7', 3, '', 47, '2013-2014', 'First'),
(445, 'Spiral EsP.', 'EsP. for Grade 7', 3, '', 47, '2013-2014', 'First'),
(446, 'MAPEH', 'MAPEH for Grade 8 ', 3, '', 48, '2013-2014', 'First'),
(447, 'MAPEH', 'MAPEH for Grade 7', 3, '', 47, '2013-2014', 'First'),
(448, 'Religion', 'Religion for Grade 8', 3, '', 48, '2013-2014', 'First'),
(449, 'Spiral Filipino', 'Filipino for Grade 8 ', 3, '', 48, '2013-2014', 'First'),
(450, 'Spiral English', 'English for Grade 8', 3, '', 48, '2013-2014', 'First'),
(451, 'Spiral Mathematics', 'Mathematics for Grade 8 ', 3, '', 48, '2013-2014', 'First'),
(452, 'Spiral Science', 'Science for Grade ', 3, '', 48, '2013-2014', 'First'),
(453, 'Spiral T.L.E.', 'T.L.E for Grade 7 ', 3, '', 48, '2013-2014', 'First'),
(454, 'Spiral A.P.', 'Araling Panlipunan for Grade 8', 3, '', 48, '2013-2014', 'First'),
(455, 'Spiral EsP.', 'EsP. for Grade 7', 3, '', 48, '2013-2014', 'First'),
(457, 'Spiral Filipino', 'Filipino for Grade 9', 3, '', 49, '2013-2014', 'First'),
(458, 'Spiral English', 'English for Grade 9', 3, '', 49, '2013-2014', 'First'),
(459, 'Spiral Mathematics', 'Mathematics for Grade 9', 3, '', 49, '2013-2014', 'First'),
(460, 'Spiral Science', 'Science for Grade 9', 3, '', 49, '2013-2014', 'First'),
(461, 'Spiral A.P.', 'Araling Panlipunan for Grade 9', 3, '', 49, '2013-2014', 'First'),
(462, 'Spiral T.L.E.', 'T.L.E for Grade 9', 3, '', 49, '2013-2014', 'First'),
(463, 'Spiral MAPEH', 'MAPEH for Grade 9', 3, '', 49, '2013-2014', 'First'),
(464, 'Values Education', 'Values Education for Grade 9', 3, '', 49, '2013-2014', 'First'),
(465, 'Computer', 'Computer for grade 9', 3, '', 49, '2013-2014', 'First'),
(466, 'Religion IV', 'Religion for Grade 10', 3, '', 50, '2013-2014', 'First'),
(467, 'Spiral Filipino', 'Filipino for Grade 10', 3, '', 50, '2013-2014', 'First'),
(468, 'Spiral Mathematics', 'Mathematics for Grade 10', 3, '', 50, '2013-2014', 'First'),
(469, 'Spiral Science', 'Science for Grade 10', 3, '', 50, '2013-2014', 'First'),
(471, 'Spiral T.L.E.', 'T.L.E for Grade 10', 3, '', 50, '2013-2014', 'First'),
(472, 'Spiral MAPEH', 'MAPEH for Grade 10', 3, '', 50, '2013-2014', 'First'),
(473, 'Values Education', 'Values Education for Grade 10', 3, '', 50, '2013-2014', 'First'),
(474, 'CAT', 'Citizens Advancement Training', 3, '', 50, '2013-2014', 'First'),
(475, 'Computer', 'Computer for grade 10', 3, '', 50, '2013-2014', 'First'),
(476, 'hjgjhggh', 'gj', 3, '', 51, '2013-2014', 'First');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblrequirements`
--

CREATE TABLE `tblrequirements` (
  `REQ_ID` int(30) NOT NULL,
  `NSO` varchar(5) NOT NULL DEFAULT 'no',
  `BAPTISMAL` varchar(5) NOT NULL DEFAULT 'no',
  `ENTRANCE_TEST_RESULT` varchar(5) NOT NULL DEFAULT 'no',
  `MARRIAGE_CONTRACT` varchar(5) NOT NULL DEFAULT 'no',
  `CERTIFICATE_OF_TRANSFER` varchar(5) NOT NULL DEFAULT 'no',
  `IDNO` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tblrequirements`
--

INSERT INTO `tblrequirements` (`REQ_ID`, `NSO`, `BAPTISMAL`, `ENTRANCE_TEST_RESULT`, `MARRIAGE_CONTRACT`, `CERTIFICATE_OF_TRANSFER`, `IDNO`) VALUES
(20, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004277),
(21, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004207),
(22, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004180),
(23, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004425),
(24, 'Yes', 'Yes', 'Yes', 'No', 'No', 20002251),
(25, 'Yes', 'Yes', 'Yes', 'No', 'No', 20002838),
(26, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004623),
(27, 'Yes', 'Yes', 'Yes', 'No', 'No', 2001497),
(28, 'Yes', 'Yes', 'No', 'No', 'No', 20001057),
(29, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004407),
(30, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20004749),
(31, 'Yes', 'Yes', 'No', 'No', 'No', 20001484),
(32, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20003333),
(33, 'Yes', 'Yes', 'Yes', 'No', 'No', 20004510),
(34, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001779),
(35, 'Yes', 'Yes', 'No', 'No', 'No', 20001482),
(36, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001937),
(37, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001648),
(38, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20002408),
(39, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20005936),
(40, 'No', 'No', 'No', 'No', 'No', 20001550),
(41, 'Yes', 'Yes', 'Yes', 'No', 'No', 20002270),
(42, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001932),
(43, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001498),
(45, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001503),
(46, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001925),
(47, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001658),
(48, 'Yes', 'No', 'No', 'No', 'No', 20001550),
(49, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001957),
(50, 'No', 'No', 'No', 'No', 'No', 20001456),
(51, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001673),
(52, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001557),
(53, 'Yes', 'Yes', 'Yes', 'No', 'No', 20002311),
(54, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20001742),
(55, 'Yes', 'Yes', 'Yes', 'No', 'Yes', 20002106),
(56, 'Yes', 'Yes', 'Yes', 'No', 'No', 20001853),
(57, 'Yes', 'Yes', 'No', 'No', 'Yes', 20001645),
(58, 'Yes', 'Yes', 'No', 'Yes', 'No', 123456);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblstuddetails`
--

CREATE TABLE `tblstuddetails` (
  `DETAIL_ID` int(11) NOT NULL,
  `FATHER` varchar(255) NOT NULL,
  `FATHER_OCCU` varchar(255) NOT NULL,
  `MOTHER` varchar(255) NOT NULL,
  `MOTHER_OCCU` varchar(255) NOT NULL,
  `BOARDING` varchar(5) NOT NULL DEFAULT 'no',
  `WITH_FAMILY` varchar(5) NOT NULL DEFAULT 'yes',
  `GUARDIAN` varchar(255) NOT NULL,
  `GUARDIAN_ADDRESS` varchar(255) NOT NULL,
  `OTHER_PERSON_SUPPORT` varchar(255) NOT NULL,
  `ADDRESS` text NOT NULL,
  `IDNO` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tblstuddetails`
--

INSERT INTO `tblstuddetails` (`DETAIL_ID`, `FATHER`, `FATHER_OCCU`, `MOTHER`, `MOTHER_OCCU`, `BOARDING`, `WITH_FAMILY`, `GUARDIAN`, `GUARDIAN_ADDRESS`, `OTHER_PERSON_SUPPORT`, `ADDRESS`, `IDNO`) VALUES
(20, 'Walter Da-anoy', 'Employee', 'Jessielyn Da-anoy', 'Housewife', 'No', 'No', '', '', '', '', 20004277),
(21, 'Mario P. Amparado', 'OFW', 'Yolly D. Odasco', 'Housewife', 'Yes', 'No', 'Domingga Gomez', '', '', '', 20004207),
(22, 'robert P. ferrer', 'fisherman', 'josephene b. ferrer', 'Housewife', 'Yes', 'Yes', 'josephene b ferrer', 'brgy.cayhagan,sipalay city,neg.occ.', 'sister', '', 20004180),
(23, 'Renelio Pintuan', 'Driver', 'Nanette Pintuan', 'OFW', 'No', 'Yes', 'Ma. Melca Jaranilla', 'Coloso St. Kabankalan City', '', '', 20004425),
(24, '', '', 'dionalita apawan', 'housewife', 'No', 'No', 'sofronia apawan', 'adela st. brgy. 1', '', '', 20002251),
(25, 'Pablito Vicente', 'Laborer', 'Crislie Vicente', 'Laborer', 'No', 'Yes', 'Angelo Lopez', 'Coloso Subd. Kabankalan City', '', '', 20002838),
(26, 'Luis Balico', 'N/A', 'Leonisa Balico', 'N/A', 'No', 'Yes', 'Mary Ann Balico', 'Brgy Isidro Village, Talubangi Kabankalan City', 'N/A', '', 20004623),
(27, 'Panfilo Catalan Buendia', 'Vendors', 'Gloria Aspan Buendia', 'Vendors', 'Yes', 'Yes', 'Mr. and Mrs. Gloria Buendia', 'Brgy. Tapi, Kabankalan City', '', '', 2001497),
(28, 'Ramar salazar', 'hair stylist', 'Kathryn Lucy salazar', 'none', 'No', 'Yes', 'DR. MIlagros Aurea Sabidalas ', '12 Rizal St. kabankalan city', '', '', 20001057),
(29, 'Ronald Martisano', 'laxborer', 'Jean Martisano', 'Housewife', 'No', 'Yes', '', '', '', '', 20004407),
(30, 'Rollen Gealon', 'Laborer', 'Marife Gealon', 'Housewife', 'No', 'Yes', 'Mr. & Mrs Rollen Gealon', 'Brgy.2 Ilog, Neg.Occ', '', '', 20004749),
(31, 'James Andrew Benedicto', 'Cook', 'Ma. Sheila Benedicto', 'DH', 'No', 'Yes', '', '', '', '', 20001484),
(32, 'Leve Voluntate', 'Farmer', 'Lerma Voluntate', 'Deceased', 'No', 'Yes', '', '', 'Mr.Von Martir', 'Bacolod City', 20003333),
(33, 'Rudy B. Magada, Jr', 'Fish Dealer', 'Mary I. Magada', 'Housewife', 'No', 'Yes', '', '', 'Ezperanza Magada', 'Libon, Tuyom, Cauayan, Negros Occidental', 20004510),
(34, 'Dionisio C. Herrera', 'Farmer', 'Rubylan O. Herrera', 'plane housewife', 'No', 'Yes', 'Dionisio c. Herrera', 'Mohon Brgy1 . kab city neg occ', '', '', 20001779),
(35, 'Adriano Bayog', 'Farmer', 'Mamerna Dulana', 'housekeeper', 'Yes', 'No', 'Seminary Fathers', 'Kabankalan City', 'Parish', 'La Castellana', 20001482),
(36, 'Ruben J. Principe', '', 'Evelina Gumawa Principe', '', 'No', 'No', '', '', '', '', 20001937),
(37, 'Deceased', 'Deceased', 'Lorna Bandolos', 'Housewife', 'No', 'Yes', '', 'Lorna Bandolos', '', 'Brgy Dancalan Ilog Negros Occidental', 20001648),
(38, 'AMBROCIO SERION', 'FARMER', 'NORMENDA SERION', 'HOUSE WIFE', 'No', 'No', 'JONALYN BUGALON', 'Kabankalan City', 'JONALYN BUGALON', 'KABANKALAN CITY', 20002408),
(39, 'no', '', 'Merlita Macurio', 'housewife', 'No', 'No', 'Gerom Bello', 'Brgy,1 fzo subd.', '', '', 20005936),
(40, 'b', '', '', '', 'No', 'No', '', '', '', '', 20001550),
(41, 'Mr. Edgar C. Macario', 'Farmer', 'Mrs. Hilda F. Macario', 'Housewife', 'No', 'Yes', 'Mrs. Imelda M. Gatoc', 'Cabintagan, Brgy. Linao Kabankalan City, Negros Occidental', 'Mr. Robert C. Macario', 'Brgy. Salong Kabankalan City', 20002270),
(42, 'Virgilio Puyogao', 'Carpenter', 'Angelica Puyogao', 'Housewife', 'No', 'Yes', 'Virgilio Puyogao', 'Dancalan, Ilog, Negros Occidental', 'Annabel Puyogao', 'Dancalan, Ilog, Negros Occidental', 20001932),
(43, 'William Bulgado', 'Driver', 'Lolita Bulgado', 'Housewife', 'Yes', 'Yes', 'William Bulgado', 'magsaysay tabu ilog neg.occ', 'none', 'none', 20001498),
(45, 'Ricardo Tayoba Cabiten', 'Farmer', 'Nelly Cuenca Cabiten', 'Housewife', 'No', 'Yes', 'Nancy Cuenca Cabiten', 'Mambugsay, Cauayan, Negros Occidental', 'Romar Cuenca Cabiten', 'Mambugsay, Cauayan, Negros Occidental', 20001503),
(46, 'Joenarie CastaÃƒÂ±o', 'Laborer', 'Jeanly CastaÃƒÂ±o', 'Housewife', 'No', 'Yes', 'Melinde CastaÃƒÂ±o', 'Brgy. Daan Banua, Kabankalan City', 'None', 'N.A', 20001925),
(47, 'Alex Flores', 'Carpenter', 'Nelfa L. Flores', 'Brgy. Custodian', 'No', 'Yes', 'Nelfa L. Flores', 'Brgy. Camugao, Kabankalan City', 'Maria Elena T. Flores', 'Brgy. Camugao, Kabankalan City', 20001658),
(48, 'BENIGNO B. CORTEZ', 'FARMER', 'TERESITA P. CORTEZ', 'HOUSE WIFE', 'Yes', 'No', 'BENIGNO B. CORTEZ', 'TABUGON,kABANKALAN CITY', 'NONE', 'NONE', 20001550),
(49, 'Samuel Daulong', 'Construction Worker', 'Mariles Daulong', 'Office employee', 'Yes', 'Yes', 'Mariles Daulong', 'Caliling,Cauayan Negros Occidental', 'Henry L. Jordan', 'Brgy. Binicuil, Kabankalan City', 20001957),
(50, 'Diosdado Arillo', 'Employee', 'Jesusa Arillo', 'House Wife', 'Yes', 'No', 'Nilda Jestopa', 'Nilda Jestopa', '', 'Adela St. Kabankalan City', 20001456),
(51, 'Jesus M. Gamala', 'Farmer', 'Carmen N. Gamala', 'Housewife', 'Yes', 'No', 'Saro Yana', 'Bonifacio St.Kabankalan City', 'Jeza Gamala', 'DasmariÃƒÂ±as Cavite', 20001673),
(52, 'Raul D. Deanon', 'Driver', 'Jonah O. Deanon', 'Housewife', 'No', 'Yes', 'Jonah O. Deanon', 'Dancalan Ilog, Neg, Occ', '', '', 20001557),
(53, 'Ernesto Elijan', 'Welder', 'Emilia Elijan', 'Vendor', 'No', 'Yes', 'Ernalyn Elijan Jamon', 'Pinaguinpinan, KAbankalan City', 'Erline Elijan', 'Saudi Rihad', 20002311),
(54, 'Edward E. Geria', 'Seaman', 'Nilfa G. Geria', 'Agriculturist', 'No', 'Yes', 'Nilfa G.Geria', 'Brgy.Guiljungan Cauayan Negros Occidental', '', '', 20001742),
(55, 'Benjie Melanio Sr.', 'Farmer', 'Delia Melanio', 'Housewife', 'No', 'Yes', 'Benjie Melanio', 'Brgy. Linao', '', '', 20002106),
(56, 'Jose Romel T. Silleva', 'Carpenter', 'Daisy O. Silleva', 'House Wife', 'No', 'Yes', 'Daisy O. Silleva', 'Mapait, Su-ay, Himamaylan City, Negros Occidental', 'Romsdaen O. SIlleva', 'iloilo City', 20001853),
(57, 'Dionisio espadero', 'Farming', 'Rosita Espadero', 'House wife', 'No', 'Yes', 'Erlinda Guinson', 'Tapi kab City', 'Sister', 'Tapi kab City', 20001645),
(58, '', '', '', '', 'No', 'No', '', '', '', '', 123456);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblstudent`
--

CREATE TABLE `tblstudent` (
  `S_ID` int(11) NOT NULL,
  `IDNO` int(20) NOT NULL,
  `FNAME` varchar(40) NOT NULL,
  `LNAME` varchar(40) NOT NULL,
  `MNAME` varchar(40) NOT NULL,
  `SEX` varchar(10) NOT NULL DEFAULT 'Male',
  `BDAY` date NOT NULL,
  `BPLACE` text NOT NULL,
  `STATUS` varchar(30) NOT NULL,
  `AGE` int(30) NOT NULL,
  `NATIONALITY` varchar(40) NOT NULL,
  `RELIGION` varchar(255) NOT NULL,
  `CONTACT_NO` varchar(40) NOT NULL,
  `HOME_ADD` text NOT NULL,
  `EMAIL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tblstudent`
--

INSERT INTO `tblstudent` (`S_ID`, `IDNO`, `FNAME`, `LNAME`, `MNAME`, `SEX`, `BDAY`, `BPLACE`, `STATUS`, `AGE`, `NATIONALITY`, `RELIGION`, `CONTACT_NO`, `HOME_ADD`, `EMAIL`) VALUES
(17, 20004277, 'JESTERRAMY', 'DA-ANOY ', 'PATETE', 'F', '1995-06-14', 'Butuan City', 'Single', 19, 'Filipino', 'roman catholic', '9099754195', 'Brgy Camugao Kabankalan City', 'jesterramy14@yahoo.com'),
(18, 20004207, 'LHENYL GRACE', 'AMPARADO', 'ODASCO', 'F', '1995-08-27', 'Lancaan Dasmarinas Cavite', 'Single', 18, 'Filipino', 'roman catholic', '9263621995', 'Yao Yao Cauayan negros Occidental', 'lhenylgraceamparado@yahoo.com'),
(19, 20004180, 'MYLENE', 'FERRER', 'BALUCAN', 'F', '1972-05-22', 'brgy.cayhagan,sipalay city,neg.occ.', 'Single', 18, 'Filipino', 'roman catholic', '91071717257', 'brgy.cayhagan,sipalay city,neg.occ.', 'macaferrer@yahoo.com'),
(20, 20004425, 'JOHN KENNETH', 'PINTUAN', 'JARANILLA', 'M', '1996-05-14', 'PGH Manila', 'Single', 17, 'Filipino', 'Roman Catholic', '9305373831', 'Villa San jose Brgy. 6 Kabankalan City Negros Occidental', 'Pintuan123@yahoo.com'),
(21, 20002251, 'ADRIAN', 'APAWAN', 'ELLORAN', 'M', '1995-10-26', 'bacolod city', 'Single', 18, 'filipino', 'roman catholic', '9128214525', 'adela st. brgy.1', 'pidska_dian@yahoo.com'),
(22, 20002838, 'MARK ANTHONY', 'VICENTE', 'TITONG', 'M', '1995-10-19', 'Kabankalan Cit y', 'Single', 18, 'Filipino', 'Roman Catholic', '+639071564380', '', 'mav.makeu_19@ymail.com'),
(23, 20004623, 'SHARAH MAE', 'BALICO', 'PILLONES', 'F', '1990-11-01', 'Tagoloan Misamis Oriental', 'Single', 23, 'Filipino', 'Catholic', '9216230993', 'Brgy Isidro Village, Talubangi Kabankalan City', 'Sharahmae_balico@yahoo.com'),
(24, 2001497, 'RAFFY', 'BUENDIA', 'RENDON', 'M', '1993-04-13', 'Tapi, Kabankalan City', 'Single', 20, 'Filipino', 'Roman Catholic', '9483774901', 'Brgy. Tapi, Kabankalan City, Negros Occidental', 'Zieken@yahoo.com'),
(25, 20001057, 'EVAN LLOYD', 'SALAZAR', 'AYALIN', 'M', '1995-05-17', 'Kabankalan City', 'Single', 18, 'filipino', 'roman catholic', '9173077451', '12 rizal St.kabankalan CIty', 'Evanlloydsalazar@yahoo.com'),
(26, 20004407, 'JOHN MARK', 'MARTISANO', 'DEPRA', 'M', '1993-06-17', 'Ilog, Neg. Occ', 'Single', 20, 'Pilipino', 'Catholic', '9469080812', 'So. Malabong Andulauan Ilog, Neg. Occ.', 'freestyle05@yahoo.com'),
(27, 20004749, 'JAMAICA JAIRAH', 'GEALON', 'DELA CRUZ', 'F', '1994-01-12', 'Brgy.2 Ilog,Neg.Occ.', 'Single', 19, 'Filipino', 'Roman Catholic', '9089917220', 'Brgy.2 Ilog Negros Occidental', 'gealon12@yahoo.com.ph'),
(28, 20001484, 'JAMES ANGELO', 'BENEDICTO', 'GARANGANAO', 'M', '1993-11-18', 'Bacolod City', 'Single', 20, 'Filipino', 'Catholic', '9305446790', 'Dancalan Ilog, Negros Occidental', 'jamesangelobenedicto@yahoo.com'),
(29, 20003333, 'JENEBIE', 'VOLUNTATE', 'TABUCON', 'F', '1991-06-17', 'Kabankalan', 'Single', 22, 'Filipino', 'Roman Catholic', '9102247024', 'Brgy.Camansi,Kabankalan City,Neg.Occ.', 'jhen1704_cute@yahoo.com'),
(30, 20004510, 'RUDY', 'MAGADA, I', 'ITONA', 'M', '1995-02-05', 'Calumpang, Cauayan, Negros Occidental', 'Single', 18, 'Filipino', 'Roman Catholic', '9106910482', 'Libon, Tuyom, Cauayan, Negros Occidental', 'magadarudy@yahoo.com'),
(31, 20001779, 'JOEVEL', 'HERRERA', 'GONZALES', 'M', '1993-05-16', 'Negros Occidental', 'Single', 20, 'Filipino', 'Roman Catholic', '9093789858', 'Brgy 1,Kab city ,Neg Occ', 'herrerajovel@yahoo.com'),
(32, 20001482, 'ALDREN', 'BAYOG', 'DULANA ', 'M', '1993-12-27', 'La Castellana', 'Single', 20, 'Filipino', 'Roman Catholic', '9077898435', 'Kabankalan City', 'Aldz_bayog@yahoo.com'),
(33, 20001937, 'MERRY GRACE', 'PRINCIPE', 'GUMAWA', 'F', '1988-03-12', 'Candoni', 'Single', 25, 'Filipino', 'Roman Catholic', '9094397440', 'Pabera St.Brgy.East,Candoni, Negros Occidental', 'merrygraceprincipe@yahoo.com'),
(34, 20001648, 'SHIELA MARIE', 'BANDOLOS', 'TADAYA', 'F', '1990-08-21', 'Brgy. Dancalan Ilog Negros Occidental', 'Single', 22, 'Filipino', 'Roman Catholic', '9095596773', 'Brgy. Dancalan Ilog Negros Occidental', 'Marie_Bandolos@yahoo.com'),
(35, 20002408, 'ANALYN', 'SERION', 'ONLAGADA', 'F', '1993-10-30', 'Bry. TAMPALON KABANKALAN CITY', 'Single', 20, 'Filipino', 'Catholic', '9476154838', 'Kabankalan City', 'Analynserion@yahoo.com'),
(36, 20005936, 'JEAN', 'MACURIO', 'GONDAO', 'F', '1994-10-29', 'Brgy.Bantayan', 'Single', 19, 'Filipino', 'Baptist', '9125341710', 'Brgy. Bantayan Kabankalan City', 'jean_29_jake@yahoo.com'),
(37, 20001550, 'BENIGNO', 'CORTEZ', 'LACPAO', 'M', '1992-02-03', 'DUMAGUETE', 'Single', 21, 'FILIPINO', 'BAPTIST', '9097313999', 'TABUGON,KABANKALAN CITY,NEGROS OCCIDENTAL', 'deadlyjay_23@yahoo.com'),
(38, 20002270, 'ARHIL JUN', 'MACARIO', 'FERNANDEZ', 'M', '1993-06-12', 'Cabintagan, Brgy. Linao', 'Single', 20, 'Filipino', 'Roman Catholic', '9489776185', 'Cabintagan, Brgy. Linao Kabankalan City, Negros Occidental', 'elehra_jun_09@yahoo.com'),
(39, 20001932, 'ANA MAE', 'PUYOGAO', 'LACSON', 'F', '1992-10-11', 'Dancalan, Ilog, Neg. Occ', 'Single', 21, 'Filipino', 'Baptist', '9079002850', 'Brgy. Dancalan, Ilog, Negros Occidental', 'puyogaoanamae@yahoo.com'),
(40, 20001498, 'GINA', 'BULGADO', 'MALABAGO', 'F', '1992-06-28', 'Magsaysay tabu ilog ', 'Single', 21, 'Filipino', 'Roman Catholic', '0912-981-4177', 'magsaysay tabu,ilog negros occidental', 'carlghin_52@yahoo.com'),
(42, 20001503, 'RHEA MAY', 'CABITEN', 'CUENCA', 'F', '1992-05-01', 'Mambugsay, Cauayan, Negros Occidental', 'Single', 21, 'Filipino', 'Roman Catholic', '9097862920', 'Mambugsay, Cauayan, Negros Occidental', 'rean7901@gmail.com'),
(43, 20001925, 'JOJEAN', 'CASTAÃ±O', 'SOBERANO', 'F', '1994-09-27', 'Silay City', 'Single', 19, 'Filipino', 'Roman Catholic', '9122543919', 'Brgy. Daan Banua, Kabankalan City', 'Jojean_c@yahoo.com'),
(44, 20001658, 'STEVE', 'FLORES', 'LIPER', 'M', '1993-01-02', 'Brgy. Camugao, Kabankalan City', 'Single', 21, 'Filipino', 'Roman Catholic', '9077659710', 'Brgy. Camugao, Kabankalan City', 'skevinz_23@ymail.com'),
(46, 20001957, 'MA. LAVINIA', 'DAULONG', 'CORSINO', 'F', '1994-06-09', 'Caliling,Cauayan Neg. Occ', 'Single', 19, 'Filipino', 'Roman Catholic', '9073837380', 'Caliling,Cauayan Negros Occidental', 'corsin90@yahoo.com'),
(47, 20001456, 'DIWANNIE', 'ARILLO', 'PAGUNSAN', 'F', '1992-10-12', 'Brgy.Tabugon Kabankalan City Neg. Occ.', 'Single', 21, 'Filipino', 'Roman Catholic', '9484525429', 'Brgy. Tabugon Kabankalan City Neg. Occ.', 'dj_arillo@yahoo.com'),
(48, 20001673, 'CARJEI', 'GAMALA', 'NAZARETH', 'M', '1993-04-28', 'Bulata', 'Single', 20, 'Filipino', 'Catholic', '9484207156', 'Bulata Cauyan Negros Occidental', 'kai_luv@yahoo.com'),
(49, 20001557, 'JENNY JOY', 'DEANON', 'O.', 'F', '1992-12-16', 'Dancalan Ilog,Neg, Occ', 'Single', 22, 'Filipino', 'Roman Catholic', '9466021131', 'Dancalan Ilog Neg,Occ', 'jj_deah16@Yahoo.com'),
(50, 20002311, 'ELSIE', 'ELIJAN', 'TABLIGAN', 'F', '1989-10-08', 'Provincial Hospital Bacolod City', 'Single', 24, 'Filipino', 'Baptist', '9128990012', 'Malinao, Dancalan, Ilog Negros Occidental', 'cute_elz20@yahoo.com'),
(51, 20001742, 'GERGEN MAE', 'GERIA', 'GADOT', 'F', '1994-05-19', 'BAcolod City', 'Single', 19, 'Filipino', 'Roman Catholic', '9129207751', 'Brgy.Guiljungan Cauayan Negros Occidental', 'geriaergenmage@yahoo.com'),
(52, 20002106, 'JEROM', 'MELANIO', 'BANDOLON', 'M', '1992-10-12', 'Kabankalan City', 'Single', 21, 'Filipino', 'Cathilic', '9303950074', 'Brgy. Linao, Kabankalan City', 'melaniojerom@yahoo.com'),
(53, 20001853, 'LIEZL', 'SILLEVA', 'ORDOÃ±A', 'F', '1994-05-19', 'Su-ay', 'Single', 19, 'Pilipino', 'Catholic', '9122319960', 'Mapait, Su-ay, Himamaylan City, Negros Occidental', 'lieztryx_16@yahoo.com'),
(54, 20001645, 'ROSELYN', 'ESPADERO', 'T', 'F', '1989-02-11', 'dancalan ilog', 'Single', 24, 'filipino', 'Catholic', '9122292298', 'tapi kab city', 'roselyt.espadero@yahoo.com'),
(55, 123456, 'KEVIN', 'GARGAR', 'DFD', 'M', '2013-07-13', 'bacolod city', 'Single', 12, '', '', '', '', 'Kev@yahoo.cpm');

-- --------------------------------------------------------

--
-- Estrutura da tabela `useraccounts`
--

CREATE TABLE `useraccounts` (
  `ACCOUNT_ID` int(11) NOT NULL,
  `ACCOUNT_NAME` varchar(255) NOT NULL,
  `ACCOUNT_USERNAME` varchar(255) NOT NULL,
  `ACCOUNT_PASSWORD` text NOT NULL,
  `ACCOUNT_TYPE` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `useraccounts`
--

INSERT INTO `useraccounts` (`ACCOUNT_ID`, `ACCOUNT_NAME`, `ACCOUNT_USERNAME`, `ACCOUNT_PASSWORD`, `ACCOUNT_TYPE`) VALUES
(1, 'Janno Palacios', 'janobe@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Administrator'),
(3, 'Joken Villanueva', 'joken@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Administrator'),
(4, 'Hatch Villanueva', 'hatchvillanueva16@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Registrar'),
(6, 'joenin', 'joenin@yahoo.com', '25f3c6036a19460cd5d3f302fa7b99e5be56cb0e', 'Encoder'),
(7, 'Erick jason Batuto', 'ejbatuto@hotmail.com', 'ee9800e8361e948d0106b38fc6e6311ee238beed', 'Administrator'),
(8, 'joken', 'j@y.c', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Student');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `ay`
--
ALTER TABLE `ay`
  ADD PRIMARY KEY (`AY_ID`),
  ADD UNIQUE KEY `acadyr` (`ACADYR`);

--
-- Índices para tabela `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`CLASS_ID`);

--
-- Índices para tabela `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`COURSE_ID`);

--
-- Índices para tabela `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DEPT_ID`);

--
-- Índices para tabela `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`GRADE_ID`);

--
-- Índices para tabela `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`INST_ID`);

--
-- Índices para tabela `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`YR_ID`);

--
-- Índices para tabela `major`
--
ALTER TABLE `major`
  ADD PRIMARY KEY (`MAJOR_ID`);

--
-- Índices para tabela `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`PHOTO_ID`);

--
-- Índices para tabela `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`ROOM_ID`);

--
-- Índices para tabela `schoolyr`
--
ALTER TABLE `schoolyr`
  ADD PRIMARY KEY (`SYID`);

--
-- Índices para tabela `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`SEM_ID`);

--
-- Índices para tabela `studentsubjects`
--
ALTER TABLE `studentsubjects`
  ADD PRIMARY KEY (`STUDSUBJ_ID`);

--
-- Índices para tabela `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`SUBJ_ID`);

--
-- Índices para tabela `tblrequirements`
--
ALTER TABLE `tblrequirements`
  ADD PRIMARY KEY (`REQ_ID`);

--
-- Índices para tabela `tblstuddetails`
--
ALTER TABLE `tblstuddetails`
  ADD PRIMARY KEY (`DETAIL_ID`);

--
-- Índices para tabela `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`S_ID`),
  ADD UNIQUE KEY `IDNO` (`IDNO`);

--
-- Índices para tabela `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`ACCOUNT_ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `ay`
--
ALTER TABLE `ay`
  MODIFY `AY_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `class`
--
ALTER TABLE `class`
  MODIFY `CLASS_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `course`
--
ALTER TABLE `course`
  MODIFY `COURSE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de tabela `department`
--
ALTER TABLE `department`
  MODIFY `DEPT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `grades`
--
ALTER TABLE `grades`
  MODIFY `GRADE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `instructor`
--
ALTER TABLE `instructor`
  MODIFY `INST_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `level`
--
ALTER TABLE `level`
  MODIFY `YR_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `major`
--
ALTER TABLE `major`
  MODIFY `MAJOR_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `photo`
--
ALTER TABLE `photo`
  MODIFY `PHOTO_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `room`
--
ALTER TABLE `room`
  MODIFY `ROOM_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `schoolyr`
--
ALTER TABLE `schoolyr`
  MODIFY `SYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `semester`
--
ALTER TABLE `semester`
  MODIFY `SEM_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `studentsubjects`
--
ALTER TABLE `studentsubjects`
  MODIFY `STUDSUBJ_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `subject`
--
ALTER TABLE `subject`
  MODIFY `SUBJ_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=477;

--
-- AUTO_INCREMENT de tabela `tblrequirements`
--
ALTER TABLE `tblrequirements`
  MODIFY `REQ_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de tabela `tblstuddetails`
--
ALTER TABLE `tblstuddetails`
  MODIFY `DETAIL_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de tabela `tblstudent`
--
ALTER TABLE `tblstudent`
  MODIFY `S_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de tabela `useraccounts`
--
ALTER TABLE `useraccounts`
  MODIFY `ACCOUNT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Banco de dados: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Banco de dados: `thesis`
--
CREATE DATABASE IF NOT EXISTS `thesis` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `thesis`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `activity_log`
--

CREATE TABLE `activity_log` (
  `activity_log_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(128) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `adminthumbnails` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`admin_id`, `firstname`, `lastname`, `username`, `password`, `adminthumbnails`) VALUES
(4, 'Jonald', 'Sevellejo', 'jonremus', 'me', 'uploads/442048-samsung-galaxy-s5-vs-galaxy-note-3-specs-and-price-comparison-in-austr.jpg'),
(5, 'Hector Neil', 'Cornea', 'admin', 'admin', 'uploads/Sr Hector neil cornea.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `client`
--

CREATE TABLE `client` (
  `client_id` int(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `thumbnails` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `client`
--

INSERT INTO `client` (`client_id`, `username`, `password`, `firstname`, `lastname`, `thumbnails`) VALUES
(10, 'oting', 'oting', 'Reynaldo', 'Tianzon', 'uploads/141113161942-large.jpg'),
(11, 'kiritosan23', 'kirito', 'Joecel', 'Ongsip', 'uploads/10933713_756692371081917_31846816310386324_n.jpg'),
(12, 'asylum1121', 'kevineleven11', 'Kevin Jone', 'Camparecio', 'images/NO-IMAGE-AVAILABLE.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `content`
--

CREATE TABLE `content` (
  `content_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `content`
--

INSERT INTO `content` (`content_id`, `title`, `content`) VALUES
(1, 'Mission', '<pre>\n<span style=\"font-size:16px\"><strong>Mission</strong></span></pre>\n\n<p style=\"text-align:left\"><span style=\"font-family:arial,helvetica,sans-serif; font-size:medium\"><span style=\"font-size:large\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span>&nbsp; &nbsp;<span style=\"font-size:18px\"> &nbsp; &nbsp; &nbsp;Respecting the human dignity and unique talents of each person, Southland College is dedicated in helping its students actualizetheir potentials for the enchancementof their own lives and or nationals Development.&nbsp;</span></p>\n\n<p style=\"text-align:left\">&nbsp;</p>\n'),
(2, 'Vision', '<pre><span style=\"font-size: large;\"><strong>Vision</strong></span></pre>\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"font-size: large;\">&nbsp; A progressive educational community where the individual is at the core of his own learning </span><br /><br /></p>'),
(3, 'History', '<pre><span style=\"font-size: large;\">HISTORY &nbsp;</span> </pre>\n<p style=\"text-align: justify;\"><span style=\"font-family:arial,helvetica,sans-serif; font-size:medium\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The southland college story is the intermingling of imposibilities and unbelief, against optimism and faith.the story of this new school is a beatifull retelling of god\'s goodness; his hands helping shape the foundation of southland college.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Amid Challeges, stumbling blocks, and interfering forces, southland college was established-a shining testamentof God\'s wondrous ways and his helping hand for those who trust in Him.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Deeply saddened by the anticipated mass resignation of the faculty and staff with the change of leadership of a private school where he was the former president, DR. Anecito D. Villaluz, Jr. Decided to put up his own school where he could freely make use of his publicity acknowledged and admired managerial skills and organizational expertise.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the preparations for the new school started in March 2009. The incorporators who compose the Board of directors are Dr.Villaluz, Chairman; Mrs. Annette Z. Villaluz, vice-chairman; Dr. Emiliano L. Sama,Jr.,corporate secretary; Mrs.Yvonne Z. Rocha, Treasurer; and Dr.Rhoda J. Amor,Dr. Grace A. Badrina, Dr. Henly S. Pahilagao, and Mr. Miguel M. Zayco, directors.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The securities and Exchange Commision (DepEd) issurd the school registration permiton March 24,2009.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The department of Education (DepEd) Western Visayas Regional office issued the permit for the basic education on June 1. 2009. The school established the consortium with the Northern Negros state College of Science and Technology (NONESCOST) for the Nursing Degree program, and with the Negros Oriental State Accounting Technology, BS Business Administrators, BS Hospiitality Management, and the 2-year Midwifery course. The administrators, faculty and staff, parents and strengthen the new school. Each of them undertook the assigned task without expecting any personal reward. it was evidend that God is shaping the southland destiny throught the hearts, hands and minds of these people.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Regional Quality Assesment Team (RQUAT) and Commission on Higher Education (CHEd) Supersvisors readily issuad permits for all degree programs After validating the requirements and inspecting the facilities.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The school was formerly launched on May 13, 2009. It was followed by the a grand caravan. The following days saw the advertisements and promotion blitz in variious towns and cities.<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;By the end of the enrolment period, God gave soutland collegeits needed initial number of students. Enrolled during the school year 2009-2010 were: pre school, 69; elementary, 130; and High school, 122. During the first semester of the same school year, college enrolment reached 177. it was an impressive number for a new school which opened within a few months time after its inception.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A thanksgiving service with the theme \"Triumph Amid Trials\" was held on August 28, 2009 morning. It was immediatly followed by the school\'s very first academic convocation. The officers of student councils, faculty and staff club, and the parents and teachers assembleis were inducted in the afternoon. aquaintance parties in all levels followed.<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;amid the trials, Southland College is seen to Survive and Prevail for its story in a tapestry of good relationships, great resposibilities, and God\'s redemption<br/>\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Indeed, at Southland College the foundation of God stand\'s sure!\n</p>'),
(4, 'Footer', '<p style=\"text-align:center\">Technology Resource Inventory System (T.R.S) Copyright 2015</p>\n\n<p style=\"text-align:center\">All Rights Reserved &reg;2015</p>\n'),
(5, 'Title', '<p><span style=\"font-family:trebuchet ms,geneva\">Technology Resource Inventory System</span></p>\n');

-- --------------------------------------------------------

--
-- Estrutura da tabela `device_name`
--

CREATE TABLE `device_name` (
  `dev_id` int(11) NOT NULL,
  `dev_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `device_name`
--

INSERT INTO `device_name` (`dev_id`, `dev_name`) VALUES
(2, 'kyboard'),
(3, 'Power cord'),
(4, 'mouse'),
(5, 'Central Processing unit (CPU)'),
(6, 'AVR'),
(7, 'aircon'),
(8, 'Monitor'),
(9, 'speaker');

-- --------------------------------------------------------

--
-- Estrutura da tabela `location_details`
--

CREATE TABLE `location_details` (
  `ld_id` int(11) NOT NULL,
  `stdev_id` int(11) NOT NULL,
  `date_deployment` date NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL,
  `fullname` varchar(128) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `date_of_notification` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notification_read`
--

CREATE TABLE `notification_read` (
  `notification_read_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_read` varchar(50) NOT NULL,
  `notification_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `stdevice`
--

CREATE TABLE `stdevice` (
  `id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_desc` varchar(128) NOT NULL,
  `dev_serial` varchar(128) NOT NULL,
  `dev_brand` varchar(128) NOT NULL,
  `dev_model` varchar(128) NOT NULL,
  `dev_status` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `stlocation`
--

CREATE TABLE `stlocation` (
  `stdev_id` int(11) NOT NULL,
  `stdev_location_name` varchar(128) NOT NULL,
  `thumbnails` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `stlocation`
--

INSERT INTO `stlocation` (`stdev_id`, `stdev_location_name`, `thumbnails`) VALUES
(22, 'Comlab A', 'images/thumbnails.jpg'),
(23, 'Comlab B', 'images/thumbnails.jpg'),
(24, 'PCID', 'images/thumbnails.jpg'),
(25, 'Library', 'images/thumbnails.jpg'),
(26, 'OSAS', 'images/thumbnails.jpg'),
(27, 'Admin Office', 'images/thumbnails.jpg'),
(28, 'High school', 'images/thumbnails.jpg'),
(29, 'Elementary', 'images/thumbnails.jpg'),
(30, 'Mj Dorm', 'images/thumbnails.jpg'),
(31, 'kcafe', 'images/thumbnails.jpg'),
(34, 'southland clinic', 'images/thumbnails.jpg'),
(35, 'AVH', 'images/thumbnails.jpg'),
(36, 'new location', 'images/thumbnails.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_log`
--

CREATE TABLE `user_log` (
  `user_log_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(128) NOT NULL,
  `admin_id` int(128) NOT NULL,
  `client_id` int(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`activity_log_id`);

--
-- Índices para tabela `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Índices para tabela `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Índices para tabela `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`);

--
-- Índices para tabela `device_name`
--
ALTER TABLE `device_name`
  ADD PRIMARY KEY (`dev_id`);

--
-- Índices para tabela `location_details`
--
ALTER TABLE `location_details`
  ADD PRIMARY KEY (`ld_id`);

--
-- Índices para tabela `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Índices para tabela `notification_read`
--
ALTER TABLE `notification_read`
  ADD PRIMARY KEY (`notification_read_id`);

--
-- Índices para tabela `stdevice`
--
ALTER TABLE `stdevice`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `stlocation`
--
ALTER TABLE `stlocation`
  ADD PRIMARY KEY (`stdev_id`);

--
-- Índices para tabela `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`user_log_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `activity_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=281;

--
-- AUTO_INCREMENT de tabela `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `content`
--
ALTER TABLE `content`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `device_name`
--
ALTER TABLE `device_name`
  MODIFY `dev_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `location_details`
--
ALTER TABLE `location_details`
  MODIFY `ld_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de tabela `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `notification_read`
--
ALTER TABLE `notification_read`
  MODIFY `notification_read_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `stdevice`
--
ALTER TABLE `stdevice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT de tabela `stlocation`
--
ALTER TABLE `stlocation`
  MODIFY `stdev_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `user_log`
--
ALTER TABLE `user_log`
  MODIFY `user_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;
--
-- Banco de dados: `xeninipq_neobank`
--
CREATE DATABASE IF NOT EXISTS `xeninipq_neobank` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `xeninipq_neobank`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `adminuser`
--

CREATE TABLE `adminuser` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin DEFAULT 'https://omniups.money/storage/logounit.png',
  `email` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ewallet_reference_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `contact_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `card_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `card_status` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `adminuser`
--

INSERT INTO `adminuser` (`id`, `first_name`, `last_name`, `image`, `email`, `password`, `created_at`, `ewallet_reference_id`, `country`, `contact_id`, `ewallet_id`, `card_id`, `card_status`, `updated_at`) VALUES
(6, 'Nirav', 'Shah', 'https://omniups.money/storage/logounit.png', 'admin@xenio.in', 'mbWiks+EENfx8bn5CVf49g==', '2021-06-11 02:29:09', 'Omni790518', 'IN', 'cont_5433bb611f116a3f3df3a6d883b70dd6', 'ewallet_3f12273e31fcaf27e8021e4f79191273', '', '', '2021-06-11 02:29:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `apto_card`
--

CREATE TABLE `apto_card` (
  `id` int(11) NOT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `phone_verification_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `apto_user_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `apto_user_token` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `card_program_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `application_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `workflow_object_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `next_action_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `card_account_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `card_network` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `card_last_four` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `agreement_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `payment_source_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `apto_card`
--

INSERT INTO `apto_card` (`id`, `ewallet_id`, `user_id`, `email_id`, `phone_verification_id`, `apto_user_id`, `apto_user_token`, `card_program_id`, `application_id`, `workflow_object_id`, `next_action_id`, `card_account_id`, `card_network`, `card_last_four`, `agreement_id`, `payment_source_id`, `created_at`) VALUES
(46, 'GEEFTO466813', 25, 'business2@xenio.in', 'entity_bf76765e05fd239a', 'crdhldr_c6967ef6dc4e5555a507', 'g4QANsadMvSP8zZIjVgVZqMDd4j0yJd7VmOxal36AsgvydoHMepByzbULxXg3RbiYqrLbwih/Ake0ADQGardHj1/FDRSByKP83GRGYAE5B8=', 'entity_eddeedc0fe61ac8f', 'entity_f3acaa5f3b252989', 'entity_c8edc1e4a39af294', 'entity_03ba958fedb73b97', 'crd_102ee0773cf49e7f', 'MASTERCARD', '5009', NULL, NULL, '2021-10-15 07:08:08');

-- --------------------------------------------------------

--
-- Estrutura da tabela `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `bankname` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `sort_code` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `bic` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `branch` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `iban` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `currency` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `bank_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `ewallet` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `bank_ref_id` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `bank`
--

INSERT INTO `bank` (`id`, `email_id`, `bankname`, `account_number`, `sort_code`, `bic`, `branch`, `iban`, `currency`, `bank_id`, `ewallet`, `bank_ref_id`) VALUES
(6, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'SK5239101098138283691845', 'EUR', 'issuing_06550ce1cf5a8db69d02fbf48d759871', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'Omni52217239730'),
(7, 'nash81@gmail.com', 'CASHDASH UK LIMITED', '2180990064', '197315', 'CAHDGB21', 'E1W 1UN', 'GB1663601973152180990064', 'GBP', 'issuing_5202d5a836d03e1f1269a87c42141e28', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'Omni10186982243'),
(8, 'ashok@xenio.in', 'CASHDASH UK LIMITED', '9159483491', '743988', 'CAHDGB21', 'E1W 1UN', 'GB8452907439889159483491', 'GBP', 'issuing_21575dcd6db8c0570306fd68c1c17f87', 'ewallet_017683299a16a8647646efbd2aa3178a', 'Omni79556905577'),
(9, 'nash81@gmail.com', 'CASHDASH UK LIMITED', '6757608981', '838574', 'CAHDGB21', 'E1W 1UN', 'GB1711048385746757608981', 'GBP', 'issuing_ea840d32df8ada29983fe7ea7d031daa', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'Omni41358805460'),
(10, 'nash81@gmail.com', 'CASHDASH UK LIMITED', '9885071084', '583793', 'CAHDGB21', 'E1W 1UN', 'GB4745535837939885071084', 'GBP', 'issuing_820b660a07b552f4c5ab1c0e176ff73c', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'Omni73693904603');

-- --------------------------------------------------------

--
-- Estrutura da tabela `blog_category`
--

CREATE TABLE `blog_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `is_home` int(11) NOT NULL DEFAULT 0,
  `is_featured` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `business`
--

CREATE TABLE `business` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `title` varchar(255) DEFAULT NULL,
  `biz_number` varchar(255) DEFAULT NULL,
  `vat_code` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `business_type` int(11) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `is_primary` int(11) DEFAULT NULL,
  `is_autoload_amount` int(11) NOT NULL,
  `enable_stock` int(11) DEFAULT 0,
  `template_style` int(11) NOT NULL DEFAULT 1,
  `color` varchar(255) NOT NULL DEFAULT '#546af1',
  `footer_note` text DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `business`
--

INSERT INTO `business` (`id`, `uid`, `user_id`, `name`, `slug`, `type`, `title`, `biz_number`, `vat_code`, `country`, `address`, `category`, `business_type`, `logo`, `status`, `is_primary`, `is_autoload_amount`, `enable_stock`, `template_style`, `color`, `footer_note`, `created_at`) VALUES
(1, '13486', 2, 'Xenio', 'xenio', 1, NULL, NULL, NULL, 79, NULL, '8', NULL, NULL, 0, 1, 0, 0, 5, '#065514', '', NULL),
(2, '54381', 4, 'New test', NULL, 1, 'Test Business', '9326601610', '27AXUPS9409E', 79, 'asdasdasdas', '2', NULL, 'uploads/medium/logotextbk_medium-400x193.png', 1, 1, 0, 0, 1, '#546af1', NULL, NULL),
(3, '51064', 134, 'Xenio - A ASAP Venture', NULL, 1, '', '', '', 79, 'A 604 Teerth Towers\r\nMahalunge\r\nNA', '11', NULL, 'uploads/medium/geeftologo_medium-300x75.png', 1, NULL, 0, 0, 1, '#546af1', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `business_category`
--

CREATE TABLE `business_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `business_category`
--

INSERT INTO `business_category` (`id`, `name`) VALUES
(1, 'Arts, crafts, and collectible'),
(2, 'Baby'),
(3, 'Beauty and fragrances'),
(4, 'Books and magazines'),
(5, 'Business to business'),
(6, 'Clothing, accessories, and shoes'),
(7, 'Web, Computers, accessories, and services'),
(8, 'Education'),
(9, 'Electronics and telecom'),
(10, 'Entertainment and media'),
(11, 'Financial services and products'),
(12, 'Food retail and service'),
(13, 'Gifts and flowers'),
(14, 'Government'),
(15, 'Health and personal care'),
(16, 'Home and garden'),
(17, 'Nonprofit'),
(18, 'Pets and animals'),
(19, 'Religion and spirituality (for profit)'),
(20, 'Retail (not elsewhere classified)'),
(21, 'Services - other'),
(22, 'Sports and outdoors'),
(23, 'Toys and hobbies'),
(24, 'Travel'),
(25, 'Vehicle sales'),
(26, 'Vehicle service and accessories');

-- --------------------------------------------------------

--
-- Estrutura da tabela `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` int(11) DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuration`
--

CREATE TABLE `configuration` (
  `id` int(11) NOT NULL,
  `variable_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `variable_value` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `configuration`
--

INSERT INTO `configuration` (`id`, `variable_name`, `variable_value`) VALUES
(1, '1', 'Xenio - Start your own Neobank today!'),
(2, '4', '3'),
(3, '5', 'zIiywFiLMRBICX/5nN4Gia988BSY7M0IqZz8Krh5MtjoUmrMNciy7CLwMF2NHUnr'),
(4, '6', 'pk_live_9010f8b65386c4be0be1aa83c67f2708'),
(5, '7', 'sk_live_556e21e491891d72d3aec2bd7e9bd79f'),
(6, '8', 'https://api.sbx.aptopayments.com'),
(7, '10', 'Sandbox'),
(8, '9', 'https://api.aptopayments.com'),
(9, '11', 'bal_6165994f80673662'),
(10, '12', 'XENIO'),
(11, '13', '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'),
(12, '14', 'pk_live_51JKZ8RGQbVPqJtjTX0jR6C8tapVsAfnYvZsneQUHpJ8etdY0ZyM46F8xeEoop8kB7gxTz9Ei69wdNVOF1xTNJg9500gxRV4itr'),
(13, '15', 'mail'),
(14, '20', 'Xenio - Start your own Neobank today!'),
(15, '18', 'connect@money.geefto.com'),
(16, '21', 'Xenio - Start your own Neobank today!'),
(17, '22', 'Xenio - Forgot Password'),
(18, '23', '2'),
(19, '24', '12'),
(20, '25', 'support@xenio.in'),
(21, '2', 'storage/893361_449149.png'),
(22, '28', 'Sandbox'),
(23, '26', 'mGFN6arcq8fWIuCbwTwIi2CIBrBjwles'),
(24, '27', 'dwRaq1eO3h-hX5TTo6KfhDYs6KYY7W-pTJB58qSY6S31qfTxpxDgu2hcXQoecjy'),
(25, '29', 'https://topups-sandbox.reloadly.com'),
(26, '30', 'https://topups.reloadly.com'),
(27, '31', 'https://auth.reloadly.com/oauth/token'),
(28, '32', 'LbHqnfSabpgjyG1GOJoijgwclyS7EseL'),
(29, '33', 'CQA0PAu7rt-quGJAJCC2umrZg0jFjk-NiLPNLM27oFm4kJCJOXflOLv4EQTVov3'),
(30, '34', 'Sandbox'),
(31, '35', 'AWgHcTHwrHdRzqGinZvNfX2I4RrfY-xVuQzaAkT34dN1dFX8bv2QG6HmvcPhzQrgSlF1m1DxrrkkMgOK'),
(32, '36', 'EC9u4xd656n9FXPtOEnd_EPioP65h6ZxyzxkFMN8v0EDDDPeKJ8TI__02v0mfSQ0MfLiw9WEbxy6MeAE'),
(33, '37', 'sb-8xa425538396@business.example.com'),
(34, '41', 'https://xenio.in/stripe/payment-success-paypal/'),
(35, '42', 'https://xenio.in/stripe/payment-cancel-paypal/'),
(36, '38', 'AZnzZgYPwjny7Ob4VT9dXyLx1UJ-WGXmnzkM0GMBQWJhuvtL1zc-hRLyHs_gGGoSxQ-PP5rvcZE-zYrI'),
(37, '39', 'EHmoU-UF_NFpk3AqALojtxdQg9Dts42dtY5oApoBCEUUKwH5uRD4ze6qNYkn_6deZE6vsq4qsCXpdSIi'),
(38, '40', 'brickstonecpa@gmail.com'),
(39, '43', 'Start your own Neobank today!'),
(40, '44', 'BANK SMARTER'),
(41, '45', 'Innovative and user friendly banking services for organizations and individuals to bank and make payments with ease and convenience.'),
(42, '46', 'XENIO is a financial solution provider offering neobanking products for financial companies. With XENIO you can start your neobanking services in a matter of hours.'),
(43, '47', 'Tailor made financial solutions');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `iso_alpha2` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `iso_alpha3` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `currency_code` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `currency_name` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `currency_sign` text COLLATE utf8mb4_bin NOT NULL,
  `phone_code` mediumtext COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `countries`
--

INSERT INTO `countries` (`id`, `name`, `iso_alpha2`, `iso_alpha3`, `currency_code`, `currency_name`, `currency_sign`, `phone_code`) VALUES
(33, 'France', 'FR', 'FRA', 'EUR', 'Euro', '€', '33'),
(37, 'Germany', 'DE', 'DEU', 'EUR', 'Euro', '€', '49'),
(48, 'Ireland', 'IE', 'IRL', 'EUR', 'Euro', '€', '353'),
(96, 'Spain', 'ES', 'ESP', 'EUR', 'Euro', '€', '34'),
(104, 'U.K.', 'GB', 'GBR', 'GBP', 'Pound Sterling', '£', '44'),
(106, 'USA', 'US', 'USA', 'USD', 'US Dollar', '$', '1'),
(107, 'Israel', 'IL', 'ISR', 'ILS', 'Israeli New Shekel', '₪', '972'),
(108, 'Austria', 'AT', 'AUT', 'EUR', 'Euro', '€', '43'),
(110, 'Greece', 'GR', 'GRC', 'EUR', 'Euro', '€', '30'),
(111, 'Netherlands', 'NL', 'NLD', 'EUR', 'Euro', '€', '31'),
(112, 'Portugal', 'PT', 'PRT', 'EUR', 'Euro', '€', '351'),
(113, 'Italy', 'IT', 'ITA', 'EUR', 'Euro', '€', '39'),
(116, 'Mexico', 'MX', 'MEX', 'MXN', 'Mexican Peso', '$', '52'),
(120, 'Peru', 'PE', 'PER', 'PEN', 'Nuevo Sol', 'S/', '51'),
(121, 'South Africa', 'ZA', 'ZAF', 'ZAR', 'Rand', 'R', '27'),
(122, 'Thailand', 'TH', 'THA', 'THB', 'Baht', '฿', '66'),
(123, 'Kenya', 'KE', 'KEN', 'KES', 'Kenyan Shilling', 'K', '254'),
(124, 'Brazil', 'BR', 'BRA', 'BRL', 'Brazilian real', 'R$', '55'),
(125, 'Colombia', 'CO', 'COL', 'COP', 'Colombia Peso', '$', '57'),
(132, 'Andorra', 'AD', 'AND', 'EUR', 'Euro', '€', '376'),
(133, 'Angola', 'AO', 'AGO', 'AOA', 'Angolan kwanza', 'Kz', '244'),
(134, 'Anguilla', 'AI', 'AIA', 'XCD', 'East Caribbean dollar', '$', '1264'),
(135, 'Antarctica', 'AQ', 'ATA', 'AUD', 'Australlian Dollar', '$', '672'),
(136, 'Antigua and Barbuda', 'AG', 'ATG', 'XCD', 'East Caribbean dollar', '$', '1268'),
(137, 'Argentina', 'AR', 'ARG', 'ARS', 'Argentine peso', '$', '54'),
(138, 'Armenia', 'AM', 'ARM', 'AMD', 'Armenian dram', '֏', '374'),
(139, 'Aruba', 'AW', 'ABW', 'AWG', 'Aruban florin', 'ƒ', '297'),
(140, 'Australia', 'AU', 'AUS', 'AUD', 'Australlian Dollar', '$', '61'),
(143, 'Azerbaijan', 'AZ', 'AZE', 'AZN', 'Azerbaijani manat', '₼', '994'),
(144, 'Bahamas', 'BS', 'BHS', 'BSD', 'Bahamian dollar', '$', '1242'),
(145, 'Bahrain', 'BH', 'BHR', 'BHD', 'Bahraini dinar', '.د.ب', '973'),
(146, 'Bangladesh', 'BD', 'BGD', 'BDT', 'Bangladeshi taka', '৳', '880'),
(147, 'Barbados', 'BB', 'BRB', 'BBD', 'Barbadian dollar', '$', '1246'),
(149, 'Belgium', 'BE', 'BEL', 'EUR', 'Euro', '€', '32'),
(150, 'Belize', 'BZ', 'BLZ', 'BZD', 'Belize dollar', '$', '501'),
(151, 'Benin', 'BJ', 'BEN', 'XOF', 'West African CFA franc', 'Fr', '229'),
(152, 'Bermuda', 'BM', 'BMU', 'BMD', 'Bermudian dollar', '$', '1441'),
(153, 'Bhutan', 'BT', 'BTN', 'BTN', 'Bhutanese ngultrum', 'Nu.', '975'),
(154, 'Bolivia (Plurinational State of)', 'BO', 'BOL', 'BOB', 'Bolivian boliviano', 'Bs.', '591'),
(155, 'Bonaire, Sint Eustatius and Saba', 'BQ', 'BES', 'USD', 'US Dollar', '$', '5997'),
(156, 'Bosnia and Herzegovina', 'BA', 'BIH', 'BAM', 'Bosnia and Herzegovina convertible mark', 'KM', '387'),
(157, 'Botswana', 'BW', 'BWA', 'BWP', 'Botswana pula', 'P', '267'),
(158, 'Bouvet Island', 'BV', 'BVT', 'NOK', 'Norwegian krone', 'kr', ''),
(160, 'British Indian Ocean Territory', 'IO', 'IOT', 'USD', 'US Dollar', '$', '246'),
(161, 'United States Minor Outlying Islands', 'UM', 'UMI', 'USD', 'US Dollar', '$', ''),
(162, 'Virgin Islands (British)', 'VG', 'VGB', 'USD', 'US Dollar', '$', '1284'),
(163, 'Virgin Islands (U.S.)', 'VI', 'VIR', 'USD', 'US Dollar', '$', '1 340'),
(164, 'Brunei Darussalam', 'BN', 'BRN', 'BND', 'Brunei dollar', '$', '673'),
(165, 'Bulgaria', 'BG', 'BGR', 'BGN', 'Bulgarian lev', 'лв', '359'),
(166, 'Burkina Faso', 'BF', 'BFA', 'XOF', 'West African CFA franc', 'Fr', '226'),
(168, 'Cambodia', 'KH', 'KHM', 'KHR', 'Cambodian riel', '៛', '855'),
(169, 'Cameroon', 'CM', 'CMR', 'XAF', 'Central African CFA franc', 'Fr', '237'),
(170, 'Canada', 'CA', 'CAN', 'CAD', 'Canadian dollar', '$', '1'),
(171, 'Cabo Verde', 'CV', 'CPV', 'CVE', 'Cape Verdean escudo', 'Esc', '238'),
(172, 'Cayman Islands', 'KY', 'CYM', 'KYD', 'Cayman Islands dollar', '$', '1345'),
(174, 'Chad', 'TD', 'TCD', 'XAF', 'Central African CFA franc', 'Fr', '235'),
(175, 'Chile', 'CL', 'CHL', 'CLP', 'Chilean peso', '$', '56'),
(176, 'China', 'CN', 'CHN', 'CNY', 'Chinese yuan', '¥', '86'),
(177, 'Christmas Island', 'CX', 'CXR', 'AUD', 'Australlian Dollar', '$', '61'),
(178, 'Cocos (Keeling) Islands', 'CC', 'CCK', 'AUD', 'Australlian Dollar', '$', '61'),
(180, 'Comoros', 'KM', 'COM', 'KMF', 'Comorian franc', 'Fr', '269'),
(183, 'Cook Islands', 'CK', 'COK', 'NZD', 'New Zealand dollar', '$', '682'),
(184, 'Costa Rica', 'CR', 'CRI', 'CRC', 'Costa Rican colón', '₡', '506'),
(185, 'Croatia', 'HR', 'HRV', 'HRK', 'Croatian kuna', 'kn', '385'),
(187, 'Curaçao', 'CW', 'CUW', 'ANG', 'Netherlands Antillean guilder', 'ƒ', '599'),
(188, 'Cyprus', 'CY', 'CYP', 'EUR', 'Euro', '€', '357'),
(189, 'Czech Republic', 'CZ', 'CZE', 'CZK', 'Czech koruna', 'Kč', '420'),
(190, 'Denmark', 'DK', 'DNK', 'DKK', 'Danish krone', 'kr', '45'),
(191, 'Djibouti', 'DJ', 'DJI', 'DJF', 'Djiboutian franc', 'Fr', '253'),
(192, 'Dominica', 'DM', 'DMA', 'XCD', 'East Caribbean dollar', '$', '1767'),
(193, 'Dominican Republic', 'DO', 'DOM', 'DOP', 'Dominican peso', '$', '1809'),
(194, 'Ecuador', 'EC', 'ECU', 'USD', 'US Dollar', '$', '593'),
(195, 'Egypt', 'EG', 'EGY', 'EGP', 'Egyptian pound', '£', '20'),
(196, 'El Salvador', 'SV', 'SLV', 'USD', 'US Dollar', '$', '503'),
(197, 'Equatorial Guinea', 'GQ', 'GNQ', 'XAF', 'Central African CFA franc', 'Fr', '240'),
(198, 'Eritrea', 'ER', 'ERI', 'ERN', 'Eritrean nakfa', 'Nfk', '291'),
(199, 'Estonia', 'EE', 'EST', 'EUR', 'Euro', '€', '372'),
(200, 'Ethiopia', 'ET', 'ETH', 'ETB', 'Ethiopian birr', 'Br', '251'),
(201, 'Falkland Islands (Malvinas)', 'FK', 'FLK', 'FKP', 'Falkland Islands pound', '£', '500'),
(202, 'Faroe Islands', 'FO', 'FRO', 'DKK', 'Danish krone', 'kr', '298'),
(203, 'Fiji', 'FJ', 'FJI', 'FJD', 'Fijian dollar', '$', '679'),
(204, 'Finland', 'FI', 'FIN', 'EUR', 'Euro', '€', '358'),
(206, 'French Guiana', 'GF', 'GUF', 'EUR', 'Euro', '€', '594'),
(207, 'French Polynesia', 'PF', 'PYF', 'XPF', 'CFP franc', 'Fr', '689'),
(208, 'French Southern Territories', 'TF', 'ATF', 'EUR', 'Euro', '€', ''),
(209, 'Gabon', 'GA', 'GAB', 'XAF', 'Central African CFA franc', 'Fr', '241'),
(210, 'Gambia', 'GM', 'GMB', 'GMD', 'Gambian dalasi', 'D', '220'),
(211, 'Georgia', 'GE', 'GEO', 'GEL', 'Georgian Lari', 'ლ', '995'),
(213, 'Ghana', 'GH', 'GHA', 'GHS', 'Ghanaian cedi', '₵', '233'),
(214, 'Gibraltar', 'GI', 'GIB', 'GIP', 'Gibraltar pound', '£', '350'),
(216, 'Greenland', 'GL', 'GRL', 'DKK', 'Danish krone', 'kr', '299'),
(217, 'Grenada', 'GD', 'GRD', 'XCD', 'East Caribbean dollar', '$', '1473'),
(218, 'Guadeloupe', 'GP', 'GLP', 'EUR', 'Euro', '€', '590'),
(219, 'Guam', 'GU', 'GUM', 'USD', 'US Dollar', '$', '1671'),
(220, 'Guatemala', 'GT', 'GTM', 'GTQ', 'Guatemalan quetzal', 'Q', '502'),
(221, 'Guernsey', 'GG', 'GGY', 'GBP', 'Pound Sterling', '£', '44'),
(222, 'Guinea', 'GN', 'GIN', 'GNF', 'Guinean franc', 'Fr', '224'),
(223, 'Guinea-Bissau', 'GW', 'GNB', 'XOF', 'West African CFA franc', 'Fr', '245'),
(224, 'Guyana', 'GY', 'GUY', 'GYD', 'Guyanese dollar', '$', '592'),
(225, 'Haiti', 'HT', 'HTI', 'HTG', 'Haitian gourde', 'G', '509'),
(226, 'Heard Island and McDonald Islands', 'HM', 'HMD', 'AUD', 'Australlian Dollar', '$', ''),
(227, 'Holy See', 'VA', 'VAT', 'EUR', 'Euro', '€', '379'),
(228, 'Honduras', 'HN', 'HND', 'HNL', 'Honduran lempira', 'L', '504'),
(229, 'Hong Kong', 'HK', 'HKG', 'HKD', 'Hong Kong dollar', '$', '852'),
(230, 'Hungary', 'HU', 'HUN', 'HUF', 'Hungarian forint', 'Ft', '36'),
(231, 'Iceland', 'IS', 'ISL', 'ISK', 'Icelandic króna', 'kr', '354'),
(232, 'India', 'IN', 'IND', 'INR', 'Indian rupee', '₹', '91'),
(233, 'Indonesia', 'ID', 'IDN', 'IDR', 'Indonesian rupiah', 'Rp', '62'),
(234, 'Côte d\'Ivoire', 'CI', 'CIV', 'XOF', 'West African CFA franc', 'Fr', '225'),
(238, 'Isle of Man', 'IM', 'IMN', 'GBP', 'Pound Sterling', '£', '44'),
(241, 'Jamaica', 'JM', 'JAM', 'JMD', 'Jamaican dollar', '$', '1876'),
(242, 'Japan', 'JP', 'JPN', 'JPY', 'Japanese yen', '¥', '81'),
(243, 'Jersey', 'JE', 'JEY', 'GBP', 'Pound Sterling', '£', '44'),
(244, 'Jordan', 'JO', 'JOR', 'JOD', 'Jordanian dinar', 'د.ا', '962'),
(245, 'Kazakhstan', 'KZ', 'KAZ', 'KZT', 'Kazakhstani tenge', '₸', '76'),
(247, 'Kiribati', 'KI', 'KIR', 'AUD', 'Australlian Dollar', '$', '686'),
(248, 'Kuwait', 'KW', 'KWT', 'KWD', 'Kuwaiti dinar', 'د.ك', '965'),
(249, 'Kyrgyzstan', 'KG', 'KGZ', 'KGS', 'Kyrgyzstani som', 'с', '996'),
(250, 'Lao People\'s Democratic Republic', 'LA', 'LAO', 'LAK', 'Lao kip', '₭', '856'),
(251, 'Latvia', 'LV', 'LVA', 'EUR', 'Euro', '€', '371'),
(253, 'Lesotho', 'LS', 'LSO', 'LSL', 'Lesotho loti', 'L', '266'),
(256, 'Liechtenstein', 'LI', 'LIE', 'CHF', 'Swiss franc', 'Fr', '423'),
(257, 'Lithuania', 'LT', 'LTU', 'EUR', 'Euro', '€', '370'),
(258, 'Luxembourg', 'LU', 'LUX', 'EUR', 'Euro', '€', '352'),
(259, 'Macao', 'MO', 'MAC', 'MOP', 'Macanese pataca', 'P', '853'),
(260, 'Macedonia (the former Yugoslav Republic of)', 'MK', 'MKD', 'MKD', 'Macedonian denar', 'ден', '389'),
(261, 'Madagascar', 'MG', 'MDG', 'MGA', 'Malagasy ariary', 'Ar', '261'),
(262, 'Malawi', 'MW', 'MWI', 'MWK', 'Malawian kwacha', 'MK', '265'),
(263, 'Malaysia', 'MY', 'MYS', 'MYR', 'Malaysian ringgit', 'RM', '60'),
(264, 'Maldives', 'MV', 'MDV', 'MVR', 'Maldivian rufiyaa', '.ރ', '960'),
(265, 'Mali', 'ML', 'MLI', 'XOF', 'West African CFA franc', 'Fr', '223'),
(266, 'Malta', 'MT', 'MLT', 'EUR', 'Euro', '€', '356'),
(267, 'Marshall Islands', 'MH', 'MHL', 'USD', 'US Dollar', '$', '692'),
(268, 'Martinique', 'MQ', 'MTQ', 'EUR', 'Euro', '€', '596'),
(269, 'Mauritania', 'MR', 'MRT', 'MRO', 'Mauritanian ouguiya', 'UM', '222'),
(270, 'Mauritius', 'MU', 'MUS', 'MUR', 'Mauritian rupee', '₨', '230'),
(271, 'Mayotte', 'YT', 'MYT', 'EUR', 'Euro', '€', '262'),
(273, 'Micronesia (Federated States of)', 'FM', 'FSM', 'USD', 'US Dollar', '$', '691'),
(274, 'Moldova (Republic of)', 'MD', 'MDA', 'MDL', 'Moldovan leu', 'L', '373'),
(275, 'Monaco', 'MC', 'MCO', 'EUR', 'Euro', '€', '377'),
(276, 'Mongolia', 'MN', 'MNG', 'MNT', 'Mongolian tögrög', '₮', '976'),
(277, 'Montenegro', 'ME', 'MNE', 'EUR', 'Euro', '€', '382'),
(278, 'Montserrat', 'MS', 'MSR', 'XCD', 'East Caribbean dollar', '$', '1664'),
(279, 'Morocco', 'MA', 'MAR', 'MAD', 'Moroccan dirham', 'د.م.', '212'),
(280, 'Mozambique', 'MZ', 'MOZ', 'MZN', 'Mozambican metical', 'MT', '258'),
(281, 'Myanmar', 'MM', 'MMR', 'MMK', 'Burmese kyat', 'Ks', '95'),
(282, 'Namibia', 'NA', 'NAM', 'NAD', 'Namibian dollar', '$', '264'),
(283, 'Nauru', 'NR', 'NRU', 'AUD', 'Australlian Dollar', '$', '674'),
(284, 'Nepal', 'NP', 'NPL', 'NPR', 'Nepalese rupee', '₨', '977'),
(286, 'New Caledonia', 'NC', 'NCL', 'XPF', 'CFP franc', 'Fr', '687'),
(287, 'New Zealand', 'NZ', 'NZL', 'NZD', 'New Zealand dollar', '$', '64'),
(288, 'Nicaragua', 'NI', 'NIC', 'NIO', 'Nicaraguan córdoba', 'C$', '505'),
(289, 'Niger', 'NE', 'NER', 'XOF', 'West African CFA franc', 'Fr', '227'),
(290, 'Nigeria', 'NG', 'NGA', 'NGN', 'Nigerian naira', '₦', '234'),
(291, 'Niue', 'NU', 'NIU', 'NZD', 'New Zealand dollar', '$', '683'),
(292, 'Norfolk Island', 'NF', 'NFK', 'AUD', 'Australlian Dollar', '$', '672'),
(294, 'Northern Mariana Islands', 'MP', 'MNP', 'USD', 'US Dollar', '$', '1670'),
(295, 'Norway', 'NO', 'NOR', 'NOK', 'Norwegian krone', 'kr', '47'),
(296, 'Oman', 'OM', 'OMN', 'OMR', 'Omani rial', 'ر.ع.', '968'),
(297, 'Pakistan', 'PK', 'PAK', 'PKR', 'Pakistani rupee', '₨', '92'),
(300, 'Panama', 'PA', 'PAN', 'PAB', 'Panamanian balboa', 'B/.', '507'),
(301, 'Papua New Guinea', 'PG', 'PNG', 'PGK', 'Papua New Guinean kina', 'K', '675'),
(302, 'Paraguay', 'PY', 'PRY', 'PYG', 'Paraguayan guaraní', '₲', '595'),
(304, 'Philippines', 'PH', 'PHL', 'PHP', 'Philippine peso', '₱', '63'),
(305, 'Pitcairn', 'PN', 'PCN', 'NZD', 'New Zealand dollar', '$', '64'),
(306, 'Poland', 'PL', 'POL', 'PLN', 'Polish złoty', 'zł', '48'),
(308, 'Puerto Rico', 'PR', 'PRI', 'USD', 'US Dollar', '$', '1787'),
(309, 'Qatar', 'QA', 'QAT', 'QAR', 'Qatari riyal', 'ر.ق', '974'),
(310, 'Republic of Kosovo', 'XK', 'KOS', 'EUR', 'Euro', '€', '383'),
(311, 'Réunion', 'RE', 'REU', 'EUR', 'Euro', '€', '262'),
(312, 'Romania', 'RO', 'ROU', 'RON', 'Romanian leu', 'lei', '40'),
(313, 'Russian Federation', 'RU', 'RUS', 'RUB', 'Russian ruble', '₽', '7'),
(314, 'Rwanda', 'RW', 'RWA', 'RWF', 'Rwandan franc', 'Fr', '250'),
(315, 'Saint Barthélemy', 'BL', 'BLM', 'EUR', 'Euro', '€', '590'),
(316, 'Saint Helena, Ascension and Tristan da Cunha', 'SH', 'SHN', 'SHP', 'Saint Helena pound', '£', '290'),
(317, 'Saint Kitts and Nevis', 'KN', 'KNA', 'XCD', 'East Caribbean dollar', '$', '1869'),
(318, 'Saint Lucia', 'LC', 'LCA', 'XCD', 'East Caribbean dollar', '$', '1758'),
(319, 'Saint Martin (French part)', 'MF', 'MAF', 'EUR', 'Euro', '€', '590'),
(320, 'Saint Pierre and Miquelon', 'PM', 'SPM', 'EUR', 'Euro', '€', '508'),
(321, 'Saint Vincent and the Grenadines', 'VC', 'VCT', 'XCD', 'East Caribbean dollar', '$', '1784'),
(322, 'Samoa', 'WS', 'WSM', 'WST', 'Samoan tālā', 'T', '685'),
(323, 'San Marino', 'SM', 'SMR', 'EUR', 'Euro', '€', '378'),
(324, 'Sao Tome and Principe', 'ST', 'STP', 'STD', 'São Tomé and Príncipe dobra', 'Db', '239'),
(325, 'Saudi Arabia', 'SA', 'SAU', 'SAR', 'Saudi riyal', 'ر.س', '966'),
(326, 'Senegal', 'SN', 'SEN', 'XOF', 'West African CFA franc', 'Fr', '221'),
(328, 'Seychelles', 'SC', 'SYC', 'SCR', 'Seychellois rupee', '₨', '248'),
(329, 'Sierra Leone', 'SL', 'SLE', 'SLL', 'Sierra Leonean leone', 'Le', '232'),
(330, 'Singapore', 'SG', 'SGP', 'SGD', 'Singapore dollar', '$', '65'),
(331, 'Sint Maarten (Dutch part)', 'SX', 'SXM', 'ANG', 'Netherlands Antillean guilder', 'ƒ', '1721'),
(332, 'Slovakia', 'SK', 'SVK', 'EUR', 'Euro', '€', '421'),
(333, 'Slovenia', 'SI', 'SVN', 'EUR', 'Euro', '€', '386'),
(334, 'Solomon Islands', 'SB', 'SLB', 'SBD', 'Solomon Islands dollar', '$', '677'),
(338, 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', 'GBP', 'Pound Sterling', '£', '500'),
(339, 'Korea (Republic of)', 'KR', 'KOR', 'KRW', 'South Korean won', '₩', '82'),
(342, 'Sri Lanka', 'LK', 'LKA', 'LKR', 'Sri Lankan rupee', 'Rs', '94'),
(344, 'Suriname', 'SR', 'SUR', 'SRD', 'Surinamese dollar', '$', '597'),
(345, 'Svalbard and Jan Mayen', 'SJ', 'SJM', 'NOK', 'Norwegian krone', 'kr', '4779'),
(346, 'Swaziland', 'SZ', 'SWZ', 'SZL', 'Swazi lilangeni', 'L', '268'),
(347, 'Sweden', 'SE', 'SWE', 'SEK', 'Swedish krona', 'kr', '46'),
(348, 'Switzerland', 'CH', 'CHE', 'CHF', 'Swiss franc', 'Fr', '41'),
(350, 'Taiwan', 'TW', 'TWN', 'TWD', 'New Taiwan dollar', '$', '886'),
(351, 'Tajikistan', 'TJ', 'TJK', 'TJS', 'Tajikistani somoni', 'ЅМ', '992'),
(352, 'Tanzania, United Republic of', 'TZ', 'TZA', 'TZS', 'Tanzanian shilling', 'Sh', '255'),
(354, 'Timor-Leste', 'TL', 'TLS', 'USD', 'US Dollar', '$', '670'),
(355, 'Togo', 'TG', 'TGO', 'XOF', 'West African CFA franc', 'Fr', '228'),
(356, 'Tokelau', 'TK', 'TKL', 'NZD', 'New Zealand dollar', '$', '690'),
(357, 'Tonga', 'TO', 'TON', 'TOP', 'Tongan paʻanga', 'T$', '676'),
(358, 'Trinidad and Tobago', 'TT', 'TTO', 'TTD', 'Trinidad and Tobago dollar', '$', '1868'),
(359, 'Tunisia', 'TN', 'TUN', 'TND', 'Tunisian dinar', 'د.ت', '216'),
(360, 'Turkey', 'TR', 'TUR', 'TRY', 'Turkish lira', '₺', '90'),
(361, 'Turkmenistan', 'TM', 'TKM', 'TMT', 'Turkmenistan manat', 'm', '993'),
(362, 'Turks and Caicos Islands', 'TC', 'TCA', 'USD', 'US Dollar', '$', '1649'),
(363, 'Tuvalu', 'TV', 'TUV', 'AUD', 'Australlian Dollar', '$', '688'),
(364, 'Uganda', 'UG', 'UGA', 'UGX', 'Ugandan shilling', 'Sh', '256'),
(365, 'Ukraine', 'UA', 'UKR', 'UAH', 'Ukrainian hryvnia', '₴', '380'),
(366, 'United Arab Emirates', 'AE', 'ARE', 'AED', 'United Arab Emirates dirham', 'د.إ', '971'),
(368, 'Uruguay', 'UY', 'URY', 'UYU', 'Uruguayan peso', '$', '598'),
(369, 'Uzbekistan', 'UZ', 'UZB', 'UZS', 'Uzbekistani som', 'so\'m', '998'),
(370, 'Vanuatu', 'VU', 'VUT', 'VUV', 'Vanuatu vatu', 'Vt', '678'),
(372, 'Vietnam', 'VN', 'VNM', 'VND', 'Vietnamese đồng', '₫', '84'),
(373, 'Wallis and Futuna', 'WF', 'WLF', 'XPF', 'CFP franc', 'Fr', '681'),
(376, 'Zambia', 'ZM', 'ZMB', 'ZMW', 'Zambian kwacha', 'ZK', '260'),
(378, 'Palau', 'PW', 'PLW', 'USD', 'US Dollar', '$', '680'),
(379, 'Albania', 'AL', 'ALB', 'ALL', 'Albanian lek', 'L', '355');

-- --------------------------------------------------------

--
-- Estrutura da tabela `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` varchar(2) NOT NULL,
  `dial_code` varchar(5) NOT NULL,
  `currency_name` varchar(20) NOT NULL,
  `currency_symbol` varchar(20) NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `user_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `country`
--

INSERT INTO `country` (`id`, `name`, `code`, `dial_code`, `currency_name`, `currency_symbol`, `currency_code`, `user_id`) VALUES
(1, 'Andorra', 'AD', '+376', 'Euro', '€', 'EUR', 0),
(2, 'United Arab Emirates', 'AE', '+971', 'United Arab Emirates', 'د.إ', 'AED', 0),
(3, 'Afghanistan', 'AF', '+93', 'Afghan afghani', '؋', 'AFN', 0),
(4, 'Antigua and Barbuda', 'AG', '+1268', 'East Caribbean dolla', '$', 'XCD', 0),
(5, 'Anguilla', 'AI', '+1264', 'East Caribbean dolla', '$', 'XCD', 0),
(6, 'Albania', 'AL', '+355', 'Albanian lek', 'L', 'ALL', 0),
(7, 'Armenia', 'AM', '+374', 'Armenian dram', '', 'AMD', 0),
(8, 'Angola', 'AO', '+244', 'Angolan kwanza', 'Kz', 'AOA', 0),
(9, 'Argentina', 'AR', '+54', 'Argentine peso', '$', 'ARS', 0),
(10, 'Austria', 'AT', '+43', 'Euro', '€', 'EUR', 0),
(11, 'Australia', 'AU', '+61', 'Australian dollar', '$', 'AUD', 0),
(12, 'Aruba', 'AW', '+297', 'Aruban florin', 'ƒ', 'AWG', 0),
(13, 'Azerbaijan', 'AZ', '+994', 'Azerbaijani manat', '', 'AZN', 0),
(14, 'Barbados', 'BB', '+1246', 'Barbadian dollar', '$', 'BBD', 0),
(15, 'Bangladesh', 'BD', '+880', 'Bangladeshi taka', '৳', 'BDT', 0),
(16, 'Belgium', 'BE', '+32', 'Euro', '€', 'EUR', 0),
(17, 'Burkina Faso', 'BF', '+226', 'West African CFA fra', 'Fr', 'XOF', 0),
(18, 'Bulgaria', 'BG', '+359', 'Bulgarian lev', 'лв', 'BGN', 0),
(19, 'Bahrain', 'BH', '+973', 'Bahraini dinar', '.د.ب', 'BHD', 0),
(20, 'Burundi', 'BI', '+257', 'Burundian franc', 'Fr', 'BIF', 0),
(21, 'Benin', 'BJ', '+229', 'West African CFA fra', 'Fr', 'XOF', 0),
(22, 'Bermuda', 'BM', '+1441', 'Bermudian dollar', '$', 'BMD', 0),
(23, 'Brazil', 'BR', '+55', 'Brazilian real', 'R$', 'BRL', 0),
(24, 'Bhutan', 'BT', '+975', 'Bhutanese ngultrum', 'Nu.', 'BTN', 0),
(25, 'Botswana', 'BW', '+267', 'Botswana pula', 'P', 'BWP', 0),
(26, 'Belarus', 'BY', '+375', 'Belarusian ruble', 'Br', 'BYR', 0),
(27, 'Belize', 'BZ', '+501', 'Belize dollar', '$', 'BZD', 0),
(28, 'Canada', 'CA', '+1', 'Canadian dollar', '$', 'CAD', 0),
(29, 'Switzerland', 'CH', '+41', 'Swiss franc', 'Fr', 'CHF', 0),
(30, 'Cote d\'Ivoire', 'CI', '+225', 'West African CFA fra', 'Fr', 'XOF', 0),
(31, 'Cook Islands', 'CK', '+682', 'New Zealand dollar', '$', 'NZD', 0),
(32, 'Chile', 'CL', '+56', 'Chilean peso', '$', 'CLP', 0),
(33, 'Cameroon', 'CM', '+237', 'Central African CFA ', 'Fr', 'XAF', 0),
(34, 'China', 'CN', '+86', 'Chinese yuan', '¥ or 元', 'CNY', 0),
(35, 'Colombia', 'CO', '+57', 'Colombian peso', '$', 'COP', 0),
(36, 'Costa Rica', 'CR', '+506', 'Costa Rican colón', '₡', 'CRC', 0),
(37, 'Cuba', 'CU', '+53', 'Cuban convertible pe', '$', 'CUC', 0),
(38, 'Cape Verde', 'CV', '+238', 'Cape Verdean escudo', 'Esc or $', 'CVE', 0),
(39, 'Cyprus', 'CY', '+357', 'Euro', '€', 'EUR', 0),
(40, 'Czech Republic', 'CZ', '+420', 'Czech koruna', 'Kč', 'CZK', 0),
(41, 'Germany', 'DE', '+49', 'Euro', '€', 'EUR', 0),
(42, 'Djibouti', 'DJ', '+253', 'Djiboutian franc', 'Fr', 'DJF', 0),
(43, 'Denmark', 'DK', '+45', 'Danish krone', 'kr', 'DKK', 0),
(44, 'Dominica', 'DM', '+1767', 'East Caribbean dolla', '$', 'XCD', 0),
(45, 'Dominican Republic', 'DO', '+1849', 'Dominican peso', '$', 'DOP', 0),
(46, 'Algeria', 'DZ', '+213', 'Algerian dinar', 'د.ج', 'DZD', 0),
(47, 'Ecuador', 'EC', '+593', 'United States dollar', '$', 'USD', 0),
(48, 'Estonia', 'EE', '+372', 'Euro', '€', 'EUR', 0),
(49, 'Egypt', 'EG', '+20', 'Egyptian pound', '£ or ج.م', 'EGP', 0),
(50, 'Eritrea', 'ER', '+291', 'Eritrean nakfa', 'Nfk', 'ERN', 0),
(51, 'Spain', 'ES', '+34', 'Euro', '€', 'EUR', 0),
(52, 'Ethiopia', 'ET', '+251', 'Ethiopian birr', 'Br', 'ETB', 0),
(53, 'Finland', 'FI', '+358', 'Euro', '€', 'EUR', 0),
(54, 'Fiji', 'FJ', '+679', 'Fijian dollar', '$', 'FJD', 0),
(55, 'Faroe Islands', 'FO', '+298', 'Danish krone', 'kr', 'DKK', 0),
(56, 'France', 'FR', '+33', 'Euro', '€', 'EUR', 0),
(57, 'Gabon', 'GA', '+241', 'Central African CFA ', 'Fr', 'XAF', 0),
(58, 'United Kingdom', 'GB', '+44', 'British pound', '£', 'GBP', 0),
(59, 'Grenada', 'GD', '+1473', 'East Caribbean dolla', '$', 'XCD', 0),
(60, 'Georgia', 'GE', '+995', 'Georgian lari', 'ლ', 'GEL', 0),
(61, 'Guernsey', 'GG', '+44', 'British pound', '£', 'GBP', 0),
(62, 'Ghana', 'GH', '+233', 'Ghana cedi', '₵', 'GHS', 0),
(63, 'Gibraltar', 'GI', '+350', 'Gibraltar pound', '£', 'GIP', 0),
(64, 'Guinea', 'GN', '+224', 'Guinean franc', 'Fr', 'GNF', 0),
(65, 'Equatorial Guinea', 'GQ', '+240', 'Central African CFA ', 'Fr', 'XAF', 0),
(66, 'Greece', 'GR', '+30', 'Euro', '€', 'EUR', 0),
(67, 'Guatemala', 'GT', '+502', 'Guatemalan quetzal', 'Q', 'GTQ', 0),
(68, 'Guinea-Bissau', 'GW', '+245', 'West African CFA fra', 'Fr', 'XOF', 0),
(69, 'Guyana', 'GY', '+595', 'Guyanese dollar', '$', 'GYD', 0),
(70, 'Hong Kong', 'HK', '+852', 'Hong Kong dollar', '$', 'HKD', 0),
(71, 'Honduras', 'HN', '+504', 'Honduran lempira', 'L', 'HNL', 0),
(72, 'Croatia', 'HR', '+385', 'Croatian kuna', 'kn', 'HRK', 0),
(73, 'Haiti', 'HT', '+509', 'Haitian gourde', 'G', 'HTG', 0),
(74, 'Hungary', 'HU', '+36', 'Hungarian forint', 'Ft', 'HUF', 0),
(75, 'Indonesia', 'ID', '+62', 'Indonesian rupiah', 'Rp', 'IDR', 0),
(76, 'Ireland', 'IE', '+353', 'Euro', '€', 'EUR', 0),
(77, 'Israel', 'IL', '+972', 'Israeli new shekel', '₪', 'ILS', 0),
(78, 'Isle of Man', 'IM', '+44', 'British pound', '£', 'GBP', 0),
(79, 'India', 'IN', '+91', 'Indian rupee', '₹', 'INR', 0),
(80, 'Iraq', 'IQ', '+964', 'Iraqi dinar', 'ع.د', 'IQD', 0),
(81, 'Iceland', 'IS', '+354', 'Icelandic króna', 'kr', 'ISK', 0),
(82, 'Italy', 'IT', '+39', 'Euro', '€', 'EUR', 0),
(83, 'Jersey', 'JE', '+44', 'British pound', '£', 'GBP', 0),
(84, 'Jamaica', 'JM', '+1876', 'Jamaican dollar', '$', 'JMD', 0),
(85, 'Jordan', 'JO', '+962', 'Jordanian dinar', 'د.ا', 'JOD', 0),
(86, 'Japan', 'JP', '+81', 'Japanese yen', '¥', 'JPY', 0),
(87, 'Kenya', 'KE', '+254', 'Kenyan shilling', 'Sh', 'KES', 0),
(88, 'Kyrgyzstan', 'KG', '+996', 'Kyrgyzstani som', 'лв', 'KGS', 0),
(89, 'Cambodia', 'KH', '+855', 'Cambodian riel', '៛', 'KHR', 0),
(90, 'Kiribati', 'KI', '+686', 'Australian dollar', '$', 'AUD', 0),
(91, 'Comoros', 'KM', '+269', 'Comorian franc', 'Fr', 'KMF', 0),
(92, 'Kuwait', 'KW', '+965', 'Kuwaiti dinar', 'د.ك', 'KWD', 0),
(93, 'Cayman Islands', 'KY', '+ 345', 'Cayman Islands dolla', '$', 'KYD', 0),
(94, 'Kazakhstan', 'KZ', '+7 7', 'Kazakhstani tenge', '', 'KZT', 0),
(95, 'Laos', 'LA', '+856', 'Lao kip', '₭', 'LAK', 0),
(96, 'Lebanon', 'LB', '+961', 'Lebanese pound', 'ل.ل', 'LBP', 0),
(97, 'Saint Lucia', 'LC', '+1758', 'East Caribbean dolla', '$', 'XCD', 0),
(98, 'Liechtenstein', 'LI', '+423', 'Swiss franc', 'Fr', 'CHF', 0),
(99, 'Sri Lanka', 'LK', '+94', 'Sri Lankan rupee', 'Rs or රු', 'LKR', 0),
(100, 'Liberia', 'LR', '+231', 'Liberian dollar', '$', 'LRD', 0),
(101, 'Lesotho', 'LS', '+266', 'Lesotho loti', 'L', 'LSL', 0),
(102, 'Lithuania', 'LT', '+370', 'Euro', '€', 'EUR', 0),
(103, 'Luxembourg', 'LU', '+352', 'Euro', '€', 'EUR', 0),
(104, 'Latvia', 'LV', '+371', 'Euro', '€', 'EUR', 0),
(105, 'Morocco', 'MA', '+212', 'Moroccan dirham', 'د.م.', 'MAD', 0),
(106, 'Monaco', 'MC', '+377', 'Euro', '€', 'EUR', 0),
(107, 'Moldova', 'MD', '+373', 'Moldovan leu', 'L', 'MDL', 0),
(108, 'Montenegro', 'ME', '+382', 'Euro', '€', 'EUR', 0),
(109, 'Madagascar', 'MG', '+261', 'Malagasy ariary', 'Ar', 'MGA', 0),
(110, 'Marshall Islands', 'MH', '+692', 'United States dollar', '$', 'USD', 0),
(111, 'Mali', 'ML', '+223', 'West African CFA fra', 'Fr', 'XOF', 0),
(112, 'Myanmar', 'MM', '+95', 'Burmese kyat', 'Ks', 'MMK', 0),
(113, 'Mongolia', 'MN', '+976', 'Mongolian tögrög', '₮', 'MNT', 0),
(114, 'Mauritania', 'MR', '+222', 'Mauritanian ouguiya', 'UM', 'MRO', 0),
(115, 'Montserrat', 'MS', '+1664', 'East Caribbean dolla', '$', 'XCD', 0),
(116, 'Malta', 'MT', '+356', 'Euro', '€', 'EUR', 0),
(117, 'Mauritius', 'MU', '+230', 'Mauritian rupee', '₨', 'MUR', 0),
(118, 'Maldives', 'MV', '+960', 'Maldivian rufiyaa', '.ރ', 'MVR', 0),
(119, 'Malawi', 'MW', '+265', 'Malawian kwacha', 'MK', 'MWK', 0),
(120, 'Mexico', 'MX', '+52', 'Mexican peso', '$', 'MXN', 0),
(121, 'Malaysia', 'MY', '+60', 'Malaysian ringgit', 'RM', 'MYR', 0),
(122, 'Mozambique', 'MZ', '+258', 'Mozambican metical', 'MT', 'MZN', 0),
(123, 'Namibia', 'NA', '+264', 'Namibian dollar', '$', 'NAD', 0),
(124, 'New Caledonia', 'NC', '+687', 'CFP franc', 'Fr', 'XPF', 0),
(125, 'Niger', 'NE', '+227', 'West African CFA fra', 'Fr', 'XOF', 0),
(126, 'Nigeria', 'NG', '+234', 'Nigerian naira', '₦', 'NGN', 0),
(127, 'Nicaragua', 'NI', '+505', 'Nicaraguan córdoba', 'C$', 'NIO', 0),
(128, 'Netherlands', 'NL', '+31', 'Euro', '€', 'EUR', 0),
(129, 'Norway', 'NO', '+47', 'Norwegian krone', 'kr', 'NOK', 0),
(130, 'Nepal', 'NP', '+977', 'Nepalese rupee', '₨', 'NPR', 0),
(131, 'Nauru', 'NR', '+674', 'Australian dollar', '$', 'AUD', 0),
(132, 'Niue', 'NU', '+683', 'New Zealand dollar', '$', 'NZD', 0),
(133, 'New Zealand', 'NZ', '+64', 'New Zealand dollar', '$', 'NZD', 0),
(134, 'Oman', 'OM', '+968', 'Omani rial', 'ر.ع.', 'OMR', 0),
(135, 'Panama', 'PA', '+507', 'Panamanian balboa', 'B/.', 'PAB', 0),
(136, 'Peru', 'PE', '+51', 'Peruvian nuevo sol', 'S/.', 'PEN', 0),
(137, 'French Polynesia', 'PF', '+689', 'CFP franc', 'Fr', 'XPF', 0),
(138, 'Papua New Guinea', 'PG', '+675', 'Papua New Guinean ki', 'K', 'PGK', 0),
(139, 'Philippines', 'PH', '+63', 'Philippine peso', '₱', 'PHP', 0),
(140, 'Pakistan', 'PK', '+92', 'Pakistani rupee', '₨', 'PKR', 0),
(141, 'Poland', 'PL', '+48', 'Polish z?oty', 'zł', 'PLN', 0),
(142, 'Portugal', 'PT', '+351', 'Euro', '€', 'EUR', 0),
(143, 'Palau', 'PW', '+680', 'Palauan dollar', '$', '', 0),
(144, 'Paraguay', 'PY', '+595', 'Paraguayan guaraní', '₲', 'PYG', 0),
(145, 'Qatar', 'QA', '+974', 'Qatari riyal', 'ر.ق', 'QAR', 0),
(146, 'Romania', 'RO', '+40', 'Romanian leu', 'lei', 'RON', 0),
(147, 'Serbia', 'RS', '+381', 'Serbian dinar', 'дин. or din.', 'RSD', 0),
(148, 'Russia', 'RU', '+7', 'Russian ruble', '', 'RUB', 0),
(149, 'Rwanda', 'RW', '+250', 'Rwandan franc', 'Fr', 'RWF', 0),
(150, 'Saudi Arabia', 'SA', '+966', 'Saudi riyal', 'ر.س', 'SAR', 0),
(151, 'Solomon Islands', 'SB', '+677', 'Solomon Islands doll', '$', 'SBD', 0),
(152, 'Seychelles', 'SC', '+248', 'Seychellois rupee', '₨', 'SCR', 0),
(153, 'Sudan', 'SD', '+249', 'Sudanese pound', 'ج.س.', 'SDG', 0),
(154, 'Sweden', 'SE', '+46', 'Swedish krona', 'kr', 'SEK', 0),
(155, 'Singapore', 'SG', '+65', 'Brunei dollar', '$', 'BND', 0),
(156, 'Slovenia', 'SI', '+386', 'Euro', '€', 'EUR', 0),
(157, 'Slovakia', 'SK', '+421', 'Euro', '€', 'EUR', 0),
(158, 'Sierra Leone', 'SL', '+232', 'Sierra Leonean leone', 'Le', 'SLL', 0),
(159, 'San Marino', 'SM', '+378', 'Euro', '€', 'EUR', 0),
(160, 'Senegal', 'SN', '+221', 'West African CFA fra', 'Fr', 'XOF', 0),
(161, 'Somalia', 'SO', '+252', 'Somali shilling', 'Sh', 'SOS', 0),
(162, 'Suriname', 'SR', '+597', 'Surinamese dollar', '$', 'SRD', 0),
(163, 'El Salvador', 'SV', '+503', 'United States dollar', '$', 'USD', 0),
(164, 'Swaziland', 'SZ', '+268', 'Swazi lilangeni', 'L', 'SZL', 0),
(165, 'Chad', 'TD', '+235', 'Central African CFA ', 'Fr', 'XAF', 0),
(166, 'Togo', 'TG', '+228', 'West African CFA fra', 'Fr', 'XOF', 0),
(167, 'Thailand', 'TH', '+66', 'Thai baht', '฿', 'THB', 0),
(168, 'Tajikistan', 'TJ', '+992', 'Tajikistani somoni', 'ЅМ', 'TJS', 0),
(169, 'Turkmenistan', 'TM', '+993', 'Turkmenistan manat', 'm', 'TMT', 0),
(170, 'Tunisia', 'TN', '+216', 'Tunisian dinar', 'د.ت', 'TND', 0),
(171, 'Tonga', 'TO', '+676', 'Tongan pa?anga', 'T$', 'TOP', 0),
(172, 'Turkey', 'TR', '+90', 'Turkish lira', '', 'TRY', 0),
(173, 'Trinidad and Tobago', 'TT', '+1868', 'Trinidad and Tobago ', '$', 'TTD', 0),
(174, 'Tuvalu', 'TV', '+688', 'Australian dollar', '$', 'AUD', 0),
(175, 'Taiwan', 'TW', '+886', 'New Taiwan dollar', '$', 'TWD', 0),
(176, 'Ukraine', 'UA', '+380', 'Ukrainian hryvnia', '₴', 'UAH', 0),
(177, 'Uganda', 'UG', '+256', 'Ugandan shilling', 'Sh', 'UGX', 0),
(178, 'United States', 'US', '+1', 'United States dollar', '$', 'USD', 0),
(179, 'Uruguay', 'UY', '+598', 'Uruguayan peso', '$', 'UYU', 0),
(180, 'Uzbekistan', 'UZ', '+998', 'Uzbekistani som', '', 'UZS', 0),
(181, 'Vietnam', 'VN', '+84', 'Vietnamese ??ng', '₫', 'VND', 0),
(182, 'Vanuatu', 'VU', '+678', 'Vanuatu vatu', 'Vt', 'VUV', 0),
(183, 'Wallis and Futuna', 'WF', '+681', 'CFP franc', 'Fr', 'XPF', 0),
(184, 'Samoa', 'WS', '+685', 'Samoan t?l?', 'T', 'WST', 0),
(185, 'Yemen', 'YE', '+967', 'Yemeni rial', '﷼', 'YER', 0),
(186, 'South Africa', 'ZA', '+27', 'South African rand', 'R', 'ZAR', 0),
(187, 'Zambia', 'ZM', '+260', 'Zambian kwacha', 'ZK', 'ZMW', 0),
(188, 'Zimbabwe', 'ZW', '+263', 'Botswana pula', 'P', 'BWP', 0),
(189, 'Tanzania', 'TZ', '', 'Tanzanian Shilling', 'TZS', 'TSh', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `cus_number` varchar(255) DEFAULT NULL,
  `vat_code` varchar(255) DEFAULT NULL,
  `city` varchar(11) DEFAULT NULL,
  `postal_code` varchar(11) DEFAULT NULL,
  `address1` mediumtext DEFAULT NULL,
  `address2` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `customers`
--

INSERT INTO `customers` (`id`, `user_id`, `business_id`, `name`, `email`, `phone`, `thumb`, `address`, `country`, `currency`, `cus_number`, `vat_code`, `city`, `postal_code`, `address1`, `address2`, `status`, `created_at`) VALUES
(1, 2, 13486, 'Nash', NULL, NULL, NULL, NULL, 79, 'INR', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `category` int(11) DEFAULT NULL,
  `vendor` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `net_amount` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `is_home` int(11) DEFAULT 0,
  `orders` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `google_fonts`
--

CREATE TABLE `google_fonts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT 1 COMMENT 'invoice = 1 & estimates = 2',
  `recurring` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `poso_number` varchar(255) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `payment_due` date DEFAULT NULL,
  `expire_on` date DEFAULT NULL,
  `due_limit` int(11) DEFAULT NULL,
  `footer_note` mediumtext DEFAULT NULL,
  `sub_total` decimal(10,2) DEFAULT NULL,
  `grand_total` decimal(10,2) DEFAULT NULL,
  `convert_total` decimal(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `reject_reason` text DEFAULT NULL,
  `client_action_date` date DEFAULT NULL,
  `is_sent` int(11) DEFAULT 0,
  `is_completed` int(11) NOT NULL DEFAULT 0,
  `sent_date` datetime DEFAULT NULL,
  `recurring_start` date DEFAULT NULL,
  `recurring_end` date DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `next_payment` date DEFAULT NULL,
  `frequency_count` int(11) NOT NULL DEFAULT 0,
  `is_view` int(11) DEFAULT NULL,
  `view_date` datetime DEFAULT NULL,
  `auto_send` int(11) DEFAULT 0,
  `send_myself` int(11) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `invoice`
--

INSERT INTO `invoice` (`id`, `user_id`, `business_id`, `title`, `type`, `recurring`, `parent_id`, `summary`, `number`, `poso_number`, `customer`, `date`, `discount`, `payment_due`, `expire_on`, `due_limit`, `footer_note`, `sub_total`, `grand_total`, `convert_total`, `status`, `reject_reason`, `client_action_date`, `is_sent`, `is_completed`, `sent_date`, `recurring_start`, `recurring_end`, `frequency`, `next_payment`, `frequency_count`, `is_view`, `view_date`, `auto_send`, `send_myself`, `created_at`) VALUES
(1, 2, 13486, '', 2, 0, NULL, '', '2021-1', '', 1, '2021-07-16', 5, NULL, '2021-07-16', NULL, '', '20.00', '19.00', '0.00', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, '2021-07-16 08:02:07'),
(2, 2, 13486, '', 1, 0, NULL, '', '2021-1', '', 1, '2021-07-26', 0, '2021-07-26', NULL, 1, '', '2500.00', '2500.00', '2500.00', 2, NULL, NULL, 1, 0, '2021-08-16 20:31:38', NULL, NULL, NULL, NULL, 0, 1, '2021-08-17 11:10:24', 0, NULL, '2021-07-26 23:54:48'),
(3, 2, 13486, '', 1, 0, NULL, '', '2021-2', '', 1, '2021-08-16', 0, '2021-08-31', NULL, 1, '', '500.00', '500.00', '500.00', 1, NULL, NULL, 1, 0, '2021-08-16 20:33:14', NULL, NULL, NULL, NULL, 0, 1, '2021-08-23 08:58:45', 0, NULL, '2021-08-16 20:31:42'),
(4, 2, 13486, '', 1, 0, NULL, '', '2021-3', '', 1, '2021-08-16', 0, '2021-08-16', NULL, 1, '', '6000.00', '6000.00', '6000.00', 1, NULL, NULL, 1, 0, '2021-08-24 06:55:06', NULL, NULL, NULL, NULL, 0, 1, '2021-08-24 07:01:24', 0, NULL, '2021-08-16 20:42:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `item` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `item`, `details`, `qty`, `price`, `total`, `type`) VALUES
(1, 1, 1, 'Please', 1, '20.00', '20.00', NULL),
(3, 2, 1, 'Test', 5, '500.00', '2500.00', NULL),
(4, 3, 1, '', 1, '500.00', '500.00', NULL),
(5, 4, 1, '', 1, '6000.00', '6000.00', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `invoice_payment_record`
--

CREATE TABLE `invoice_payment_record` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `invoice_taxes`
--

CREATE TABLE `invoice_taxes` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `text_direction` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `language`
--

INSERT INTO `language` (`id`, `name`, `slug`, `short_name`, `code`, `text_direction`, `status`) VALUES
(1, 'English', 'english', 'en', '', 'ltr', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `lang_values`
--

CREATE TABLE `lang_values` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `english` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `lang_values`
--

INSERT INTO `lang_values` (`id`, `type`, `label`, `keyword`, `english`) VALUES
(1, 'user', 'Dashboard', 'dashboard', 'Dashboard'),
(2, 'user', 'Settings', 'settings', 'Settings'),
(3, 'user', 'Customers', 'customers', 'Customers'),
(4, 'user', 'Categories', 'categories', 'Categories'),
(5, 'user', 'Tax', 'tax', 'Tax'),
(6, 'user', 'Products', 'products', 'Products'),
(7, 'user', 'Estimates', 'estimates', 'Estimates'),
(8, 'user', 'Invoices', 'invoices', 'Invoices'),
(9, 'user', 'Recurring Invoice', 'recurring-invoice', 'Recurring Invoice'),
(10, 'user', 'Vendors', 'vendors', 'Vendors'),
(11, 'user', 'Expense', 'expense', 'Expense'),
(12, 'user', 'Subscription', 'subscription', 'Subscription'),
(13, 'user', 'Reports', 'reports', 'Reports'),
(14, 'user', 'Change Password', 'change-password', 'Change Password'),
(15, 'user', 'logout', 'logout', 'logout'),
(16, 'user', 'Upgrade', 'upgrade', 'Upgrade'),
(17, 'user', 'Income & Expenses ', 'income-expenses', 'Income & Expenses '),
(18, 'user', 'Net Income', 'net-income', 'Net Income'),
(19, 'user', 'Fiscal year ', 'fiscal-year', 'Fiscal year '),
(20, 'user', 'Overdue Invoices', 'overdue-invoices', 'Overdue Invoices'),
(21, 'user', ' Customer', 'customer', ' Customer'),
(22, 'user', 'Amount', 'amount', 'Amount'),
(23, 'user', 'All Customer', 'all-customer', 'All Customer'),
(24, 'user', 'All status', 'all-status', 'All status'),
(25, 'user', 'From ', 'from', 'From '),
(26, 'user', 'To ', 'to', 'To '),
(27, 'user', 'Status', 'status', 'Status'),
(28, 'user', 'Date', 'date', 'Date'),
(29, 'user', 'Number', 'number', 'Number'),
(30, 'user', 'Total', 'total', 'Total'),
(31, 'user', 'Amount Due', 'amount-due', 'Amount Due'),
(32, 'user', 'Actions', 'actions', 'Actions'),
(33, 'user', 'Record a payment', 'record-a-payment', 'Record a payment'),
(34, 'user', 'More', 'more', 'More'),
(35, 'user', 'Record a payment for this invoice', 'record-a-payment-for-this-invoice', 'Record a payment for this invoice'),
(36, 'user', 'Record a payment you’ve already received, such as cash, cheque, or bank payment.', 'record-payment-info', 'Record a payment you’ve already received, such as cash, cheque, or bank payment.'),
(37, 'user', 'Payment date', 'payment-date', 'Payment date'),
(38, 'user', 'Payment due date', 'payment-due-date', 'Payment due date'),
(39, 'user', 'Payment method', 'payment-method', 'Payment method'),
(40, 'user', 'Memo / Notes', 'memo-notes', 'Memo / Notes'),
(41, 'user', 'Add Payment', 'add-payment', 'Add Payment'),
(42, 'user', 'Create New Invoices', 'create-new-invoices', 'Create New Invoice'),
(43, 'user', 'Add Vendor', 'add-vendor', 'Add Vendor'),
(44, 'user', 'Add Product', 'add-product', 'Add Product'),
(45, 'user', 'Add Customer ', 'add-customer', 'Add Customer '),
(46, 'user', 'Create new Bill', 'create-new-bill', 'Create new Bill'),
(47, 'user', 'Create new Estimate', 'create-new-estimate', 'Create new Estimate'),
(48, 'user', 'Create new Invoice', 'create-new-invoice', 'Create new Invoice'),
(49, 'user', 'Recurring', 'recurring', 'Recurring'),
(50, 'user', 'Draft', 'draft', 'Draft'),
(51, 'user', 'Invoice', 'invoice', 'Invoice'),
(52, 'user', 'Edit', 'edit', 'Edit'),
(53, 'user', 'More Actions', 'more-actions', 'More Actions'),
(54, 'user', 'Created', 'created', 'Created'),
(55, 'user', 'Send invoice', 'send-invoice', 'Send invoice'),
(56, 'user', 'Invoice To', 'invoice-to', 'Invoice To'),
(57, 'user', 'Subject', 'subject', 'Subject'),
(58, 'user', 'Message', 'message', 'Message'),
(59, 'user', 'Close', 'close', 'Close'),
(60, 'user', 'Send', 'send', 'Send'),
(61, 'user', 'Items', 'items', 'Items'),
(62, 'user', 'Price', 'price', 'Price'),
(63, 'user', 'Quantity', 'quantity', 'Quantity'),
(64, 'user', 'New Invoice', 'new-invoice', 'New Invoice'),
(65, 'user', 'Last sent', 'last-sent', 'Last sent'),
(66, 'user', 'General Settings', 'general-settings', 'General Settings'),
(67, 'user', 'Business', 'business', 'Business'),
(68, 'user', 'Invoice Customization', 'invoice-customization', 'Invoice Customization'),
(69, 'user', 'Choose invoice templates', 'choose-invoice-templates', 'Choose invoice templates'),
(70, 'user', 'Accent color', 'accent-color', 'Accent color'),
(71, 'user', 'Personal Information', 'personal-information', 'Personal Information'),
(72, 'user', 'Name', 'name', 'Name'),
(73, 'user', 'Country', 'country', 'Country'),
(74, 'user', 'City', 'city', 'City'),
(75, 'user', 'State', 'state', 'State'),
(76, 'user', 'Postcode', 'postcode', 'Postcode'),
(77, 'user', 'Adderss', 'adderss', 'Adderss'),
(78, 'user', 'Old Password', 'old-password', 'Old Password'),
(79, 'user', 'New Password', 'new-password', 'New Password'),
(80, 'user', 'Confirm New Password', 'confirm-new-password', 'Confirm New Password'),
(81, 'user', 'Change', 'change', 'Change'),
(82, 'user', 'Logo', 'logo', 'Logo'),
(83, 'user', 'Information', 'information', 'Information'),
(84, 'user', 'Action', 'action', 'Action'),
(85, 'user', 'Add New business', 'add-new-business', 'Add New business'),
(86, 'user', 'Back', 'back', 'Back'),
(87, 'user', 'Name *', 'name-', 'Name *'),
(88, 'user', 'Title', 'title', 'Title'),
(89, 'user', 'Address', 'address', 'Address'),
(90, 'user', 'This is your reporting currency and cannot be changed. You can still send invoices, track expenses and enter transactions in any currency and an exchange rate is applied for you.', 'currency-notice', 'This is your reporting currency and cannot be changed. You can still send invoices, track expenses and enter transactions in any currency and an exchange rate is applied for you.'),
(91, 'user', 'Save business', 'save-business', 'Save business'),
(92, 'user', 'Upload Business logo', 'upload-business-logo', 'Upload Business logo'),
(93, 'user', 'Default', 'default', 'Default'),
(94, 'user', 'Sat Default', 'sat-default', 'Sat Default'),
(95, 'user', 'All customers', 'all-customers', 'All customers'),
(96, 'user', 'Show entries', 'show-entries', 'Show entries'),
(97, 'user', 'Email', 'email', 'Email'),
(98, 'user', 'Info', 'info', 'Info'),
(99, 'user', 'Phone', 'phone', 'Phone'),
(100, 'user', 'Added', 'added', 'Added'),
(101, 'user', 'Edit customer', 'edit-customer', 'Edit customer'),
(102, 'user', 'Customer Name', 'customer-name', 'Customer Name'),
(103, 'user', 'Billing Information', 'billing-information', 'Billing Information'),
(104, 'user', 'Currency', 'currency', 'Currency'),
(105, 'user', 'Postal / Zip code', 'postal-zip-code', 'Postal / Zip code'),
(106, 'user', 'Address 1', 'address-1', 'Address 1'),
(107, 'user', 'Address 2', 'address-2', 'Address 2'),
(108, 'user', 'Previous', 'previous', 'Previous'),
(109, 'user', 'Next', 'next', 'Next'),
(110, 'user', 'Search', 'search', 'Search'),
(111, 'user', 'Showing ', 'showing', 'Showing '),
(112, 'user', 'entries', 'entries', 'entries'),
(113, 'user', 'Type', 'type', 'Type'),
(114, 'user', 'Edit Category', 'edit-category', 'Edit Category'),
(115, 'user', 'Category Name', 'category-name', 'Category Name'),
(116, 'user', 'Add new category', 'add-new-category', 'Add new category'),
(117, 'user', 'All tax', 'all-tax', 'All tax'),
(118, 'user', 'Rate', 'rate', 'Rate'),
(119, 'user', 'Add new tax', 'add-new-tax', 'Add new tax'),
(120, 'user', 'Tax Name', 'tax-name', 'Tax Name'),
(121, 'user', 'Tax Rate ', 'tax-rate', 'Tax Rate '),
(122, 'user', 'Tax rate should be a number only, without a percent sign', 'tax-rate-info', 'Tax rate should be a number only, without a percent sign'),
(123, 'user', 'Tax Number / ID', 'tax-number-id', 'Tax Number / ID'),
(124, 'user', 'Details', 'details', 'Details'),
(125, 'user', 'Save tax ', 'save-tax', 'Save tax '),
(126, 'user', 'Show the tax Number on invoices', 'show-the-tax-number-on-invoices', 'Show the tax name on invoices'),
(127, 'user', 'Products & Services', 'products-services', 'Products & Services'),
(128, 'user', 'New Estimates', 'new-estimates', 'New Estimate'),
(129, 'user', 'All Estimate', 'all-estimate', 'All Estimate'),
(130, 'user', ' Iconic', 'iconic', ' Iconic'),
(131, 'user', ' United States', 'united-states', ' United States'),
(132, 'user', 'Estimate to', 'estimate-to', 'Estimate to'),
(133, 'user', 'Estimate number', 'estimate-number', 'Estimate number'),
(134, 'user', 'P.O./S.O. number', 'p.o.s.o.-number', 'P.O./S.O. number'),
(135, 'user', 'Estimate date', 'estimate-date', 'Estimate date'),
(136, 'user', 'Expires on', 'expires-on', 'Expires on'),
(137, 'user', 'Item', 'item', 'Item'),
(138, 'user', 'Add am customers', 'add-am-customers', 'Add am customers'),
(139, 'user', 'Add an item', 'add-an-item', 'Add an item'),
(140, 'user', 'Sub Total', 'sub-total', 'Sub Total'),
(141, 'user', 'Discount', 'discount', 'Discount'),
(142, 'user', 'Grand Total', 'grand-total', 'Grand Total'),
(143, 'user', 'Footer', 'footer', 'Footer'),
(144, 'user', 'Save Estimate', 'save-estimate', 'Save Estimate'),
(145, 'user', 'More Action ', 'more-action', 'More Action '),
(146, 'user', 'Your subscription', 'your-subscription', 'Your subscription'),
(147, 'user', 'Premium Plan', 'premium-plan', 'Premium Plan'),
(148, 'user', 'Billing Frequency', 'billing-frequency', 'Billing Frequency'),
(149, 'user', 'Last Billing', 'last-billing', 'Last Billing'),
(150, 'user', 'Next Billing', 'next-billing', 'Next Billing'),
(151, 'user', 'Upgrade Plan', 'upgrade-plan', 'Upgrade Plan'),
(152, 'user', 'Basic', 'basic', 'Basic'),
(153, 'user', 'Standard', 'standard', 'Standard'),
(154, 'user', 'Premium', 'premium', 'Premium'),
(155, 'user', 'Downgrade', 'downgrade', 'Downgrade'),
(156, 'user', 'Add new vendor', 'add-new-vendor', 'Add new vendor'),
(157, 'user', 'Vendor Name', 'vendor-name', 'Vendor Name'),
(158, 'user', 'Save vendor', 'save-vendor', 'Save vendor'),
(159, 'user', 'Add New Expenses', 'add-new-expenses', 'Add New Expenses'),
(160, 'user', 'Category', 'category', 'Category'),
(161, 'user', 'Client', 'client', 'Client'),
(162, 'user', 'Notes', 'notes', 'Notes'),
(163, 'user', 'Yearly', 'yearly', 'Yearly'),
(164, 'user', 'Monthly ', 'monthly', 'Monthly '),
(165, 'user', 'Sign in', 'sign-in', 'Sign in'),
(166, 'admin', 'Packages by Users', 'packages-by-users', 'Packages by Users'),
(167, 'admin', 'Basic Package', 'basic-package', 'Basic Package'),
(168, 'admin', 'Standard Package', 'standard-package', 'Standard Package'),
(169, 'admin', 'Premium Package', 'premium-package', 'Premium Package'),
(170, 'admin', 'Recently joined Users', 'recently-joined-users', 'Recently joined Users'),
(171, 'admin', 'Last 12 months Income', 'last-12-months-income', 'Last 12 months Income'),
(172, 'admin', 'Avatar', 'avatar', 'Avatar'),
(173, 'admin', 'All Users', 'all-users', 'All Users'),
(174, 'admin', 'Package', 'package', 'Package'),
(175, 'admin', 'Payment status', 'payment-status', 'Payment status'),
(176, 'admin', 'Join', 'join', 'Join'),
(177, 'admin', 'Expire', 'expire', 'Expire'),
(178, 'admin', '-1 days left', '-1-days-left', '-1 days left'),
(179, 'admin', 'pending', 'pending', 'pending'),
(180, 'admin', '2 weeks ago', '2-weeks-ago', '2 weeks ago'),
(181, 'admin', 'Email Settings  ', 'email-settings', 'Email Settings  '),
(182, 'admin', 'Social Settings', 'social-settings', 'Social Settings'),
(183, 'admin', ' Payment Settings', 'payment-settings', ' Payment Settings'),
(184, 'admin', 'Recapture Settings ', 'recaptcha-settings', 'reCaptcha Settings'),
(185, 'admin', 'Update Settings', 'update-settings', 'Update Settings'),
(186, 'admin', 'Captcha Site key', 'captcha-site-key', 'Captcha Site key'),
(187, 'admin', 'Captcha Secret key', 'captcha-secret-key', 'Captcha Secret key'),
(188, 'admin', 'Preferences', 'preferences', 'Preferences'),
(189, 'admin', 'Google reCaptcha', 'google-recaptcha', 'Google reCaptcha'),
(190, 'admin', 'Registration System', 'registration-system', 'Registration System'),
(191, 'admin', 'Email Verification', 'email-verification', 'Email Verification'),
(192, 'admin', 'Paypal payment', 'paypal-payment', 'Paypal payment'),
(193, 'admin', 'Disable', 'disable', 'Disable'),
(194, 'admin', 'Enable', 'enable', 'Enable'),
(195, 'admin', 'Application Name', 'application-name', 'Application Name'),
(196, 'admin', 'Application Title', 'application-title', 'Application Title'),
(197, 'admin', 'Keywords', 'keywords', 'Keywords'),
(198, 'admin', 'Description', 'description', 'Description'),
(199, 'admin', 'Footer About', 'footer-about', 'Footer About'),
(200, 'admin', 'Admin Email', 'admin-email', 'Admin Email'),
(201, 'admin', 'Copyright', 'copyright', 'Copyright'),
(202, 'admin', 'Update Faction ', 'update-faction', 'Update Faction '),
(203, 'admin', 'Update Logo', 'update-logo', 'Update Logo'),
(204, 'admin', ' Gmail Smtp', 'gmail-smtp', ' Gmail Smtp'),
(205, 'admin', 'Gmail host', 'gmail-host', 'Gmail host'),
(206, 'admin', 'Gmail port', 'gmail-port', 'Gmail port'),
(207, 'admin', 'Mail Protocol', 'mail-protocol', 'Mail Protocol'),
(208, 'admin', 'Mail title', 'mail-title', 'Mail title'),
(209, 'admin', 'Mail host', 'mail-host', 'Mail host'),
(210, 'admin', 'Mail port', 'mail-port', 'Mail port'),
(211, 'admin', 'Mail username', 'mail-username', 'Mail username'),
(212, 'admin', 'Mail password', 'mail-password', 'Mail password'),
(213, 'admin', 'Paypal Mode', 'paypal-mode', 'Paypal Mode'),
(214, 'admin', 'Paypal Merchant Account', 'paypal-merchant-account', 'Paypal Merchant Account'),
(215, 'admin', 'Facebook', 'facebook', 'Facebook'),
(216, 'admin', 'Twitter', 'twitter', 'Twitter'),
(217, 'admin', 'Instagram', 'instagram', 'Instagram'),
(218, 'admin', 'Linkedin', 'linkedin', 'Linkedin'),
(219, 'admin', 'Google Analytics', 'google-analytics', 'Google Analytics'),
(220, 'admin', 'Manage Packages', 'manage-packages', 'Manage Packages'),
(221, 'admin', 'Update Package - Basic', 'update-package-basic', 'Update Package - Basic'),
(222, 'admin', 'Monthly Price', 'monthly-price', 'Monthly Price'),
(223, 'admin', 'Yearly Price', 'yearly-price', 'Yearly Price'),
(224, 'admin', 'Update Package - Standard', 'update-package-standard', 'Update Package - Standard'),
(225, 'admin', 'Update Package - Premium', 'update-package-premium', 'Update Package - Premium'),
(226, 'admin', 'Is popular Packages', 'is-popular-packages', 'Is popular Packages'),
(227, 'admin', 'Features', 'features', 'Features'),
(228, 'admin', 'Thumb', 'thumb', 'Thumb'),
(229, 'admin', 'Edit Feature', 'edit-feature', 'Edit Feature'),
(230, 'admin', 'Every invoice paid is positive incoming revenue for your business. Accufy enables you to easily create and send professional invoices, with advanced features like recurring billing. asd', 'every-invoice-paid-is-positive-incoming-revenue-for-your-business.-accufy-enables-you-to-easily-create-and-send-professional-invoices-with-advanced-features-like-recurring-billing.-asd', 'Every invoice paid is positive incoming revenue for your business. Accufy enables you to easily create and send professional invoices, with advanced features like recurring billing. asd'),
(231, 'admin', 'Upload Image ', 'upload-image', 'Upload Image '),
(232, 'admin', 'Add New Feature', 'add-new-feature', 'Add New Feature'),
(233, 'admin', 'Save ', 'save', 'Save '),
(234, 'admin', 'Size ', 'size', 'Size '),
(235, 'admin', 'Foment ', 'foment', 'Foment '),
(236, 'admin', 'Font ', 'font', 'Font '),
(237, 'admin', 'Styles', 'styles', 'Styles'),
(238, 'admin', 'Edit Package ', 'edit-package', 'Edit Package '),
(239, 'admin', 'Edit Features', 'edit-features', 'Edit Features'),
(240, 'admin', 'Add New Page', 'add-new-page', 'Add New Page'),
(241, 'admin', 'Pages', 'pages', 'Pages'),
(242, 'admin', 'Edit page', 'edit-page', 'Edit page'),
(243, 'admin', 'Page title', 'page-title', 'Page title'),
(244, 'admin', 'Page slug', 'page-slug', 'Page slug'),
(245, 'admin', 'Page description', 'page-description', 'Page description'),
(246, 'admin', 'erfref', 'erfref', 'erfref'),
(247, 'admin', ' Aloha', 'aloha', ' Aloha'),
(248, 'admin', 'Faqs', 'faqs', 'Faqs'),
(249, 'admin', 'All Faqs', 'all-faqs', 'All Faqs'),
(250, 'admin', 'Add New testimonial', 'add-new-testimonial', 'Add New testimonial'),
(251, 'admin', 'Client Name', 'client-name', 'Client Name'),
(252, 'admin', 'Designation', 'designation', 'Designation'),
(253, 'admin', 'Feedback ', 'feedback', 'Feedback '),
(254, 'admin', 'Upload Client Avatar ', 'upload-client-avatar', 'Upload Client Avatar '),
(255, 'admin', 'Blog', 'blog', 'Blog'),
(256, 'admin', 'Add category', 'add-category', 'Add category'),
(257, 'admin', 'Bolg posts ', 'bolg-posts', 'Bolg posts '),
(258, 'admin', 'All Blog posts', 'all-blog-posts', 'All Blog posts'),
(259, 'admin', 'Add New Blog Post', 'addblog-post', 'Add New Blog Post'),
(260, 'admin', 'Add Blog Post', 'add-blog-post', 'Add Blog Post'),
(261, 'admin', 'Add New Blog Post', 'add-new-blog-post', 'Add New Blog Post'),
(262, 'admin', 'Slug', 'slug', 'Slug'),
(263, 'admin', 'Tags', 'tags', 'Tags'),
(264, 'admin', 'Post description', 'post-description', 'Post description'),
(265, 'admin', 'Save Post ', 'save-post', 'Save Post '),
(266, 'admin', 'Active', 'active', 'Active'),
(267, 'admin', 'inactive', 'inactive', 'inactive'),
(268, 'admin', 'Users', 'users', 'Users'),
(269, 'user', 'Pricing Package', 'pricing-package', 'Pricing Package'),
(270, 'admin', 'Testimonial', 'testimonial', 'Testimonial'),
(271, 'admin', 'Language', 'language', 'Language'),
(272, 'admin', 'No data founds', 'no-data-founds', 'No data founds'),
(273, 'user', 'See all overdue invoices', 'see-all-overdue-invoices', 'See all overdue invoices'),
(274, 'user', 'Recently Paid Invoices', 'recently-paid-invoices', 'Recently Paid Invoices'),
(275, 'user', 'See all paid invoices', 'see-all-paid-invoices', 'See all paid invoices'),
(276, 'user', 'Select', 'select', 'Select'),
(277, 'admin', 'Save Changes', 'save-changes', 'Save Changes'),
(278, 'user', 'Edit business', 'edit-business', 'Edit business'),
(279, 'user', 'Informations', 'informations', 'Informations'),
(280, 'user', 'Select country', 'select-country', 'Select country'),
(281, 'user', 'Select business category', 'select-business-category', 'Select business category'),
(282, 'user', 'Update', 'update', 'Update'),
(283, 'user', 'Template', 'template', 'Template'),
(284, 'user', 'Add New Customer', 'add-new-customer', 'Add New Customer'),
(285, 'user', 'Edit tax', 'edit-tax', 'Edit tax'),
(286, 'user', 'Edit product', 'edit-product', 'Edit product'),
(287, 'user', 'Product Name', 'product-name', 'Product Name'),
(288, 'user', 'Sell this', 'sell-this', 'Sell this'),
(289, 'user', 'Allow this product or service to be added to Invoices', 'allow-this-product', 'Allow this product or service to be added to Invoices'),
(290, 'user', 'Income Category', 'income-category', 'Income Category'),
(291, 'user', 'Buy this', 'buy-this', 'Buy this'),
(292, 'user', 'Allow this product or service to be added to Bills.', 'allow-this-product-to-bills', 'Allow this product or service to be added to Bills.'),
(293, 'user', 'Product Details', 'product-details', 'Product Details'),
(294, 'user', 'Expense Category', 'expense-category', 'Expense Category'),
(295, 'user', 'Preview as a customer', 'preview-as-a-customer', 'Preview as a customer'),
(296, 'user', 'Export as PDF', 'export-as-pdf', 'Export as PDF'),
(297, 'user', 'Send estimate', 'send-estimate', 'Send estimate'),
(298, 'user', 'Send a copy to myself at', 'send-a-copy-to-myself-at', 'Send a copy to myself at'),
(299, 'user', 'Finish Setup', 'finish-setup', 'Finish Setup'),
(300, 'user', 'You haven\'t finished your setup yet. We recommend you to finish your setup before send your invoice.', 'setup-alert-msg', 'You haven\'t finished your setup yet. We recommend you to finish your setup before send your invoice.'),
(301, 'user', 'Finish Setup Now', 'finish-setup-now', 'Finish Setup Now'),
(302, 'user', 'You have reached your limit', 'reached-limit', 'You have reached your limit'),
(303, 'user', 'You already created', 'you-already-created', 'You already created'),
(304, 'user', 'Please upgrade your package to unlock the features.', 'package-limit-msg', 'Please upgrade your package to unlock the features.'),
(305, 'user', 'Upgrade your plan', 'upgrade-your-plan', 'Upgrade your plan'),
(306, 'user', 'All Estimates', 'all-estimates', 'All Estimates'),
(307, 'user', 'Oops! There was an issue with your Estimate. Please try again', 'invoice-create-error', 'Oops! There was an issue with your Estimate. Please try again'),
(308, 'user', 'Business address and contact details, title, summary, and logo', 'invoice-heading-title', 'Business address and contact details, title, summary, and logo'),
(309, 'user', 'Summary example: project name, description of estimate', 'summery-placeholder', 'Summary example: project name, description of estimate'),
(310, 'user', 'Add a customer', 'add-a-customer', 'Add a customer'),
(311, 'user', 'Select tax', 'select-tax', 'Select tax'),
(312, 'user', 'Enter a footer for this invoice (e.g. tax information, thank you note)', 'invoice-footer-placeholder', 'Enter a footer for this invoice (e.g. tax information, thank you note)'),
(313, 'user', 'Preview mode', 'preview-mode', 'Preview mode'),
(314, 'user', 'You are previewing how your customer will see the web version of your estimate', 'preview-mode-msg', 'You are previewing how your customer will see the web version of your'),
(315, 'user', 'Print', 'print', 'Print'),
(316, 'user', 'Download Pdf', 'download-pdf', 'Download Pdf'),
(317, 'user', 'Convert to invoice', 'convert-to-invoice', 'Convert to invoice'),
(318, 'user', 'Select payment method', 'select-payment-method', 'Select payment method'),
(319, 'user', 'Unpaid', 'unpaid', 'Unpaid'),
(320, 'user', 'Paid', 'paid', 'Paid'),
(321, 'user', 'Sent', 'sent', 'Sent'),
(322, 'user', 'All Invoices', 'all-invoices', 'All Invoices'),
(323, 'user', 'Add new product', 'add-new-product', 'Add new product'),
(324, 'user', 'This is a preview of your invoice. Switch back to Edit if you need to make changes.', 'preview-invoice-info', 'This is a preview of your invoice. Switch back to Edit if you need to make changes.'),
(325, 'user', 'Due on', 'due-on', 'Due on'),
(326, 'user', 'You created this invoice, but you have not approved it', 'approve-info', 'You created this invoice, but you have not approved it'),
(327, 'user', 'Your customer has paid this invoice in full.', 'paid-info', 'Your customer has paid this invoice in full.'),
(328, 'user', 'Your customer has not paid the full invoice amount on time.', 'unpaid-info', 'Your customer has not paid the full invoice amount on time.'),
(329, 'user', 'Draft Invoice', 'draft-invoice', 'Draft Invoice'),
(330, 'user', 'This is a DRAFT invoice. You can take further actions once you approve it', 'draft-inv-info', 'This is a DRAFT invoice. You can take further actions once you approve it'),
(331, 'user', 'Your invoice is awaiting payment', 'awaiting-payment', 'Your invoice is awaiting payment'),
(332, 'user', 'Your invoice is paid in full', 'paid-in-full', 'Your invoice is paid in full'),
(333, 'user', 'Payments received', 'payments-received', 'Payments received'),
(334, 'user', ' A payment for', 'a-payment-for', ' A payment for'),
(335, 'user', 'Send Again', 'send-again', 'Send Again'),
(336, 'user', 'Payment terms', 'payment-terms', 'Payment terms'),
(337, 'user', 'On Receipt', 'on-receipt', 'On Receipt'),
(338, 'user', 'Within', 'within', 'Within'),
(339, 'user', 'Days', 'days', 'Days'),
(340, 'user', 'Invoice Schedule', 'invoice-schedule', 'Invoice Schedule'),
(341, 'user', 'Recurring start', 'recurring-start', 'Recurring start'),
(342, 'user', 'Recurring end', 'recurring-end', 'Recurring end'),
(343, 'user', 'Repeat invoice', 'repeat-invoice', 'Repeat invoice'),
(344, 'user', 'Set schedule', 'set-schedule', 'Set schedule'),
(345, 'user', 'Start date', 'start-date', 'Start date'),
(346, 'user', 'Repeat this invoice', 'repeat-this-invoice', 'Repeat this invoice'),
(347, 'user', 'Weekly', 'weekly', 'Weekly'),
(348, 'user', 'Weeks', 'weeks', 'Weeks'),
(349, 'user', 'Months', 'months', 'Months'),
(350, 'user', 'Years', 'years', 'Years'),
(351, 'user', 'End date', 'end-date', 'End date'),
(352, 'user', 'Auto send invoice by e-mail', 'auto-send-invoice-by-e-mail', 'Auto send invoice by e-mail'),
(353, 'user', 'Email a copy of each invoice to myself', 'email-a-copy', 'Email a copy of each invoice to myself'),
(354, 'user', 'Bill to', 'bill-to', 'Bill to'),
(355, 'user', 'You have not added a customer', 'empty-customer', 'You have not added a customer'),
(356, 'user', 'Invoice number', 'invoice-number', 'Invoice number'),
(357, 'user', 'Invoice date', 'invoice-date', 'Invoice date'),
(358, 'user', 'Due date', 'due-date', 'Due date'),
(359, 'user', 'You have not added any items', 'empty-items', 'You have not added any items'),
(360, 'user', 'Package Plan', 'package-plan', 'Package Plan'),
(361, 'user', 'PAY NOW', 'pay-now', 'PAY NOW'),
(362, 'user', 'Your payment has be completed successfully !', 'payment-success-msg', 'Your payment has be completed successfully !'),
(363, 'user', 'Your payment has be failed ! Please try again', 'payment-error-msg', 'Your payment has be failed ! Please try again'),
(364, 'user', 'Continue', 'continue', 'Continue'),
(365, 'user', 'Failed', 'failed', 'Failed'),
(366, 'user', 'Try again', 'try-again', 'Try again'),
(367, 'user', 'Show Report', 'show-report', 'Show Report'),
(368, 'user', 'Plan', 'plan', 'Plan'),
(369, 'user', 'Days left', 'days-left', 'Days left'),
(370, 'user', 'per year', 'per-year', 'per year'),
(371, 'user', 'per month', 'per-month', 'per month'),
(372, 'user', 'Unlimited', 'unlimited', 'Unlimited'),
(373, 'user', 'Edit vendor', 'edit-vendor', 'Edit vendor'),
(374, 'user', 'Edit Expense', 'edit-expense', 'Edit Expense'),
(375, 'user', 'Expenses', 'expenses', 'Expenses'),
(376, 'user', 'Expense Amount', 'expense-amount', 'Expense Amount'),
(377, 'user', 'Save and continue', 'save-and-continue', 'Save and continue'),
(378, 'user', 'Preview', 'preview', 'Preview'),
(379, 'user', 'Manage business', 'manage-business', 'Manage business'),
(380, 'user', 'Manage profile', 'manage-profile', 'Manage profile'),
(381, 'user', 'Sign out', 'sign-out', 'Sign out'),
(382, 'user', 'accounts', 'accounts', 'accounts'),
(383, 'user', 'No users found', 'no-users-found', 'No users found'),
(384, 'user', 'Edit Faq', 'edit-faq', 'Edit Faq'),
(385, 'user', 'Add New Faq', 'add-new-faq', 'Add New Faq'),
(386, 'user', 'Upload favicon', 'upload-favicon', 'Upload favicon'),
(387, 'user', 'Upload logo', 'upload-logo', 'Upload logo'),
(388, 'user', 'Not found', 'not-found', 'Not found'),
(389, 'user', 'Update Package features for', 'update-package-features-for', 'Update Package features for'),
(390, 'user', 'Basic Limit', 'basic-limit', 'Basic Limit'),
(391, 'user', 'Standared Limit', 'standared-limit', 'Standared Limit'),
(392, 'user', 'Premium Limit', 'premium-limit', 'Premium Limit'),
(393, 'user', 'Update Package', 'update-package', 'Update Package'),
(394, 'user', 'Yes', 'yes', 'Yes'),
(395, 'user', 'No', 'no', 'No'),
(396, 'user', 'Edit testimonial', 'edit-testimonial', 'Edit testimonial'),
(397, 'user', 'Edit Blog Post', 'edit-blog-post', 'Edit Blog Post'),
(398, 'front', 'Pricing', 'pricing', 'Pricing'),
(399, 'front', 'Home', 'home', 'Home'),
(400, 'front', 'Blogs', 'blogs', 'Blogs'),
(401, 'front', 'Contact', 'contact', 'Contact'),
(402, 'front', 'Create Account', 'create-account', 'Create Account'),
(403, 'front', 'Get Started', 'get-started', 'Get Started'),
(404, 'front', 'The better way to make, move and manage your money', 'home-feature-title', 'The better way to keep track & manage your money'),
(405, 'front', 'Workflow', 'workflow', 'Workflow'),
(406, 'front', 'Look at a glance how our app works', 'how-app-works', 'Look at a glance how our app works'),
(407, 'front', 'Choose Plan', 'choose-plan', 'Choose Plan'),
(408, 'front', 'Choose your comfortable plan', 'choose-your-comfortable-plan', 'Choose your comfortable plan'),
(409, 'front', 'Get Paid', 'get-paid', 'Get Paid'),
(410, 'front', 'Paid via paypal payment method', 'paid-via-paypal-payment-method', 'Paid via paypal payment method'),
(411, 'front', 'Start Working', 'start-working', 'Start Working'),
(412, 'front', 'Start Using and explore the featuers', 'start-using-and-explore-the-featuers', 'Start Using and explore the features'),
(413, 'front', 'Clients Say', 'clients-say', 'Clients Say'),
(414, 'front', 'Learn more, Build skills & Empower yourself', 'learn-more-build-skills-empower-yourself', 'Learn more, Build skills & Empower yourself'),
(415, 'front', 'Get in touch', 'get-in-touch', 'Get in touch'),
(416, 'front', '404 Not Found', '404-not-found', '404 Not Found'),
(417, 'front', 'The resource requested could not be found on this site!', '404-msg', 'The resource requested could not be found on this site!'),
(418, 'front', 'Back to Home', 'back-to-home', 'Back to Home'),
(419, 'front', 'Full name', 'full-name', 'Full name'),
(420, 'front', 'Write your Message', 'write-your-message', 'Write your Message'),
(421, 'front', 'Forgot password?', 'forgot-password', 'Forgot password?'),
(422, 'front', 'Recover password', 'recover-password', 'Recover password'),
(423, 'front', 'SUBMIT', 'submit', 'SUBMIT'),
(424, 'front', 'Login', 'login', 'Login'),
(425, 'front', 'Enter your email', 'enter-your-email', 'Enter your email'),
(426, 'front', 'Small Business—friendly Pricing', 'price-title', 'Small Business—friendly Pricing'),
(427, 'front', 'We\'re offering a generous Free Plan and affordable premium pricing plans that grow with your business', 'price-desc', 'We\'re offering a generous Free Plan and affordable premium pricing plans that grow with your business'),
(428, 'front', 'Done', 'done', 'Done'),
(429, 'front', 'Error', 'error', 'Error'),
(430, 'front', 'Please complete your payment by clicking the PAY NOW button', 'complete-your-payment', 'Please complete your payment by clicking the PAY NOW button'),
(431, 'front', 'Registration system is disabled', 'registration-system-is-disabled', 'Registration system is disabled'),
(432, 'front', 'helps Entrepreneurs to manage their business & finances', 'register-info', 'helps Entrepreneurs to manage their business & finances'),
(433, 'front', 'Sign Up', 'sign-up', 'Sign Up'),
(434, 'front', 'I agree with Terms of Services', 'agree-info', 'I agree with Terms of Services'),
(435, 'front', 'Setup your first Business', 'setup-your-first-business', 'Setup your first Business'),
(436, 'front', 'Select Business Type', 'select-business-type', 'Select Business Type'),
(437, 'front', 'You are almost done', 'you-are-almost-done', 'You are almost done'),
(438, 'front', 'Post comment', 'post-comment', 'Post comment'),
(439, 'front', 'Related Posts', 'related-posts', 'Related Posts'),
(440, 'front', 'Comments', 'comments', 'Comments'),
(441, 'front', 'Verify Account', 'verify-account', 'Verify Account'),
(442, 'front', 'We have sent a link to your registered email address, please click this link to verify your account', 'verify-acc-msg', 'We have sent a link to your registered email address, please click this link to verify your account'),
(443, 'front', 'Email verification failed!', 'verify-failed', 'Email verification failed!'),
(444, 'front', 'Congratulation\'s', 'congratulations', 'Congratulation\'s'),
(445, 'front', 'Your account successfully verified', 'verify-success', 'Your account successfully verified'),
(446, 'admin', 'Inserted Successfully', 'msg-inserted', 'Inserted Successfully'),
(447, 'admin\n', 'Updated Successfully', 'msg-updated', 'Updated Successfully'),
(448, 'front', 'Activate Successfully', 'msg-activated', 'Activate Successfully'),
(449, 'front', 'Deactivate Successfully', 'msg-deactivated', 'Deactivate Successfully'),
(450, 'front', 'Recaptcha is required', 'recaptcha-is-required', 'Recaptcha is required'),
(451, 'front', 'Message send Successfully', 'message-send-successfully', 'Message send Successfully'),
(452, 'front', 'Create', 'create', 'Create'),
(453, 'user', 'Approve', 'approve', 'Approve'),
(454, 'admin', 'Contacts', 'contacts', 'Contacts'),
(455, 'admin', 'Select User', 'select-user', 'Select User'),
(456, 'admin', 'Select Package', 'select-package', 'Select Package'),
(457, 'admin', 'Offline Payment', 'offline-payment', 'Offline Payment'),
(458, 'admin', 'Add Offline Payment', 'add-offline-payment', 'Add Offline Payment'),
(459, 'admin', 'Subscription Type', 'subscription-type', 'Subscription Type'),
(460, 'admin', 'Payment added successfully', 'payment-added-successfully', 'Payment added successfully'),
(461, 'admin', 'Enter your tags', 'enter-your-tags', 'Enter your tags'),
(462, 'user', 'Created on', 'created-on', 'Created on'),
(463, 'user', 'View', 'view', 'View'),
(464, 'user', 'Approved', 'approved', 'Approved'),
(465, 'front', 'Free trial of', 'free-trial-of', 'Free trial of'),
(466, 'admin', 'Edit frontend values', 'edit-frontend-values', 'Frontend values'),
(467, 'admin', 'Edit admin values', 'edit-admin-values', 'Admin values'),
(468, 'admin', 'Edit user values', 'edit-user-values', 'User values'),
(469, 'admin', 'Update language for', 'update-language-for', 'Update language for'),
(470, 'admin', 'Frontend', 'frontend', 'Frontend'),
(471, 'admin', 'Admin', 'admin', 'Admin'),
(472, 'admin', 'User', 'user', 'User'),
(473, 'admin', 'Add New Language ', 'add-new-language', 'Add New Language '),
(474, 'admin', 'Manage Language', 'manage-language', 'Manage Language'),
(475, 'admin', 'Update values', 'update-values', 'Update values'),
(476, 'admin', 'Your Password has been changed Successfully', 'password-reset-success-msg', 'Your Password has been changed Successfully'),
(477, 'admin', 'Oops', 'oops', 'Oops'),
(478, 'admin', 'Your Confirm Password doesn\'t Match', 'confirm-pass-not-match-msg', 'Your Confirm Password doesn\'t Match'),
(479, 'admin', 'Your Old Password doesn\'t Match', 'old-password-doesnt-match', 'Your Old Password doesn\'t Match'),
(480, 'admin', 'Sorry', 'sorry', 'Sorry!'),
(481, 'admin', 'Something wrong', 'something-wrong', 'Something wrong'),
(482, 'admin', 'Success', 'success', 'Success!'),
(483, 'admin', 'Setup successfully', 'setup-successfully', 'Setup successfully'),
(484, 'admin', 'Send successfully', 'send-successfully', 'Send successfully'),
(485, 'admin', 'Are you sure', 'are-you-sure', 'Are you sure?'),
(486, 'admin', 'Convert this estimate to a draft invoice?', 'convert-estimate-to-draft-invoice', 'Convert this estimate to a draft invoice?'),
(487, 'admin', 'Convert', 'convert', 'Convert'),
(488, 'admin', 'Converted successfully', 'converted-successfully', 'Converted successfully'),
(489, 'admin', 'Data limit has been over', 'data-limit-over', 'Data limit has been over'),
(490, 'admin', 'Sending failed', 'sending-failed', 'Sending failed'),
(491, 'admin', 'Approved Successfully', 'approved-successfully', 'Approved Successfully'),
(492, 'admin', 'You will not be able to recover this file', 'not-recover-file', 'You will not be able to recover this file'),
(493, 'admin', 'Deleted successfully', 'deleted-successfully', 'Deleted successfully'),
(494, 'admin', 'Approve this invoice', 'approve-this-invoice', 'Approve this invoice'),
(495, 'admin', 'Set as your primary business', 'set-as-your-primary-business', 'Set as your primary business'),
(496, 'admin', 'Want to set', 'want-to-set', 'Want to set'),
(497, 'admin', 'as your default business?', 'as-your-default-business', 'as your default business?'),
(498, 'admin', 'You have made some changes and it\'s not saved?', 'made-changes-not-saved', 'You have made some changes and it\'s not saved?'),
(499, 'admin', 'Your account has been suspended', 'account-suspend-msg', 'Your account has been suspended!'),
(500, 'front', 'This email already exist, try another one', 'email-exist', 'This email already exist, try another one'),
(501, 'front', 'Your account is not active', 'account-not-active', 'Your account is not active'),
(502, 'front', 'Sorry your username or password is not correct!', 'wrong-username-password', 'Sorry your username or password is not correct!'),
(503, 'front', 'Your email is not verified, Please verify your email', 'email-not-verified', 'Your email is not verified, Please verify your email'),
(504, 'front', 'We\'ve sent a password to your email address. Please check your inbox', 'password-sent-to-email', 'We\'ve sent a password to your email address. Please check your inbox'),
(505, 'front', 'Password Reset Successfully !', 'password-reset-successfully', 'Password Reset Successfully !'),
(506, 'front', 'You are not a valid user', 'not-a-valid-user', 'You are not a valid user'),
(507, 'admin', 'Set default language', 'set-default-language', 'Set default language'),
(508, 'admin', 'Short Form', 'short-form', 'Short Form'),
(509, 'admin', 'Text direction', 'text-direction', 'Text direction'),
(510, 'admin', 'Oops! There was an issue with your invoice. Please try again', 'invoice-error-create', 'Oops! There was an issue with your invoice. Please try again'),
(511, 'user', 'Business address and contact details, title, summary, and logo', 'invoice-title', 'Business address and contact details, title, summary, and logo'),
(512, 'user', 'Add new item', 'add-new-item', 'Add new item'),
(513, 'user', 'Summary example: project name, description of invoice', 'invoice-title-placeholder', 'Summary example: project name, description of invoice'),
(514, 'user', 'Select Customer', 'select-customer', 'Select Customer'),
(515, 'admin', 'Set Trial Days', 'set-trial-days', 'Set trial days'),
(516, 'front', 'Start', 'start', 'Start'),
(517, 'front', 'days trial', 'days-trial', 'days trial'),
(518, 'admin', 'Delete', 'delete', 'Delete'),
(519, 'admin', 'Activate', 'activate', 'Activate'),
(520, 'admin', 'Deactivate', 'deactivate', 'Deactivate'),
(521, 'admin', 'Verified', 'verified', 'Verified'),
(522, 'user', 'Estimate', 'estimate', 'Estimate'),
(523, 'front', 'Explore our features', 'explore-our-features', 'Explore our features'),
(524, 'front', 'Frequently Asked Questions', 'frequently-asked-questions', 'Frequently Asked Questions'),
(525, 'admin', 'Income', 'income', 'Income'),
(526, 'front', 'Password', 'password', 'Password'),
(527, 'front', 'Username or email', 'username-or-email', 'Username or email'),
(528, 'user', 'Currency conversion', 'currency-conversion', 'Currency conversion'),
(529, 'user', 'Add a customer to this invoice', 'add-customer-error-msg', 'Add a customer to this invoice'),
(530, 'user', 'Set default footer note for invoice', 'set-default-footer-note', 'Set default footer note for invoice'),
(531, 'admin', 'Multilingual System', 'enable-multilingual', 'Multilingual System'),
(532, 'user', 'Completed', 'completed', 'Completed'),
(533, 'user', 'Stop Recurring', 'stop-recurring', 'Stop Recurring'),
(534, 'user', 'Stop this recurring invoice', 'stop-this-recurring-invoice', 'Stop this recurring invoice'),
(535, 'user', 'Applied Successfully', 'applied-successfully', 'Applied Successfully'),
(536, 'user', 'Cancel', 'cancel', 'Cancel'),
(537, 'front', 'This website uses cookies. By using this website you consent to our use of these cookies.', 'accept-cookies', 'This website uses cookies. By using this website you consent to our use of these cookies.'),
(538, 'front', 'Accept', 'accept', 'Accept'),
(539, 'user', 'You created this invoice, but you have not approved it.', 'draft-tooltip', 'You created this invoice, but you have not approved it.'),
(540, 'user', 'Your customer has paid this invoice in full.', 'paid-tooltip', 'Your customer has paid this invoice in full.'),
(541, 'user', 'Your customer has not paid the full invoice amount on time.', 'unpaid-tooltip', 'Your customer has not paid the full invoice amount on time.'),
(542, 'user', 'This recurring invoice has been completed', 'complete-tooltip', 'This recurring invoice has been completed'),
(543, 'user', 'Your customer has paid this invoice in full.', 'active-tooltip', 'Your customer has paid this invoice in full.'),
(544, 'user', 'Your estimate is expire now', 'expire-estimate', 'Your estimate is expire now'),
(545, 'user', 'our estimate is saved', 'saved-estimate', 'our estimate is saved'),
(546, 'user', 'Reset Filter', 'reset-filter', 'Reset Filter'),
(547, 'user', 'Report Types', 'report-types', 'Report Types'),
(548, 'user', 'Tax Info', 'tax-info', 'Tax Info'),
(549, 'user', 'Including Tax', 'with-tax', 'Including Tax'),
(550, 'user', 'Excluding Tax', 'without-tax', 'Excluding Tax'),
(551, 'user', 'All', 'all', 'All'),
(552, 'user', 'Net Amount', 'net-amount', 'Net Amount'),
(553, 'user', 'Version', 'version', 'Version'),
(554, 'user', 'Your customer has paid partial payment of this invoice.', 'paid-partial', 'Your customer has paid partial payment of this invoice.'),
(555, 'user', 'Next Payment', 'next-payment', 'Next Payment'),
(556, 'user', 'Upcomming', 'upcomming', 'Upcomming'),
(557, 'user', 'Upcomming Recurring Payments', 'upcomming-recurring-payments', 'Upcomming Recurring Payments'),
(558, 'admin', 'Coupons', 'coupons', 'Coupons'),
(559, 'admin', 'Coupon', 'coupon', 'Coupon'),
(560, 'admin', 'Edit Coupon', 'edit-coupon', 'Edit Coupon'),
(561, 'admin', 'Add New Coupon', 'add-new-coupon', 'Add New Coupon'),
(562, 'admin', 'Usages limit', 'usages-limit', 'Usages limit'),
(563, 'admin', 'Usages Count', 'usages-count', 'Usages Count'),
(564, 'admin', 'Auto generate coupon code', 'auto-generate-code', 'Auto generate coupon code'),
(565, 'admin', 'Ccoupon Code', 'coupon-code', 'Ccoupon Code'),
(566, 'admin', 'Expire Date', 'expire-date', 'Expire Date'),
(567, 'admin', 'Billing Type', 'bill-type', 'Billing Type'),
(568, 'front', 'Off', 'off', 'Off'),
(569, 'front', 'Terms of service', 'terms-of-service', 'Terms of service'),
(570, 'front', 'I agree with', 'agree-with', 'I agree with'),
(571, 'front', 'Save up to', 'save-upto', 'Save up to'),
(572, 'admin', 'Enable Payment', 'enable-payment', 'Enable Payment'),
(573, 'admin', 'Stripe Payment', 'stripe-payment', 'Stripe Payment'),
(574, 'admin', 'Publish Key', 'publish-key', 'Publish Key'),
(575, 'admin', 'Secret Key', 'secret-key', 'Secret Key'),
(576, 'user', 'Name on Card', 'name-on-card', 'Name on Card'),
(577, 'user', 'Card Number', 'card-number', 'Card Number'),
(578, 'user', 'Expiration', 'expiration', 'Expiration'),
(579, 'user', 'Payment', 'payment', 'Payment'),
(580, 'user', 'If you leave this field, your invoice end date will be set unlimited', 'recurring-end-info', 'If you leave this field, your invoice end date will be set unlimited'),
(581, 'user', 'Add new GST', 'add-new-gst', 'Add new GST'),
(582, 'user', 'Edit GST', 'edit-gst', 'Edit GST'),
(583, 'admin', 'Order', 'order', 'Order'),
(584, 'user', 'Convert to Recurring Invoice', 'convert-recurring', 'Convert to Recurring'),
(585, 'user', 'Start date must be lower then the current date', 'recurring-date-msg', 'Start date must be lower then the current date'),
(586, 'user', 'Convert this to a recurring invoice', 'convert-recurring-msg', 'Convert this to a recurring invoice'),
(587, 'user', 'Pay Online', 'pay-online', 'Pay Online'),
(588, 'user', 'Receive payment currency', 'payment-currency', 'Receive payment currency'),
(589, 'user', 'Get shareable link', 'share-link', 'Get shareable link'),
(590, 'user', 'Rejected', 'rejected', 'Rejected'),
(591, 'user', 'Reject Reason', 'reject-reason', 'Reject Reason'),
(592, 'user', 'Describe reject reason', 'describe-reject-reason', 'Describe reject reason'),
(593, 'user', 'Product Stock Quantity', 'stock-quantity', 'Product Stock Quantity'),
(594, 'user', 'Enable product stock', 'enable-stock', 'Enable product stock'),
(595, 'user', 'Enable this feature you will be able to manage your products stock in invoices. ', 'enable-sotck-help', 'Enable this feature you will be able to manage your products stock in invoices. '),
(596, 'user', 'Accent color', 'accent-color', 'Accent color'),
(597, 'admin', 'Send Test Mail', 'test-mail', 'Send Test Mail'),
(598, 'admin', 'Mail Encryption', 'mail-encryption', 'Mail Encryption'),
(599, 'admin', 'If you are using gmail smtp please make sure you have set below settings before sending mail', 'mail-help-info', 'If you are using gmail smtp please make sure you have set below settings before sending mail'),
(600, 'admin', '\'SSL\' is used for port 465/25, \'TLS\' is used for port 587', 'mail-help-info-2', '\'SSL\' is used for port 465/25, \'TLS\' is used for port 587'),
(601, 'admin', 'Set 0 days to hide trial option in website', 'trial-disable', 'Set 0 days to hide trial option in website'),
(602, 'user', 'Bills', 'bills', 'Bills'),
(603, 'user', 'Create New Bill', 'create-new-bill', 'Create New Bill'),
(604, 'user', 'Edit Bill', 'edit-bill', 'Edit Bill'),
(605, 'user', 'Save Bill', 'save-bill', 'Save Bill'),
(606, 'user', 'Bill', 'bill', 'Bill'),
(607, 'user', 'Record a payment for this bill', 'record-payment-bill', 'Record a payment for this bill'),
(608, 'user', 'Sales', 'sales', 'Sales'),
(609, 'user', 'Purchases', 'purchases', 'Purchases'),
(610, 'user', 'Partial', 'partial', 'Partial'),
(611, 'user', 'Income by Customer', 'income-by-customer', 'Income by Customer'),
(612, 'user', 'Purchases by Vendor', 'purchases-by-Vendor', 'Purchases by Vendor'),
(613, 'user', 'Purchase', 'purchase', 'Purchase'),
(614, 'user', 'Profit & Loss', 'profit-loss', 'Profit & Loss'),
(615, 'user', 'Paid & Unpaid', 'paid-unpaid', 'Paid & Unpaid'),
(616, 'user', 'Including paid & unpaid invoices and bills', 'paid-unpaid-inv-bill', 'Including paid & unpaid invoices and bills'),
(617, 'user', 'Including only paid invoices and bills', 'paid-inv-bill', 'Including only paid invoices and bills'),
(618, 'user', 'Net Profit', 'net-profit', 'Net Profit'),
(619, 'user', 'Sales Tax Report', 'sales-tax-report', 'Sales Tax Report'),
(620, 'user', 'Sales Product to tax', 'sales-product-tax', 'Sales Product to tax'),
(621, 'user', 'Tax Amount on Sales', 'tax-amount-sale', 'Tax Amount on Sales'),
(622, 'user', 'Purchases Subject to Tax', 'purchase-subject', 'Purchases Subject to Tax'),
(623, 'user', 'Tax Amount on Purchases', 'tax-amount-purchase', 'Tax Amount on Purchases'),
(624, 'user', 'Net Tax Owing', 'tax-owing', 'Net Tax Owing'),
(625, 'front', 'Signing in ...', 'signing-in', 'Signing in ...'),
(626, 'user', 'Select Vendor', 'select-Vendor', 'Select Vendor'),
(627, 'user', 'General', 'general', 'General'),
(628, 'user', 'Purchase from', 'purchase-from', 'Purchase from'),
(629, 'user', 'Bill Number', 'bill-number', 'Bill Number'),
(630, 'front', 'Frontend Website', 'enable-frontend', 'Frontend Website'),
(631, 'admin', 'Search by name or email', 'search-by-name-email', 'Search by name or email'),
(632, 'admin', 'All Packages', 'all-package', 'All Packages'),
(633, 'admin', 'Website Settings', 'website-settings', 'Website Settings'),
(634, 'user', 'Your customer has paid some partial payment for this invoice.', 'partial-payment', 'Your customer has paid some partial payment for this invoice.'),
(635, 'admin', 'Set -2 for Unlimited, -1 for Yes & 0 for No', 'limit-suggestions', 'Set -2 for Unlimited, -1 for Yes & 0 for No'),
(636, 'admin', 'Enable access to show your frontend website.', 'enable-frontend-info', 'Enable access to show your frontend website.'),
(637, 'admin', 'Enable access to active multilingual system.', 'enable-multilingual-info', 'Enable access to active multilingual system.'),
(638, 'admin', 'Enable to active reCaptcha for all public forms (Sign up, contacts).', 'enable-captcha-info', 'Enable to active reCaptcha for all public forms (Sign up, contacts).'),
(639, 'admin', 'Enable to allow sign up users to your site.', 'registration-system-info', 'Enable to allow sign up users to your site.'),
(640, 'admin', 'Enable to allow email verification for registered users.', 'email-verification-info', 'Enable to allow email verification for registered users.'),
(641, 'admin', 'Enable Payment = Your users need to complete their payment for access all features <br> Disable Payment = Your users will access all features without completing payments.', 'enable-payment-info', 'Enable Payment = Your users need to complete their payment for access all features <br> Disable Payment = Your users will access all features without completing payments.'),
(642, 'admin', 'Enable to allow delete invoice in user business.', 'delete-invoice-info', 'Enable to allow delete invoice in user business.'),
(643, 'admin', 'Enable to active discount system', 'discount-info', 'Enable to active discount system'),
(644, 'admin', 'Enable to show blogs option in frontend', 'blogs-info', 'Enable to show blogs option in frontend'),
(645, 'admin', 'Enable to show FAQs option in frontend', 'faqs-info', 'Enable to show FAQs option in frontend'),
(646, 'user', 'Enter item description', 'item-description', 'Enter item description'),
(647, 'user', 'Send Bills', 'send-bills', 'Send Bills'),
(648, 'user', 'Invoice title', 'invoice-titles', 'Invoice title'),
(649, 'user', 'Estimate title', 'estimate-title', 'Estimate title'),
(650, 'user', 'Bill title', 'bill-title', 'Bill title'),
(651, 'user', 'View Invoices', 'view-invoice', 'View Invoices'),
(652, 'user', 'Payment on', 'payment-on', 'Payment on'),
(653, 'user', 'Using', 'using', 'Using'),
(654, 'user', 'Pending Invoices', 'pending-invoices', 'Pending Invoices'),
(655, 'user', 'Set Default', 'set-default', 'Set Default'),
(656, 'user', 'Set as a default business', 'default-business', 'Set as a default business'),
(657, 'user', 'Convert to credit note', 'convert-credit', 'Convert to credit note'),
(658, 'user', 'Convert to invoice', 'convert-invoice', 'Convert to invoice'),
(659, 'user', 'Revert to Invoice', 'revert-invoice', 'Revert to Invoice'),
(660, 'user', 'Credit Notes', 'credit-notes', 'Credit Notes'),
(661, 'user', 'Credit Note', 'credit-note', 'Credit Note'),
(662, 'admin', 'Appearance', 'appearance', 'Appearance'),
(663, 'admin', 'Set Theme', 'set-theme', 'Set Theme'),
(664, 'user', 'Position at the business', 'position-at-the-business', 'Position at the business'),
(665, 'user', 'User Role', 'user-role', 'User Role'),
(666, 'user', 'Role', 'role', 'Role'),
(667, 'user', 'Editor', 'editor', 'Editor'),
(668, 'user', 'Viewer/Assesor', 'viewerassesor', 'Viewer/Assesor'),
(669, 'user', 'Viewer', 'viewer', 'Viewer'),
(670, 'user', 'Admin Permissions', 'admin-permissions', 'Admin Permissions'),
(671, 'user', 'Best for a business partner, family member, or trusted accountant manager', 'admin-permissions-info', 'Best for a business partner, family member, or trusted accountant manager'),
(672, 'user', 'View Only', 'view-only', 'View Only'),
(673, 'user', 'Full access', 'full-access', 'Full access'),
(674, 'user', 'No Access', 'no-access', 'No Access'),
(675, 'user', 'Editor Permissions', 'editor-permissions', 'Editor Permissions'),
(676, 'user', 'Best for a bookkeeper or accountant manager', 'editor-permissions-info', 'Best for a bookkeeper or accountant manager'),
(677, 'user', 'Viewer Permissions', 'viewer-permissions', 'Viewer Permissions'),
(678, 'user', 'Best for anyone who needs view-only access', 'viewer-permissions-info', 'Best for anyone who needs view-only access'),
(679, 'user', 'Permissions', 'permissions', 'Permissions'),
(680, 'user', 'Owner', 'owner', 'Owner'),
(681, 'user', 'Joined', 'joined', 'Joined'),
(682, 'user', 'Assign Role Permissions', 'assign-role-permissions', 'Assign Role Permissions'),
(683, 'user', 'Role Management', 'role-management', 'Role Management');
INSERT INTO `lang_values` (`id`, `type`, `label`, `keyword`, `english`) VALUES
(684, 'user', 'Oops! Invalid invitation', 'oops-invalid-invitation', 'Oops! Invalid invitation'),
(685, 'user', 'This invitation to collaborate in ', 'this-invitation-to-collaborate-in', 'This invitation to collaborate in '),
(686, 'user', 'is expired or has been already used.', 'is-expired-or-has-been-already-used', 'is expired or has been already used.'),
(687, 'user', 'Accept Invitation', 'accept-invitation', 'Accept Invitation'),
(688, 'user', 'Setup your password to collaborate in', 'setup-your-password-to-collaborate', 'Setup your password to collaborate in'),
(689, 'user', 'Add new user', 'add-new-user', 'Add new user'),
(690, 'admin', 'Create New', 'create-new', 'Create New'),
(691, 'admin', 'Countries', 'countries', 'Countries'),
(692, 'admin', 'Country', 'country', 'Country'),
(693, 'admni', 'Country Code', 'country-code', 'Country Code'),
(694, 'admin', 'Currency Name', 'currency-name', 'Currency Name'),
(695, 'admin', 'Currency Code', 'currency-code', 'Currency Code'),
(696, 'admin', 'Currency Symbol', 'currency-symbol', 'Currency Symbol'),
(698, 'admin', 'Delete Confirmation', 'delete-confirmation', 'Delete Confirmation'),
(699, 'admin', 'Are you sure want to delete this business', 'sure-delete-business', 'Are you sure want to delete this business'),
(700, 'admin', 'permanently', 'permanently', 'permanently'),
(701, 'admin', 'This may affect your reports, customers, invoices, estimates, bills', 'affect-business', 'This may affect your reports, customers, invoices, estimates, bills'),
(702, 'admin', 'Role Permissions', 'role-permissions', 'Role Permissions'),
(703, 'front', 'Not Viewed Yet', 'not-viewed', 'Not Viewed Yet'),
(704, 'admin', ' Add Product for both type (Sales & Purchases)', 'product-both', ' Add Product for both type (Sales & Purchases)'),
(705, 'user', 'Payment Records', 'payment-records', 'Payment Records'),
(706, 'user', 'Edit Payment', 'edit-payment', 'Edit Payment'),
(707, 'admin', 'Manage Users', 'manage-users', 'Manage Users'),
(708, 'front', 'Invoice templates', 'invoice_template', 'Invoice templates'),
(709, 'front', 'Get Invoice Payment via Paypal/stripe', 'invoice-payments', 'Get Invoice Payment via Paypal/stripe'),
(710, 'front', 'Multi User Roles', 'user-roles', 'Multi User Roles'),
(711, 'admin', 'Key Id', 'key-id', 'Key Id'),
(712, 'admin', 'Key Secret', 'key-secret', 'Key Secret'),
(713, 'admin', 'Addons', 'addons', 'Addons'),
(714, 'admin', 'Addon', 'addon', 'Addon');

-- --------------------------------------------------------

--
-- Estrutura da tabela `master_config`
--

CREATE TABLE `master_config` (
  `id` int(11) NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `key_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `master_config`
--

INSERT INTO `master_config` (`id`, `field_name`, `group_id`, `key_name`, `description`, `type`) VALUES
(1, 'Site Name', 0, 'site_name', 'data-site name', 'textbox'),
(2, 'Site Logo', 2, 'site_logo', 'data-site logo', 'image'),
(4, 'Stripe Transaction Fees', 4, 'stripe_transaction_fees', 'data-stripe-transaction-fees', 'number'),
(5, 'Apto Mobile Key', 3, 'apto_mobile_key', 'data-apto-mobile-key', 'textbox'),
(6, 'Apto Public Key', 3, 'apto_public_key', 'data-apto-public-key', 'textbox'),
(7, 'Apto Secret Key', 3, 'apto_secret_key', 'data-apto-secret-key', 'textbox'),
(8, 'Apto Sandbox Url', 3, 'apto_sandbox_url', 'data-apto-sandbox-url', 'textbox'),
(9, 'Apto Live Url', 3, 'apto_live_url', 'data-apto-live-url', 'textbox'),
(10, 'Apto Usage Mode', 3, 'apto_usage_mode', 'data-apto-usage-mode', 'textbox'),
(11, 'Apto Source Balance Id', 3, 'apto_source_balance_id', 'data-apto-source-balance-id', 'textbox'),
(12, 'Site Account Prefix', 2, 'site_account_prefix', 'data-site-account-prefix', 'textbox'),
(13, 'Stripe Secret Key', 4, 'stripe_secret_key', 'data-stripe-secret-key', 'textbox'),
(14, 'Stripe Publishable Key', 4, 'stripe_publishable_key', 'data-stripe-publishable-key', 'textbox'),
(15, 'Mail Protocol', 5, 'mail_protocol', 'data-mail-protocol', 'textbox'),
(16, 'Mail SMTP Host', 5, 'mail_smtp_host', 'data-mail-smtp-host', 'textbox'),
(17, 'Mail SMTP Port', 5, 'mail_smtp_port', 'data-mail-smtp-port', 'number'),
(18, 'Mail SMTP Username', 5, 'mail_smtp_username', 'data-mail-smtp-username', 'textbox'),
(19, 'Mail SMTP Password', 5, 'mail_smtp_password', 'data-mail-smtp-password', 'textbox'),
(20, 'Site Email From', 2, 'site_email_from', 'data-site-email-from', 'textbox'),
(21, 'Referral Email Subject', 2, 'referral_email_subject', 'data-referral-email-subject', 'textbox'),
(22, 'Forgot Password Email Subject', 2, 'forgot_password_email_subject', 'data-forgot-password-email-subject', 'textbox'),
(23, 'Set Password Email Link Expiry Time', 2, 'set_password_email_link_expiry_time', 'data-set-password-email-link-expiry-time', 'number'),
(24, 'Reset Password Email Link Expiry Time', 2, 'reset_password_email_link_expiry_time', 'data-reset-password-email-link-expiry-time', 'number'),
(25, 'Support Email', 2, 'support_email', 'data-support-email', 'email'),
(26, 'Reloadly Client Id', 6, 'reloadly_client_id', 'data-reloadly-client-id', 'textbox'),
(27, 'Reloadly Client Secret', 6, 'reloadly_client_secret', 'data-reloadly-client-secret', 'textbox'),
(28, 'Reloadly Usage Mode', 6, 'reloadly_usage_mode', 'data-reloadly-usage-mode', 'textbox'),
(29, 'Reloadly Sandbox Url', 6, 'reloadly_sandbox_url', 'data-reloadly-sandbox-url', 'textbox'),
(30, 'Reloadly Live Url', 6, 'reloadly_live_url', 'data-reloadly-live-url', 'textbox'),
(31, 'Reloadly OAuth Token Url', 6, 'reloadly_oauth_token_url', 'data-reloadly-oauth-token-url', 'textbox'),
(32, 'Reloadly Sandbox Client Id', 6, 'reloadly_sandbox_client_id', 'data-reloadly-sandbox-client-id-', 'textbox'),
(33, 'Reloadly Sandbox Client Secret', 6, 'reloadly_sandbox_client_secret', 'data-reloadly-sandbox-client-secret', 'textbox'),
(34, 'Paypal Usage Mode', 7, 'paypal_usage_mode', 'data-paypal-usage-mode', 'textbox'),
(35, 'Paypal Sandbox Client Id', 7, 'paypal_sandbox_client_id', 'data-paypal-sandbox-client-id', 'textbox'),
(36, 'Paypal Sandbox Secret Key', 7, 'paypal_sandbox_secret_key', 'data-paypal-sandbox-secret-key', 'textbox'),
(37, 'Paypal Sandbox Account Id', 7, 'paypal_sandbox_account_id', 'data-paypal-sandbox-account-id', 'textbox'),
(38, 'Paypal Client Id', 7, 'paypal_client_id', 'data-paypal-client-id', 'textbox'),
(39, 'Paypal Secret Key', 7, 'paypal_secret_key', 'data-paypal-secret-key', 'textbox'),
(40, 'Paypal Account Id', 7, 'paypal_account_id', 'data-paypal-account-id', 'textbox'),
(41, 'Paypal Return Url', 7, 'paypal_return_url', 'data-paypal-return-url', 'url'),
(42, 'Paypal Cancel Url', 7, 'paypal_cancel_url', 'data-paypal-cancel-url', 'url'),
(43, 'copyright', 2, 'copyright', 'data-copyright', 'textbox'),
(44, 'Home Hero1 text', 2, 'home_hero1_text', 'data-home-hero1-text', 'textbox'),
(45, 'Home Hero1 subtext', 2, 'home_hero1_subtext', 'data-home-hero1-subtext', 'text area'),
(46, 'aboutus text', 2, 'aboutus_text', 'data-aboutus-text', 'text area'),
(47, 'services text', 2, 'services_text', 'data-services-text', 'text area'),
(48, 'debitcard_text', 2, 'debitcard_text', 'data-debitcard_text', 'text area'),
(49, 'personalaccount text', 2, 'personalaccount_text', 'data-personalaccount-text', 'text area'),
(50, 'businessaccount text', 2, 'businessaccount_text', 'data-businessaccount-text', 'text area'),
(51, 'paymentservices text', 2, 'paymentservices_text', 'data-paymentservices-text', 'text area'),
(52, 'timemanagement text', 2, 'timemanagement_text', 'data-timemanagement-text', 'text area'),
(53, 'accountingsystem text', 2, 'accountingsystem_text', 'data-accountingsystem-text', 'text area'),
(54, 'chooseus_text1', 2, 'chooseus_text1', 'data-chooseus_text1', 'text area'),
(55, 'chooseus pt1', 2, 'chooseus_pt1', 'data-chooseus-pt1', 'textbox'),
(56, 'chooseus pt2', 2, 'chooseus_pt2', 'data-chooseus-pt2', 'textbox'),
(57, 'chooseus pt3', 2, 'chooseus_pt3', 'data-chooseus-pt3', 'textbox'),
(58, 'chooseus pt4', 2, 'chooseus_pt4', 'data-chooseus-pt4', 'textbox'),
(59, 'chooseus pt5', 2, 'chooseus_pt5', 'data-chooseus-pt5', 'textbox'),
(60, 'chooseus pt1 text', 2, 'chooseus_pt1_text', 'data-chooseus-pt1-text', 'text area'),
(61, 'chooseus pt2 text', 2, 'chooseus_pt2_text', 'data-chooseus-pt2-text', 'text area'),
(62, 'chooseus pt3 text', 2, 'chooseus_pt3_text', 'data-chooseus-pt3-text', 'text area'),
(63, 'chooseus pt4 text', 2, 'chooseus_pt4_text', 'data-chooseus-pt4-text', 'text area'),
(64, 'chooseus pt5 text', 2, 'chooseus_pt5_text', 'data-chooseus-pt5-text', 'text area');

-- --------------------------------------------------------

--
-- Estrutura da tabela `master_group`
--

CREATE TABLE `master_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `master_group`
--

INSERT INTO `master_group` (`id`, `group_name`, `description`) VALUES
(1, 'Firebase', 'Settings related to Firebase'),
(2, 'Site', 'Settings related to Portal'),
(3, 'Apto', 'Settings related to Apto'),
(4, 'Stripe', 'Settings related to Stripe'),
(5, 'Email', 'Settings related to Email'),
(6, 'Reloadly', 'Settings related to Reloadly'),
(7, 'Paypal', 'Settings related to Paypal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `master_wallet_balance`
--

CREATE TABLE `master_wallet_balance` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `alias` varchar(5) COLLATE utf8mb4_bin NOT NULL,
  `currency` varchar(5) COLLATE utf8mb4_bin NOT NULL,
  `balance` double NOT NULL,
  `received_balance` double NOT NULL,
  `on_hold_balance` double NOT NULL,
  `reserve_balance` double NOT NULL,
  `last_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `master_wallet_balance`
--

INSERT INTO `master_wallet_balance` (`id`, `user_id`, `ewallet_id`, `alias`, `currency`, `balance`, `received_balance`, `on_hold_balance`, `reserve_balance`, `last_updated_at`) VALUES
(12, 38, 'GEEFTO784151', 'USD', 'USD', 17.26, 0, 0, 0, '2021-08-20 15:31:03'),
(13, 6, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'USD', 'USD', 6198.82, 0, 0, 0, '2021-08-24 01:28:42'),
(14, 44, 'GEEFTO300690', 'USD', 'USD', 14.46, 0, 0, 0, '2021-08-18 18:30:29'),
(15, 74, 'GEEFTO691034', 'USD', 'USD', 19.64, 0, 0, 0, '2021-08-20 10:11:09'),
(18, 37, 'OMNI477998', 'USD', 'USD', 1, 0, 0, 0, '2021-08-19 20:18:47'),
(19, 76, 'GEEFTO696878', 'USD', 'USD', 1.82, 0, 0, 0, '2021-09-16 21:21:37'),
(20, 89, 'GEEFTO657088', 'USD', 'USD', 43.2, 0, 0, 0, '2021-08-25 00:27:32'),
(21, 90, 'GEEFTO846824', 'USD', 'USD', 0.96, 0, 0, 0, '2021-08-26 10:39:56'),
(22, 38, 'ewallet_3f12273e31fcaf27e8021e4f79191273', 'USD', 'USD', 48.2, 0, 0, 0, '2021-09-06 14:17:32'),
(23, 25, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'USD', 'USD', 1886.4, 0, 0, 0, '2021-10-16 03:30:18'),
(24, 42, 'GEEFTO365378', 'USD', 'USD', 9.64, 0, 0, 0, '2021-09-25 04:58:40'),
(25, 159, 'XENIO574328', 'USD', 'USD', 192.8, 0, 0, 0, '2021-10-16 14:02:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `meeting_schedule`
--

CREATE TABLE `meeting_schedule` (
  `id` int(11) NOT NULL,
  `meetingid` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `meetingsubject` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `ewallet_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `meeting_schedule`
--

INSERT INTO `meeting_schedule` (`id`, `meetingid`, `meetingsubject`, `datetime`, `timezone`, `created_at`, `ewallet_id`, `user_id`) VALUES
(1, '65654564564', 'Test Meeting', '2021-07-28 22:40:27', 'Asia/Kolkata', '2021-07-25 13:11:34', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 6),
(2, '66555777', 'New Web Form', '2021-07-30 13:00:00', '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi', '2021-07-25 13:30:15', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `myreferal`
--

CREATE TABLE `myreferal` (
  `id` int(11) NOT NULL,
  `ref_email_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `ref_code` int(11) NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `fri_email_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `myreferal`
--

INSERT INTO `myreferal` (`id`, `ref_email_id`, `ref_code`, `first_name`, `last_name`, `fri_email_id`, `created_at`) VALUES
(5, 'nash81@gmail.com', 922297, 'Business', 'Business', 'business1@xenio.in', '2021-06-28 02:18:04'),
(6, 'marvinade@yahoo.com', 392582, 'Ayo', 'Adejugbe', 'marvinade@yahoo.com', '2021-08-07 16:35:48'),
(8, 'nash81@gmail.com', 922297, 'George', 'Oluwaboro', 'techforhumanity@gmail.com', '2021-08-08 15:58:37'),
(9, 'techforhumanity@gmail.com', 272112, 'George', 'Brickstone', 'brickstonecpa@gmail.com', '2021-08-08 17:35:19'),
(10, 'dul_boi@icloud.com', 113167, 'Abdulkadir ', 'Yusuf', 'abdulkadiryusuf778@gmail.com', '2021-08-08 20:07:52'),
(11, 'dul_boi@icloud.com', 113167, 'Abdulkadir ', 'Yusuf', 'dul_boi@icloud.com', '2021-08-08 20:08:58'),
(12, 'techforhumanity@gmail.com', 272112, 'Jean', 'Fogham', 'jboscoamad@gmail.com', '2021-08-08 20:53:26'),
(13, 'dul_boi@icloud.com', 113167, 'Abdul', 'Aliyu', 'abdullahibabaaliyu@gmail.com', '2021-08-09 12:38:41'),
(14, 'techforhumanity@gmail.com', 272112, 'Ore-Tayo', 'Funsho', 'ofunsho@prophasisconsults.com', '2021-08-09 23:38:29'),
(15, 'ofunsho@prophasisconsults.com', 305455, 'Olamide', 'Funsho', 'tirofunsho@gmail.com', '2021-08-10 00:57:59'),
(16, 'techforhumanity@gmail.com', 272112, 'Michael', 'Evans', 'myrewardsclub@yahoo.com', '2021-08-10 02:23:38'),
(17, 'techforhumanity@gmail.com', 272112, 'Similolu', 'Akinnusi', 'simi.akinnusi@mintft.com', '2021-08-10 09:27:58'),
(18, 'techforhumanity@gmail.com', 272112, 'Kolawole', 'Akinmuyiwa', 'Kola@prowheelsmag.com', '2021-08-10 11:56:01'),
(19, 'techforhumanity@gmail.com', 272112, 'kolapo', 'ogungbile', 'kogungbile@gmail.com', '2021-08-10 16:00:39'),
(20, 'techforhumanity@gmail.com', 272112, 'Ana', 'Everett', 'solutionsae@yahoo.com', '2021-08-11 14:43:49'),
(21, 'techforhumanity@gmail.com', 272112, 'Gbola', 'Adiat', 'hhgconsult@gmail.com', '2021-08-12 15:14:33'),
(22, 'techforhumanity@gmail.com', 272112, 'Ibukunoluwapo', 'Oluwaboro', 'enochibk@gmail.com', '2021-08-12 15:38:54'),
(23, 'techforhumanity@gmail.com', 272112, 'Olugbenga', 'Wahab', 'wahabolugbenga@gmail.com', '2021-08-13 13:28:13'),
(24, 'techforhumanity@gmail.com', 272112, 'Abiodun', 'Olasanoye', 'abiodunolasanoye@gmail.com', '2021-08-15 18:55:44'),
(25, 'techforhumanity@gmail.com', 272112, 'Olutoye ', 'Bello', 'toyebello@bandbllc.com', '2021-08-17 20:09:27'),
(26, 'techforhumanity@gmail.com', 272112, 'Donald', 'Chapman', 'dchapman7@babson.edu', '2021-08-18 15:54:48'),
(27, 'techforhumanity@gmail.com', 272112, 'Peter', 'Ojo', 'peter@peterojo.com', '2021-08-18 18:22:06'),
(28, 'dul_boi@icloud.com', 113167, 'Abdulfatah', 'Suleiman', 'abdulsuleymann1234@icloud.com', '2021-08-20 14:47:45'),
(29, 'ofunsho@prophasisconsults.com', 305455, 'ADEBANKE', 'OLUFEMI', 'BFUNSHO@YAHOO.COM', '2021-08-20 20:40:20'),
(30, 'abdulsuleymann1234@icloud.com', 795985, 'Aothman', 'Ladan', 'aothmanladan@gmail.com', '2021-08-21 03:09:19'),
(31, 'techforhumanity@gmail.com', 272112, 'Kolawole', 'Akinmuyiwa', 'kola@prowheelsmag.com', '2021-08-22 00:25:07'),
(32, 'toadejumo@gmail.com', 385692, 'Taiwo Oluyomi', 'Adejumo', 'toadejumo@gmail.com', '2021-08-22 05:10:38'),
(33, 'techforhumanity@gmail.com', 272112, 'Olusegun ', 'Palmer ', 'alabapalma@gmail.com', '2021-08-22 21:14:41'),
(34, 'techforhumanity@gmail.com', 272112, 'Godfrey', 'Phillips', 'phillipsgodfrey1@gmail.com', '2021-08-23 09:56:30'),
(35, 'techforhumanity@gmail.com', 272112, 'Ekunda', 'Wonodi', 'eowonodi@gmail.com', '2021-08-24 00:13:04'),
(36, 'phillipsgodfrey1@gmail.com', 219692, 'Tunde ', 'Adegboye', 'tndadegboye@att.net', '2021-08-24 10:08:51'),
(37, 'techforhumanity@gmail.com', 272112, 'Gifted', 'Steppers', 'giftedsteppersdance@gmail.com', '2021-08-24 10:41:35'),
(38, 'techforhumanity@gmail.com', 272112, 'ola', 'famuyiwa', 'olareal@gmail.com', '2021-08-25 00:08:44'),
(39, 'phillipsgodfrey1@gmail.com', 219692, 'Joel', 'Phillips', 'jojophil1357@hotmail.com', '2021-08-27 12:44:12'),
(40, 'phillipsgodfrey1@gmail.com', 219692, 'Julius', 'Akpojiyovwi', 'vote27002@yahoo.co.uk', '2021-08-27 13:48:58'),
(41, 'phillipsgodfrey1@gmail.com', 219692, 'Abosede', 'Popoola', 'bosepopoola1@gmail.com', '2021-08-27 14:55:49'),
(42, 'phillipsgodfrey1@gmail.com', 219692, 'Anthony', 'Rumuna', 'tyjindustries@hotmail.com', '2021-08-27 15:42:52'),
(43, 'techforhumanity@gmail.com', 272112, 'Akinlolu', 'Oluboro ', 'sakinlolu@gmail.com', '2021-08-28 12:55:24'),
(44, 'sakinlolu@gmail.com', 406445, 'Titilayo ', 'Oluboro', 'kadijamotunrayo@gmail.com', '2021-08-28 21:29:11'),
(45, 'techforhumanity@gmail.com', 272112, 'Frank ', 'Alarapon', 'ariesfrank2001@yahoo.com', '2021-08-30 03:46:07'),
(46, 'techforhumanity@gmail.com', 272112, 'Ademola', 'Adelaja', 'aadelaja1@yahoo.com', '2021-09-01 19:44:31'),
(47, 'techforhumanity@gmail.com', 272112, 'Abiodun', 'Durosinmi ', 'durob2012@gmail.com', '2021-09-03 21:09:19'),
(48, 'info@roumarketing.com', 595379, 'Dr Roussan', 'Etienne Jr.', 'info@roumarketing.com', '2021-09-05 11:36:10'),
(49, 'rou@roumarketing.com', 860163, 'Dr Roussan', 'Etienne Jr.', 'rou@roumarketing.com', '2021-09-05 11:53:34'),
(50, 'techforhumanity@gmail.com', 272112, 'Amani ', 'Talbot', 'cashoutdre59@gmail.com', '2021-09-05 17:16:35'),
(51, 'techforhumanity@gmail.com', 272112, 'Eva', 'Thorne', 'cocoref@gmail.com', '2021-09-05 17:24:05'),
(52, 'fhgolnett@gmail.com', 985835, 'Hassan', 'Foipon', 'fhgolnett@gmail.com', '2021-09-05 17:54:47'),
(53, 'info@roumarketing.com', 595379, 'Dale', 'Wafer', 'dewafer@aol.com', '2021-09-06 20:22:18'),
(54, 'techforhumanity@gmail.com', 272112, 'George', 'Oluwaboro', 'goluwaboro@gmail.com', '2021-09-07 04:02:00'),
(55, 'techforhumanity@gmail.com', 272112, 'Waziri ', 'Ibrahim ', 'wazconsultant2@gmail.com', '2021-09-12 18:38:47'),
(56, 'techforhumanity@gmail.com', 272112, 'Abu', 'Bah', 'abubah74@gmail.com', '2021-09-18 16:24:04'),
(57, 'usojoolusegunfunmiojo195666@gmail.com', 272401, 'Olusegun Edward ', 'Ojo', 'usojoolusegunfunmiojo195666@gmail.com', '2021-09-19 14:57:13'),
(58, 'usojoolusegunfunmiojo195666@gmail.com', 272401, 'FAFOWORA ', 'KEHINDE JOSHUA ', 'mkennyjoshua@yahoo.com', '2021-09-19 16:15:20'),
(59, 'techforhumanity@gmail.com', 272112, 'Adesina', 'Akinjokun', 'aaakanjijokun@gmail.com', '2021-09-20 09:45:46'),
(60, 'techforhumanity@gmail.com', 272112, 'Aishat', 'Yusuf', 'aishaayusuf@yahoo.com', '2021-09-25 04:51:51'),
(61, 'phillipsgodfrey1@gmail.com', 219692, 'Nicholas', 'Phillips', 'nicholas1phillips@hotmail.com', '2021-09-25 18:07:42'),
(62, 'phillipsgodfrey1@gmail.com', 219692, 'Abigail', 'Phillips', 'abigail1698@outlook.com', '2021-09-25 18:15:38'),
(63, 'techforhumanity@gmail.com', 272112, 'Mark', 'Boswell', 'mboswell05@yahoo.com', '2021-10-04 14:54:09'),
(64, 'mboswell05@yahoo.com', 840651, 'Mark', 'Boswell', 'trayteboswell1@yahoo.com', '2021-10-05 21:42:50'),
(65, 'techforhumanity@gmail.com', 272112, 'Catherine', 'Ngongoseke', 'catherinengongoseke@gmail.com', '2021-10-05 23:17:11'),
(66, 'philikod@gmail.com', 113905, 'Philip', 'Ikodor', 'philikod@gmail.com', '2021-10-05 23:47:30'),
(67, 'techforhumanity@gmail.com', 272112, 'George', 'Olu', 'george@psacpa.com', '2021-10-08 14:26:26'),
(68, 'phillipsgodfrey1@gmail.com', 219692, 'Olayinka Abiola', 'Lawson', 'iyunola@yahoo.com', '2021-10-10 18:48:21'),
(69, 'techforhumanity@gmail.com', 272112, 'Elsie ', 'Ezekiel ', 'elsieezy4real@gmail.com', '2021-10-14 17:04:01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(10, 'nash81@gmail.com'),
(11, ''),
(12, ''),
(13, ''),
(14, NULL),
(15, NULL),
(16, NULL),
(17, NULL),
(18, NULL),
(19, NULL),
(20, ''),
(21, 'geefto.com@buycodeshop.com'),
(22, NULL),
(23, NULL),
(24, NULL),
(25, 'joel.patenaude@j2partnersinc.com'),
(26, 'mdarbaz228@gmail.com'),
(27, NULL),
(28, NULL),
(29, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `notification` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `is_read` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `monthly_price` decimal(10,2) DEFAULT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `dis_month` int(11) NOT NULL DEFAULT 0,
  `dis_year` int(11) NOT NULL DEFAULT 0,
  `is_special` int(11) NOT NULL DEFAULT 0,
  `is_active` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `package`
--

INSERT INTO `package` (`id`, `name`, `slug`, `price`, `monthly_price`, `bill_type`, `dis_month`, `dis_year`, `is_special`, `is_active`) VALUES
(1, 'Basic', 'basic', '0.00', '0.00', 'year', 10, 0, 0, 1),
(2, 'Standard', 'standared', '35.00', '15.00', 'year', 20, 0, 1, 0),
(3, 'Premium', 'premium', '1000.00', '30.00', 'year', 50, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `package_features`
--

CREATE TABLE `package_features` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `basic` varchar(255) DEFAULT NULL,
  `standared` varchar(255) DEFAULT NULL,
  `premium` varchar(255) DEFAULT NULL,
  `year_basic` int(11) DEFAULT NULL,
  `year_standared` int(11) DEFAULT NULL,
  `year_premium` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `package_features`
--

INSERT INTO `package_features` (`id`, `name`, `slug`, `basic`, `standared`, `premium`, `year_basic`, `year_standared`, `year_premium`, `type`, `text`) VALUES
(1, 'Invoices', 'invoice', '-2', '-2', '-2', -2, -2, -2, '', NULL),
(2, 'Estimates', 'estimate', '-2', '-2', '-2', -2, -2, -2, '', NULL),
(3, 'Customers', 'customer', '-2', '-2', '-2', -2, -2, -2, '', NULL),
(4, 'Business', 'business', '-2', '-2', '-2', -2, -2, -2, '', ''),
(5, 'Invoice templates', 'invoice_template', '-2', '-2', '-2', -2, -2, -2, '', 'Set value 1-6'),
(6, 'Get Invoice Payment via Paypal/stripe', 'invoice-payments', '-2', '-2', '-2', -2, -2, -2, '', 'Set -1 for Yes & 0 for No'),
(7, 'Multi User Roles', 'user-roles', '-2', '-2', '-2', -2, -2, -2, '', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `details` longtext DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `paylink`
--

CREATE TABLE `paylink` (
  `id` int(11) NOT NULL,
  `linkid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `ewallet_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `amount` int(11) NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `currency` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `paylink`
--

INSERT INTO `paylink` (`id`, `linkid`, `email_id`, `description`, `ewallet_id`, `amount`, `country`, `currency`, `created_at`) VALUES
(8, 'Omni77485699928', 'nash81@gmail.com', '', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 50, 'IN', 'AED', '2021-06-11 13:14:48'),
(9, 'Omni27640368930', 'nash81@gmail.com', '', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 50, 'IN', 'BMD', '2021-06-11 13:27:55'),
(10, 'Omni58308648900', 'nash81@gmail.com', '', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 100, 'IN', 'USD', '2021-06-11 17:49:35'),
(11, 'Omni49357609328', 'nash81@gmail.com', '', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 50, 'IN', 'AUD', '2021-06-11 17:53:09'),
(12, 'Omni86482907431', 'nash81@gmail.com', '', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 500, 'IN', 'THB', '2021-06-11 18:02:54'),
(13, 'Omni39212863541', 'nash81@gmail.com', 'For Tuxedo', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 100, 'IN', 'AUD', '2021-06-11 18:13:47'),
(14, 'Omni51664674189', 'nash81@gmail.com', 'Test Payments', 'ewallet_3f12273e31fcaf27e8021e4f79191273', 50, 'IN', 'AED', '2021-06-16 16:23:05'),
(15, 'Paylink74043721139', 'nash81@gmail.com', 'Testing of Payment Links', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 1250, 'IN', 'INR', '2021-07-15 21:19:04'),
(16, 'Paylink47307508030', 'nash81@gmail.com', 'Tese', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 560, 'IN', 'INR', '2021-07-16 02:43:25'),
(17, 'Paylink21565315579', 'accounts@xenio.in', 'Test Merchant Services', 'Omni750618', 100, '', 'USD', '2021-07-16 03:37:59'),
(18, 'Paylink37048330742', 'nash81@gmail.com', 'Test', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 300, 'US', 'USD', '2021-08-05 13:56:50'),
(19, 'Paylink75343804426', 'brickstonecpa@gmail.com', 'Test Transactions', 'GEEFTO646184', 20, 'United States', 'USD', '2021-08-08 17:36:55'),
(20, 'Paylink40828285159', 'business2@xenio.in', 'Test', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 50, 'United States', 'USD', '2021-09-20 18:57:34'),
(21, 'Paylink17225076934', 'business2@xenio.in', 'Test', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 1, 'United States', 'USD', '2021-09-24 12:06:00'),
(22, 'Paylink50084903193', 'business2@xenio.in', 'Testing Payment', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 0, 'United States', 'USD', '2021-09-24 12:07:03'),
(23, 'Paylink67587673317', 'business2@xenio.in', 'Test Payment for Martin', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 100, 'United States', 'USD', '2021-10-23 11:30:36');

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `puid` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package` varchar(255) DEFAULT NULL,
  `billing_type` varchar(255) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `txn_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  `expire_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `payment`
--

INSERT INTO `payment` (`id`, `puid`, `user_id`, `package`, `billing_type`, `payment_type`, `txn_id`, `amount`, `status`, `created_at`, `expire_on`) VALUES
(1, '94682', 2, '1', 'monthly', NULL, NULL, '0.00', 'verified', '2021-07-15', '2021-08-15'),
(2, '01328', 3, '1', 'monthly', NULL, NULL, '0.00', 'verified', '2021-07-15', '2021-08-15');

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment_advance`
--

CREATE TABLE `payment_advance` (
  `id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment_records`
--

CREATE TABLE `payment_records` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `business_id` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `convert_amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `type` varchar(255) DEFAULT 'income',
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `payment_records`
--

INSERT INTO `payment_records` (`id`, `invoice_id`, `business_id`, `customer_id`, `amount`, `convert_amount`, `payment_date`, `payment_method`, `note`, `type`, `created_at`) VALUES
(1, 0, '', 0, '0.00', '0.00', '2021-08-22', 0, NULL, 'income', NULL),
(2, 0, '', 0, '0.00', '0.00', '2021-08-23', 0, NULL, 'income', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `payouts`
--

CREATE TABLE `payouts` (
  `id` bigint(20) NOT NULL,
  `payout_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `sender_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `beneficiary_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` varchar(15) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_dump` text COLLATE utf8mb4_bin DEFAULT NULL,
  `response_dump` text COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `payouts`
--

INSERT INTO `payouts` (`id`, `payout_id`, `sender_id`, `beneficiary_id`, `ewallet_id`, `amount`, `description`, `created_at`, `request_dump`, `response_dump`) VALUES
(1, 'payout_0204b3153fca2b32f443e380746d9e7c', 'sender_709c20eb118b658d0e9b6174ce347a7c', 'beneficiary_9f10357fd8dbce7dfe3fa94e7df0bb3e', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 50, 'Testing of Description in Payouts', '1624850891', '{\"beneficiary\":{\"first_name\":\"Mohammed\",\"last_name\":\"Altaf\",\"account_number\":\"1234567890\",\"identification_type\":\"work_permit\",\"identification_value\":\"1234567890\"},\"beneficiary_country\":\"PH\",\"beneficiary_entity_type\":\"individual\",\"description\":\"Testing of Description in Payouts\",\"confirm_automatically\":true,\"ewallet\":\"ewallet_b43aed61d43f74d82b022422cfa26e22\",\"payout_currency\":\"PHP\",\"payout_method_type\":\"ph_allied_bank\",\"sender\":{\"first_name\":\"Mohammed\",\"last_name\":\"Altaf\",\"identification_type\":\"identification_id\",\"identification_value\":\"1234567890\",\"phone_number\":\"0476857122\",\"occupation\":\"Professional\",\"source_of_income\":\"salary\",\"date_of_birth\":\"02\\/03\\/1990\",\"address\":\"14 Springvale Road Glen Waverley VIC Australia\",\"purpose_code\":\"investment_income\",\"beneficiary_relationship\":\"customer\"},\"sender_amount\":\"50\",\"sender_country\":\"IN\",\"sender_currency\":\"PHP\",\"sender_entity_type\":\"individual\",\"statement_descriptor\":\"OMNI UPS Transaction\"}', '\"{\\\"status\\\":{\\\"error_code\\\":\\\"\\\",\\\"status\\\":\\\"SUCCESS\\\",\\\"message\\\":\\\"\\\",\\\"response_code\\\":\\\"\\\",\\\"operation_id\\\":\\\"340c6909-9068-4759-bac6-a58fba404146\\\"},\\\"data\\\":{\\\"id\\\":\\\"payout_0204b3153fca2b32f443e380746d9e7c\\\",\\\"payout_type\\\":\\\"bank\\\",\\\"payout_method_type\\\":\\\"ph_allied_bank\\\",\\\"amount\\\":50,\\\"payout_currency\\\":\\\"PHP\\\",\\\"sender_amount\\\":50,\\\"sender_currency\\\":\\\"PHP\\\",\\\"status\\\":\\\"Created\\\",\\\"sender_country\\\":\\\"IN\\\",\\\"sender\\\":{\\\"id\\\":\\\"sender_709c20eb118b658d0e9b6174ce347a7c\\\",\\\"last_name\\\":\\\"Altaf\\\",\\\"first_name\\\":\\\"Mohammed\\\",\\\"country\\\":\\\"IN\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"14 Springvale Road Glen Waverley VIC Australia\\\",\\\"name\\\":\\\"Mohammed Altaf\\\",\\\"date_of_birth\\\":\\\"02\\/03\\/1990\\\",\\\"phone_number\\\":\\\"0476857122\\\",\\\"currency\\\":\\\"PHP\\\",\\\"identification_type\\\":\\\"identification_id\\\",\\\"identification_value\\\":\\\"1234567890\\\",\\\"purpose_code\\\":\\\"investment_income\\\",\\\"beneficiary_relationship\\\":\\\"customer\\\",\\\"source_of_income\\\":\\\"salary\\\",\\\"occupation\\\":\\\"Professional\\\"},\\\"beneficiary_country\\\":\\\"PH\\\",\\\"beneficiary\\\":{\\\"id\\\":\\\"beneficiary_9f10357fd8dbce7dfe3fa94e7df0bb3e\\\",\\\"last_name\\\":\\\"Altaf\\\",\\\"first_name\\\":\\\"Mohammed\\\",\\\"country\\\":\\\"PH\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"name\\\":\\\"Mohammed Altaf\\\",\\\"account_number\\\":\\\"1234567890\\\",\\\"currency\\\":\\\"PHP\\\",\\\"identification_type\\\":\\\"work_permit\\\",\\\"identification_value\\\":\\\"1234567890\\\"},\\\"fx_rate\\\":1,\\\"instructions\\\":{\\\"name\\\":\\\"instructions\\\",\\\"steps\\\":[{\\\"step1\\\":\\\"The funds will be transferred to the provided account details of the beneficiary .\\\"}]},\\\"ewallets\\\":[{\\\"ewallet_id\\\":\\\"ewallet_b43aed61d43f74d82b022422cfa26e22\\\",\\\"amount\\\":50,\\\"percent\\\":100}],\\\"metadata\\\":{},\\\"description\\\":\\\"Testing of Description in Payouts\\\",\\\"created_at\\\":1624850891,\\\"payout_fees\\\":null,\\\"expiration\\\":null,\\\"paid_at\\\":null,\\\"identifier_type\\\":null,\\\"identifier_value\\\":null,\\\"error\\\":null,\\\"paid_amount\\\":0,\\\"statement_descriptor\\\":\\\"OMNI UPS Transaction\\\",\\\"gc_error_code\\\":null}}\"'),
(3, 'payout_776a42bbbcda768cb7dfc5cea4309f02', 'sender_2cc3fdd4bc35e43f0e10e220c302c48c', 'beneficiary_abc7f989d2efc5d2f02b771164ae4625', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 150, 'This is a test message', '1624886446', '{\"beneficiary\":{\"payment_type\":\"priority\",\"address\":\"C2 1103 Supertech\",\"city\":\"Ghaziabad\",\"country\":\"AE\",\"first_name\":\"Nirav\",\"last_name\":\"Shah\",\"iban\":\"SK7812955172353646008543\",\"bic_swift\":\"12312312\"},\"beneficiary_country\":\"AE\",\"beneficiary_entity_type\":\"individual\",\"description\":\"This is a test message\",\"confirm_automatically\":true,\"ewallet\":\"ewallet_b43aed61d43f74d82b022422cfa26e22\",\"payout_currency\":\"AED\",\"payout_method_type\":\"ae_general_bank\",\"sender\":{\"country\":\"AE\",\"city\":\"Sharjah\",\"address\":\"C 205,A SATYAM SPRINGS,OFF BKSD MARG,DEONAR,  NR USV LIMITED\",\"first_name\":\"Nirav\",\"last_name\":\"Shah\",\"date_of_birth\":\"17\\/12\\/1979\",\"purpose_code\":\"salary\"},\"sender_amount\":\"150\",\"sender_country\":\"IN\",\"sender_currency\":\"USD\",\"sender_entity_type\":\"individual\",\"statement_descriptor\":\"OMNI UPS Transaction\"}', '\"{\\\"status\\\":{\\\"error_code\\\":\\\"\\\",\\\"status\\\":\\\"SUCCESS\\\",\\\"message\\\":\\\"\\\",\\\"response_code\\\":\\\"\\\",\\\"operation_id\\\":\\\"e0b1093d-f890-4f01-9497-6aa57e024910\\\"},\\\"data\\\":{\\\"id\\\":\\\"payout_776a42bbbcda768cb7dfc5cea4309f02\\\",\\\"payout_type\\\":\\\"bank\\\",\\\"payout_method_type\\\":\\\"ae_general_bank\\\",\\\"amount\\\":534.45,\\\"payout_currency\\\":\\\"AED\\\",\\\"sender_amount\\\":150,\\\"sender_currency\\\":\\\"USD\\\",\\\"status\\\":\\\"Created\\\",\\\"sender_country\\\":\\\"IN\\\",\\\"sender\\\":{\\\"id\\\":\\\"sender_2cc3fdd4bc35e43f0e10e220c302c48c\\\",\\\"last_name\\\":\\\"Shah\\\",\\\"first_name\\\":\\\"Nirav\\\",\\\"country\\\":\\\"IN\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"C 205,A SATYAM SPRINGS,OFF BKSD MARG,DEONAR,  NR USV LIMITED\\\",\\\"name\\\":\\\"Nirav Shah\\\",\\\"date_of_birth\\\":\\\"17\\/12\\/1979\\\",\\\"city\\\":\\\"Sharjah\\\",\\\"currency\\\":\\\"USD\\\",\\\"purpose_code\\\":\\\"salary\\\"},\\\"beneficiary_country\\\":\\\"AE\\\",\\\"beneficiary\\\":{\\\"id\\\":\\\"beneficiary_abc7f989d2efc5d2f02b771164ae4625\\\",\\\"last_name\\\":\\\"Shah\\\",\\\"first_name\\\":\\\"Nirav\\\",\\\"country\\\":\\\"AE\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"C2 1103 Supertech\\\",\\\"name\\\":\\\"Nirav Shah\\\",\\\"city\\\":\\\"Ghaziabad\\\",\\\"currency\\\":\\\"AED\\\",\\\"bic_swift\\\":\\\"12312312\\\",\\\"iban\\\":\\\"SK7812955172353646008543\\\",\\\"payment_type\\\":\\\"priority\\\"},\\\"fx_rate\\\":3.563004,\\\"instructions\\\":{\\\"name\\\":\\\"instructions\\\",\\\"steps\\\":[{\\\"step1\\\":\\\"The funds will be transferred to the provided account details of the beneficiary .\\\"}]},\\\"ewallets\\\":[{\\\"ewallet_id\\\":\\\"ewallet_b43aed61d43f74d82b022422cfa26e22\\\",\\\"amount\\\":150,\\\"percent\\\":100}],\\\"metadata\\\":{},\\\"description\\\":\\\"This is a test message\\\",\\\"created_at\\\":1624886446,\\\"payout_fees\\\":null,\\\"expiration\\\":null,\\\"paid_at\\\":null,\\\"identifier_type\\\":null,\\\"identifier_value\\\":null,\\\"error\\\":null,\\\"paid_amount\\\":0,\\\"statement_descriptor\\\":\\\"OMNI UPS Transaction\\\",\\\"gc_error_code\\\":null}}\"'),
(4, 'payout_19db13d5ed2fbd2ff16f18d8567cf191', 'sender_1cc221608a0c17747a818aa634e96845', 'beneficiary_ceabbbe252b33f9a3697b0460315f872', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 50, 'Reebok Sports Shoes for Sale', '1625009823', '{\"beneficiary\":{\"payment_type\":\"priority\",\"address\":\"Jeypore\",\"city\":\"Jeypore\",\"country\":\"IN\",\"first_name\":\"Mohammed\",\"last_name\":\"Afzal\",\"iban\":\"88888888888888888\",\"bic_swift\":\"88908088\"},\"beneficiary_country\":\"GB\",\"beneficiary_entity_type\":\"individual\",\"description\":\"Reebok Sports Shoes for Sale\",\"confirm_automatically\":true,\"ewallet\":\"ewallet_b43aed61d43f74d82b022422cfa26e22\",\"payout_currency\":\"EUR\",\"payout_method_type\":\"gb_general_bank\",\"sender\":{\"country\":\"IN\",\"city\":\"Bengaluru\",\"address\":\"19\\/58,Almidrar,\",\"first_name\":\"Mohammed\",\"last_name\":\"Arbaz\",\"date_of_birth\":\"03\\/02\\/1990\"},\"sender_amount\":\"50\",\"sender_country\":\"IN\",\"sender_currency\":\"USD\",\"sender_entity_type\":\"individual\",\"statement_descriptor\":\"OMNI UPS Transaction\"}', '\"{\\\"status\\\":{\\\"error_code\\\":\\\"\\\",\\\"status\\\":\\\"SUCCESS\\\",\\\"message\\\":\\\"\\\",\\\"response_code\\\":\\\"\\\",\\\"operation_id\\\":\\\"2f20393d-74ad-4376-8ca5-e301bb2824b6\\\"},\\\"data\\\":{\\\"id\\\":\\\"payout_19db13d5ed2fbd2ff16f18d8567cf191\\\",\\\"payout_type\\\":\\\"bank\\\",\\\"payout_method_type\\\":\\\"gb_general_bank\\\",\\\"amount\\\":40.76,\\\"payout_currency\\\":\\\"EUR\\\",\\\"sender_amount\\\":50,\\\"sender_currency\\\":\\\"USD\\\",\\\"status\\\":\\\"Created\\\",\\\"sender_country\\\":\\\"IN\\\",\\\"sender\\\":{\\\"id\\\":\\\"sender_1cc221608a0c17747a818aa634e96845\\\",\\\"last_name\\\":\\\"Arbaz\\\",\\\"first_name\\\":\\\"Mohammed\\\",\\\"country\\\":\\\"IN\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"19\\/58,Almidrar,\\\",\\\"name\\\":\\\"Mohammed Arbaz\\\",\\\"date_of_birth\\\":\\\"03\\/02\\/1990\\\",\\\"city\\\":\\\"Bengaluru\\\",\\\"currency\\\":\\\"USD\\\"},\\\"beneficiary_country\\\":\\\"GB\\\",\\\"beneficiary\\\":{\\\"id\\\":\\\"beneficiary_ceabbbe252b33f9a3697b0460315f872\\\",\\\"last_name\\\":\\\"Afzal\\\",\\\"first_name\\\":\\\"Mohammed\\\",\\\"country\\\":\\\"GB\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"Jeypore\\\",\\\"name\\\":\\\"Mohammed Afzal\\\",\\\"city\\\":\\\"Jeypore\\\",\\\"currency\\\":\\\"EUR\\\",\\\"bic_swift\\\":\\\"88908088\\\",\\\"iban\\\":\\\"88888888888888888\\\",\\\"payment_type\\\":\\\"priority\\\"},\\\"fx_rate\\\":0.81512495,\\\"instructions\\\":{\\\"name\\\":\\\"instructions\\\",\\\"steps\\\":[{\\\"step1\\\":\\\"The funds will be transferred to the provided account details of the beneficiary .\\\"}]},\\\"ewallets\\\":[{\\\"ewallet_id\\\":\\\"ewallet_b43aed61d43f74d82b022422cfa26e22\\\",\\\"amount\\\":50,\\\"percent\\\":100}],\\\"metadata\\\":{},\\\"description\\\":\\\"Reebok Sports Shoes for Sale\\\",\\\"created_at\\\":1625009823,\\\"payout_fees\\\":null,\\\"expiration\\\":null,\\\"paid_at\\\":null,\\\"identifier_type\\\":null,\\\"identifier_value\\\":null,\\\"error\\\":null,\\\"paid_amount\\\":0,\\\"statement_descriptor\\\":\\\"OMNI UPS Transaction\\\",\\\"gc_error_code\\\":null}}\"'),
(5, 'payout_d513579c20f876d04debdf58b28354ec', 'sender_4ed269b7c17df6038d064e1eade8b917', 'beneficiary_975b9520d2a3bb4ee510c014e4cbd8f7', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 150, 'This is a test transfer for date format', '1625015907', '{\"beneficiary\":{\"payment_type\":\"priority\",\"address\":\"C2 1103 Supertech\",\"city\":\"Ghaziabad\",\"country\":\"IN\",\"first_name\":\"Nirav\",\"last_name\":\"Shah\",\"iban\":\"SK7812955172353646008543\",\"bic_swift\":\"12312312\"},\"beneficiary_country\":\"GB\",\"beneficiary_entity_type\":\"individual\",\"description\":\"This is a test transfer for date format\",\"confirm_automatically\":true,\"ewallet\":\"ewallet_b43aed61d43f74d82b022422cfa26e22\",\"payout_currency\":\"GBP\",\"payout_method_type\":\"gb_general_bank\",\"sender\":{\"country\":\"GB\",\"city\":\"Ghaziabad\",\"address\":\"C2 1103 Supertech\",\"first_name\":\"Nirav\",\"last_name\":\"Shah\",\"date_of_birth\":\"30\\/12\\/1979\"},\"sender_amount\":\"150\",\"sender_country\":\"IN\",\"sender_currency\":\"USD\",\"sender_entity_type\":\"individual\",\"statement_descriptor\":\"OMNI UPS Transaction\"}', '\"{\\\"status\\\":{\\\"error_code\\\":\\\"\\\",\\\"status\\\":\\\"SUCCESS\\\",\\\"message\\\":\\\"\\\",\\\"response_code\\\":\\\"\\\",\\\"operation_id\\\":\\\"b1252f52-5d4b-4256-843c-9ee138842c99\\\"},\\\"data\\\":{\\\"id\\\":\\\"payout_d513579c20f876d04debdf58b28354ec\\\",\\\"payout_type\\\":\\\"bank\\\",\\\"payout_method_type\\\":\\\"gb_general_bank\\\",\\\"amount\\\":105.12,\\\"payout_currency\\\":\\\"GBP\\\",\\\"sender_amount\\\":150,\\\"sender_currency\\\":\\\"USD\\\",\\\"status\\\":\\\"Created\\\",\\\"sender_country\\\":\\\"IN\\\",\\\"sender\\\":{\\\"id\\\":\\\"sender_4ed269b7c17df6038d064e1eade8b917\\\",\\\"last_name\\\":\\\"Shah\\\",\\\"first_name\\\":\\\"Nirav\\\",\\\"country\\\":\\\"IN\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"C2 1103 Supertech\\\",\\\"name\\\":\\\"Nirav Shah\\\",\\\"date_of_birth\\\":\\\"30\\/12\\/1979\\\",\\\"city\\\":\\\"Ghaziabad\\\",\\\"currency\\\":\\\"USD\\\"},\\\"beneficiary_country\\\":\\\"GB\\\",\\\"beneficiary\\\":{\\\"id\\\":\\\"beneficiary_975b9520d2a3bb4ee510c014e4cbd8f7\\\",\\\"last_name\\\":\\\"Shah\\\",\\\"first_name\\\":\\\"Nirav\\\",\\\"country\\\":\\\"GB\\\",\\\"entity_type\\\":\\\"individual\\\",\\\"address\\\":\\\"C2 1103 Supertech\\\",\\\"name\\\":\\\"Nirav Shah\\\",\\\"city\\\":\\\"Ghaziabad\\\",\\\"currency\\\":\\\"GBP\\\",\\\"bic_swift\\\":\\\"12312312\\\",\\\"iban\\\":\\\"SK7812955172353646008543\\\",\\\"payment_type\\\":\\\"priority\\\"},\\\"fx_rate\\\":0.70082306,\\\"instructions\\\":{\\\"name\\\":\\\"instructions\\\",\\\"steps\\\":[{\\\"step1\\\":\\\"The funds will be transferred to the provided account details of the beneficiary .\\\"}]},\\\"ewallets\\\":[{\\\"ewallet_id\\\":\\\"ewallet_b43aed61d43f74d82b022422cfa26e22\\\",\\\"amount\\\":150,\\\"percent\\\":100}],\\\"metadata\\\":{},\\\"description\\\":\\\"This is a test transfer for date format\\\",\\\"created_at\\\":1625015907,\\\"payout_fees\\\":null,\\\"expiration\\\":null,\\\"paid_at\\\":null,\\\"identifier_type\\\":null,\\\"identifier_value\\\":null,\\\"error\\\":null,\\\"paid_amount\\\":0,\\\"statement_descriptor\\\":\\\"OMNI UPS Transaction\\\",\\\"gc_error_code\\\":null}}\"');

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `details` text DEFAULT NULL,
  `is_sell` int(11) DEFAULT NULL,
  `is_buy` int(11) DEFAULT NULL,
  `income_category` int(11) DEFAULT NULL,
  `expense_category` int(11) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `products`
--

INSERT INTO `products` (`id`, `user_id`, `business_id`, `quantity`, `name`, `slug`, `price`, `details`, `is_sell`, `is_buy`, `income_category`, `expense_category`, `created_at`) VALUES
(1, 2, 13486, 0, 'Nash', NULL, '20.00', NULL, 1, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `product_services`
--

CREATE TABLE `product_services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `product_tax`
--

CREATE TABLE `product_tax` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `tax_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rates`
--

CREATE TABLE `rates` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `rates`
--

INSERT INTO `rates` (`id`, `code`, `rate`, `date`) VALUES
(1, 'AED', '3.6732', '2020-06-14'),
(2, 'AFN', '77.59138', '2020-06-14'),
(3, 'ALL', '110.8155', '2020-06-14'),
(4, 'AMD', '481.814', '2020-06-14'),
(5, 'AOA', '600.099', '2020-06-14'),
(6, 'ARS', '69.38714', '2020-06-14'),
(7, 'AUD', '1.45934', '2020-06-14'),
(8, 'AWG', '1.8', '2020-06-14'),
(9, 'AZN', '1.7', '2020-06-14'),
(10, 'BBD', '2.01949', '2020-06-14'),
(11, 'BDT', '84.95716', '2020-06-14'),
(12, 'BGN', '1.73798', '2020-06-14'),
(13, 'BHD', '0.37708', '2020-06-14'),
(14, 'BIF', '1910.1', '2020-06-14'),
(15, 'BMD', '1', '2020-06-14'),
(16, 'BND', '1.39063', '2020-06-14'),
(17, 'BRL', '5.04955', '2020-06-14'),
(18, 'BTN', '', '2020-06-14'),
(19, 'BWP', '11.6776', '2020-06-14'),
(20, 'BYR', '', '2020-06-14'),
(21, 'BZD', '2.01612', '2020-06-14'),
(22, 'CAD', '1.3587', '2020-06-14'),
(23, 'CHF', '0.95193', '2020-06-14'),
(24, 'CLP', '791.83', '2020-06-14'),
(25, 'CNY', '7.0733', '2020-06-14'),
(26, 'COP', '3776.69', '2020-06-14'),
(27, 'CRC', '579.11026', '2020-06-14'),
(28, 'CUC', '1', '2020-06-14'),
(29, 'CVE', '98.405', '2020-06-14'),
(30, 'CZK', '23.75794', '2020-06-14'),
(31, 'DJF', '177.729', '2020-06-14'),
(32, 'DKK', '6.6203', '2020-06-14'),
(33, 'DOP', '58.405', '2020-06-14'),
(34, 'DZD', '128.51363', '2020-06-14'),
(35, 'EGP', '16.18149', '2020-06-14'),
(36, 'ERN', '', '2020-06-14'),
(37, 'ETB', '34.4', '2020-06-14'),
(38, 'EUR', '0.88851', '2020-06-14'),
(39, 'FJD', '2.1951', '2020-06-14'),
(40, 'GBP', '0.7972', '2020-06-14'),
(41, 'GEL', '3.05', '2020-06-14'),
(42, 'GHS', '5.7805', '2020-06-14'),
(43, 'GIP', '0.7972', '2020-06-14'),
(44, 'GNF', '9460.45', '2020-06-14'),
(45, 'GTQ', '7.69408', '2020-06-14'),
(46, 'GYD', '209.43027', '2020-06-14'),
(47, 'HKD', '7.7498', '2020-06-14'),
(48, 'HNL', '24.941', '2020-06-14'),
(49, 'HRK', '6.72254', '2020-06-14'),
(50, 'HTG', '107.76859', '2020-06-14'),
(51, 'HUF', '307.54', '2020-06-14'),
(52, 'IDR', '14217.361', '2020-06-14'),
(53, 'ILS', '3.4619', '2020-06-14'),
(54, 'INR', '75.9608', '2020-06-14'),
(55, 'IQD', '1190.05', '2020-06-14'),
(56, 'ISK', '135.127', '2020-06-14'),
(57, 'JMD', '140.52593', '2020-06-14'),
(58, 'JOD', '0.70905', '2020-06-14'),
(59, 'JPY', '107.349', '2020-06-14'),
(60, 'KES', '106.46093', '2020-06-14'),
(61, 'KGS', '74.78584', '2020-06-14'),
(62, 'KHR', '4091.2', '2020-06-14'),
(63, 'KMF', '437.872', '2020-06-14'),
(64, 'KWD', '0.30797', '2020-06-14'),
(65, 'KYD', '0.83348', '2020-06-14'),
(66, 'KZT', '404.31862', '2020-06-14'),
(67, 'LAK', '9010.45', '2020-06-14'),
(68, 'LBP', '1511.43755', '2020-06-14'),
(69, 'LKR', '185.37567', '2020-06-14'),
(70, 'LRD', '199.26', '2020-06-14'),
(71, 'LSL', '17.1', '2020-06-14'),
(72, 'MAD', '9.6755', '2020-06-14'),
(73, 'MDL', '17.17804', '2020-06-14'),
(74, 'MGA', '', '2020-06-14'),
(75, 'MMK', '1400.194', '2020-06-14'),
(76, 'MNT', '', '2020-06-14'),
(77, 'MRO', '', '2020-06-14'),
(78, 'MUR', '39.70737', '2020-06-14'),
(79, 'MVR', '15.5', '2020-06-14'),
(80, 'MWK', '740.05', '2020-06-14'),
(81, 'MXN', '22.2003', '2020-06-14'),
(82, 'MYR', '4.27072', '2020-06-14'),
(83, 'MZN', '69.6835', '2020-06-14'),
(84, 'NAD', '17.121', '2020-06-14'),
(85, 'NGN', '387.52', '2020-06-14'),
(86, 'NIO', '34.3', '2020-06-14'),
(87, 'NOK', '9.6223', '2020-06-14'),
(88, 'NPR', '121.40247', '2020-06-14'),
(89, 'NZD', '1.55107', '2020-06-14'),
(90, 'OMR', '0.38503', '2020-06-14'),
(91, 'PAB', '1.00019', '2020-06-14'),
(92, 'PEN', '3.46515', '2020-06-14'),
(93, 'PGK', '3.45', '2020-06-14'),
(94, 'PHP', '50.2806', '2020-06-14'),
(95, 'PKR', '164.51', '2020-06-14'),
(96, 'PLN', '3.9426', '2020-06-14'),
(97, 'PYG', '6691.42155', '2020-06-14'),
(98, 'QAR', '3.64143', '2020-06-14'),
(99, 'RON', '4.29532', '2020-06-14'),
(100, 'RSD', '104.4402', '2020-06-14'),
(101, 'RUB', '69.8931', '2020-06-14'),
(102, 'RWF', '950.05', '2020-06-14'),
(103, 'SAR', '3.75399', '2020-06-14'),
(104, 'SBD', '8.32912', '2020-06-14'),
(105, 'SCR', '17.59155', '2020-06-14'),
(106, 'SDG', '55.305', '2020-06-14'),
(107, 'SEK', '9.3155', '2020-06-14'),
(108, 'SLL', '9755.5', '2020-06-14'),
(109, 'SOS', '583.05', '2020-06-14'),
(110, 'SRD', '7.45835', '2020-06-14'),
(111, 'SZL', '17.121', '2020-06-14'),
(112, 'THB', '30.9815', '2020-06-14'),
(113, 'TJS', '10.28185', '2020-06-14'),
(114, 'TMT', '3.5', '2020-06-14'),
(115, 'TND', '2.85065', '2020-06-14'),
(116, 'TOP', '2.2711', '2020-06-14'),
(117, 'TRY', '6.8106', '2020-06-14'),
(118, 'TTD', '6.75027', '2020-06-14'),
(119, 'TWD', '29.64478', '2020-06-14'),
(120, 'UAH', '26.73694', '2020-06-14'),
(121, 'UGX', '3720.74805', '2020-06-14'),
(122, 'USD', '1', '2020-06-14'),
(123, 'UYU', '42.84096', '2020-06-14'),
(124, 'UZS', '10160.5', '2020-06-14'),
(125, 'VND', '23266.665', '2020-06-14'),
(126, 'VUV', '', '2020-06-14'),
(127, 'WST', '', '2020-06-14'),
(128, 'XAF', '580.42432', '2020-06-14'),
(129, 'XCD', '2.70269', '2020-06-14'),
(130, 'XOF', '580.53', '2020-06-14'),
(131, 'XPF', '', '2020-06-14'),
(132, 'YER', '250.3625', '2020-06-14'),
(133, 'ZAR', '17.0361', '2020-06-14'),
(134, 'ZMW', '18.33854', '2020-06-14');

-- --------------------------------------------------------

--
-- Estrutura da tabela `referal`
--

CREATE TABLE `referal` (
  `id` int(11) NOT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `referal`
--

INSERT INTO `referal` (`id`, `email_id`, `code`, `createdat`) VALUES
(1, 'nash81@gmail.com', 922297, '2021-06-28 01:00:55'),
(2, 'business1@xenio.in', 497388, '2021-06-28 01:50:12'),
(3, 'sub@xenio.in', 187732, '2021-07-09 17:48:54'),
(4, 'business2@xenio.in', 643167, '2021-07-30 04:13:15'),
(5, 'techforhumanity@gmail.com', 272112, '2021-08-06 11:58:09'),
(6, 'marvinade@yahoo.com', 392582, '2021-08-07 16:34:42'),
(7, 'kemioluwaboro@gmail.com', 367082, '2021-08-08 01:06:24'),
(8, 'chika@xenio.in', 784286, '2021-08-08 14:40:56'),
(9, 'aishaayusuf@yahoo.com', 912369, '2021-08-08 14:46:25'),
(10, 'brickstonecpa@gmail.com', 984811, '2021-08-08 17:34:54'),
(11, 'dul_boi@icloud.com', 113167, '2021-08-08 18:50:49'),
(12, 'abdulkadiryusuf778@gmail.com', 369595, '2021-08-08 20:05:20'),
(13, 'jboscoamad@gmail.com', 201433, '2021-08-08 20:52:36'),
(14, 'abdullahibabaaliyu@gmail.com', 531603, '2021-08-09 00:17:15'),
(15, 'ofunsho@prophasisconsults.com', 305455, '2021-08-09 22:58:07'),
(16, 'tirofunsho@gmail.com', 928093, '2021-08-10 00:56:44'),
(17, 'myrewardsclub@yahoo.com', 787389, '2021-08-10 02:23:12'),
(18, 'snotiji@aol.com', 508119, '2021-08-10 03:45:13'),
(19, 'simi.akinnusi@mintft.com', 841084, '2021-08-10 09:17:19'),
(20, 'Kola@prowheelsmag.com', 273281, '2021-08-10 11:55:21'),
(21, 'kogungbile@gmail.com', 638385, '2021-08-10 15:59:48'),
(22, 'kofocoker@gmail.com', 201651, '2021-08-10 21:14:20'),
(23, 'solutionsae@yahoo.com', 866114, '2021-08-11 14:42:34'),
(24, 'gwenabiolaoloke@gmail.com', 209706, '2021-08-12 08:22:41'),
(25, 'hhgconsult@gmail.com', 727023, '2021-08-12 15:14:02'),
(26, 'enochibk@gmail.com', 779025, '2021-08-12 15:38:05'),
(27, 'wahabolugbenga@gmail.com', 856230, '2021-08-13 13:27:30'),
(28, 'ceo@globalmaxremit.com', 715002, '2021-08-14 02:17:59'),
(29, 'nhgcg1@gmail.com', 298571, '2021-08-14 05:22:23'),
(30, 'Tfakus@gmail.com', 996787, '2021-08-14 20:15:46'),
(31, 'abiodunolasanoye@gmail.com', 909986, '2021-08-15 18:55:10'),
(32, 'johnlombela@hotmail.com', 774665, '2021-08-17 01:33:16'),
(33, 'toyebello@bandbllc.com', 677160, '2021-08-17 20:06:56'),
(34, 'dchapman7@babson.edu', 512332, '2021-08-18 15:54:26'),
(35, 'peter@peterojo.com', 882217, '2021-08-18 18:21:38'),
(36, 'mdarbaz2290@mailinator.com', 246352, '2021-08-19 20:21:11'),
(37, 'abdulsuleymann1234@icloud.com', 795985, '2021-08-20 14:47:12'),
(38, 'BFUNSHO@YAHOO.COM', 943798, '2021-08-20 20:39:41'),
(39, 'aothmanladan@gmail.com', 600554, '2021-08-21 03:08:03'),
(40, 'kola@prowheelsmag.com', 786587, '2021-08-22 00:24:39'),
(41, 'toadejumo@gmail.com', 385692, '2021-08-22 05:04:38'),
(42, 'alabapalma@gmail.com', 104929, '2021-08-22 21:07:26'),
(43, 'phillipsgodfrey1@gmail.com', 219692, '2021-08-23 09:46:25'),
(44, 'alukuxaviour@gmail.com', 681042, '2021-08-23 18:24:30'),
(45, 'eowonodi@gmail.com', 502960, '2021-08-24 00:12:15'),
(46, 'tndadegboye@att.net', 623285, '2021-08-24 10:05:36'),
(47, 'giftedsteppersdance@gmail.com', 724713, '2021-08-24 10:39:59'),
(48, 'harisonoma@gmail.com', 560527, '2021-08-24 12:51:43'),
(49, 'jidronk210@yahoo.com', 447007, '2021-08-24 22:00:24'),
(50, 'olareal@gmail.com', 440595, '2021-08-25 00:07:29'),
(51, 'chukwunonsoarinze93@gmail.com', 499224, '2021-08-26 10:34:24'),
(52, 'mr.darwincarreno@gmail.com', 719947, '2021-08-26 14:06:22'),
(53, 'gsadegbile@yahoo.com', 356112, '2021-08-27 01:34:55'),
(54, 'jojophil1357@hotmail.com', 267845, '2021-08-27 12:43:46'),
(55, 'vote27002@yahoo.co.uk', 200486, '2021-08-27 13:48:35'),
(56, 'bosepopoola1@gmail.com', 405699, '2021-08-27 14:55:22'),
(57, 'tyjindustries@hotmail.com', 678942, '2021-08-27 15:42:17'),
(58, 'kunleobadina@yahoo.com', 819416, '2021-08-27 17:58:34'),
(59, 'sakinlolu@gmail.com', 406445, '2021-08-28 12:54:17'),
(60, 'mdarbaz123@mailinator.com', 286110, '2021-08-28 18:54:33'),
(61, 'kadijamotunrayo@gmail.com', 190554, '2021-08-28 21:28:02'),
(62, 'aareonakakanfo@mac.com', 698261, '2021-08-30 02:24:24'),
(63, 'ayotundeowo@gmail.com', 576939, '2021-08-30 02:47:39'),
(64, 'ariesfrank2001@yahoo.com', 822709, '2021-08-30 03:44:50'),
(65, 'catheer@gmail.com', 705382, '2021-08-31 00:45:47'),
(66, 'aadelaja1@yahoo.com', 779107, '2021-09-01 19:43:47'),
(67, 'rick@metou.com', 845974, '2021-09-01 20:23:41'),
(68, 'ashish@machnetinc.com', 289040, '2021-09-03 20:41:05'),
(69, 'durob2012@gmail.com', 665767, '2021-09-03 21:08:33'),
(70, 'DEWAFER@AOL.COM', 511696, '2021-09-05 06:33:20'),
(71, 'info@roumarketing.com', 595379, '2021-09-05 11:34:42'),
(72, 'rou@roumarketing.com', 860163, '2021-09-05 11:52:33'),
(73, 'cashoutdre59@gmail.com', 444241, '2021-09-05 17:15:25'),
(74, 'cocoref@gmail.com', 442132, '2021-09-05 17:23:35'),
(75, 'fhgolnett@gmail.com', 985835, '2021-09-05 17:51:23'),
(76, 'dewafer@aol.com', 467124, '2021-09-06 20:21:15'),
(77, 'goluwaboro@gmail.com', 664243, '2021-09-07 04:01:17'),
(78, 'kunlekuponiyi@yahoo.com', 469307, '2021-09-08 17:40:57'),
(79, 'wazconsultant2@gmail.com', 504124, '2021-09-12 18:26:32'),
(80, 'marrj12@gmail.com', 344340, '2021-09-14 13:02:52'),
(81, 'msgroupllc@outlook.com', 812457, '2021-09-15 15:57:19'),
(82, 'alex@sandiainternational.com', 158914, '2021-09-16 23:35:47'),
(83, 'abubah74@gmail.com', 578484, '2021-09-18 16:23:19'),
(84, 'usojoolusegunfunmiojo195666@gmail.com', 272401, '2021-09-19 14:15:00'),
(85, 'mkennyjoshua@yahoo.com', 262839, '2021-09-19 16:14:42'),
(86, 'aaakanjijokun@gmail.com', 497392, '2021-09-20 09:18:31'),
(87, 'nicholas1phillips@hotmail.com', 864515, '2021-09-25 18:07:21'),
(88, 'abigail1698@outlook.com', 858154, '2021-09-25 18:15:15'),
(89, 'mboswell05@yahoo.com', 840651, '2021-10-04 14:53:59'),
(90, 'Mboswell05@yahoo.com', 451344, '2021-10-05 21:31:09'),
(91, 'trayteboswell1@yahoo.com', 176785, '2021-10-05 21:40:43'),
(92, 'catherinengongoseke@gmail.com', 152742, '2021-10-05 23:16:21'),
(93, 'philikod@gmail.com', 113905, '2021-10-05 23:30:53'),
(94, 'george@psacpa.com', 829539, '2021-10-08 14:23:45'),
(95, 'iyunola@yahoo.com', 604515, '2021-10-10 18:47:39'),
(96, 'kitanayeni@hotmail.co.uk', 217883, '2021-10-11 03:03:29'),
(97, 'janine69@gmail.com', 900730, '2021-10-11 06:40:01'),
(98, 'joedmoz@gmail.com', 800804, '2021-10-11 13:29:04'),
(99, 'elsieezy4real@gmail.com', 539894, '2021-10-14 17:03:04'),
(100, 'nash81@xenio.in', 746180, '2021-10-16 13:51:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `logotxt` text COLLATE utf8mb4_bin NOT NULL,
  `logotxtw` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `logounit` text COLLATE utf8mb4_bin NOT NULL,
  `purchasecode` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sitename` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `title` text COLLATE utf8mb4_bin NOT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `supportemail` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sandbox_access_key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sandbox_secret_key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `live_access_key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `live_sandbox_key` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `apto_mobilekey` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `apto_publickey` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `apto_secretkey` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `apto_liveurl` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sandbox` tinyint(1) NOT NULL,
  `firebase` varchar(512) COLLATE utf8mb4_bin NOT NULL,
  `jitsi_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `transaction_fee` varchar(11) COLLATE utf8mb4_bin NOT NULL,
  `fx_fee` varchar(11) COLLATE utf8mb4_bin NOT NULL,
  `card_fee` varchar(11) COLLATE utf8mb4_bin NOT NULL,
  `non_usage_fee` varchar(11) COLLATE utf8mb4_bin NOT NULL,
  `chargeback_fee` varchar(11) COLLATE utf8mb4_bin NOT NULL,
  `referal_fee` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `setting`
--

INSERT INTO `setting` (`id`, `logotxt`, `logotxtw`, `logounit`, `purchasecode`, `sitename`, `title`, `meta_description`, `meta_keywords`, `supportemail`, `sandbox_access_key`, `sandbox_secret_key`, `live_access_key`, `live_sandbox_key`, `apto_mobilekey`, `apto_publickey`, `apto_secretkey`, `apto_liveurl`, `sandbox`, `firebase`, `jitsi_url`, `transaction_fee`, `fx_fee`, `card_fee`, `non_usage_fee`, `chargeback_fee`, `referal_fee`) VALUES
(1, '/storage/logo.png', '/storage/logo.png', '/storage/logounit.png', '5436a599-b4ee-45a0-ba1a-4f34d97f16ba\r\n', 'XENIO', 'XENIO - Start your Neobank today!', 'XENIO - Start your Neobank today!', 'XENIO - Start your Neobank today!', 'support@xenio.in', 'E93A97744D51CBCFFB21', 'a9226d393883fa9062158ce1fbde28b7611d64b330ab518a0162d3370cf142903ed6d927040e5803', 'test', '', '3t8xFNA3Gk5o8AkgEyi7ud4Gl4PJHy3WEXbMP198+ZOI7UwZUzjd1nCNXPJbuyQv', 'pk_live_a51a1574eaabf53377444b13d079dc2f', 'sk_live_898a3595131e8fc4b0426b8a29396d71', 'https://api.sbx.aptopayments.com/', 1, 'apiKey: \"AIzaSyC03uEDIZZ-jY3mDF19I_Nr6rf0tSGYW9M\",     authDomain: \"batein-3c7b5.firebaseapp.com\",     databaseURL: \"https://batein-3c7b5.firebaseio.com\",     projectId: \"batein-3c7b5\",     storageBucket: \"batein-3c7b5.appspot.com\",     messagingSenderId: \"3864589954\",     appId: \"1:3864589954:web:60092706bfd740138c269b\",     measurementId: \"G-SYWSY0V0ZG\"', 'meet.jit.si', '3.5', '2', '2', '0', '0', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_name` varchar(255) DEFAULT NULL,
  `site_title` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `hero_img` varchar(255) DEFAULT 'assets/front/img/hside.jpg',
  `keywords` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `terms_service` longtext DEFAULT NULL,
  `footer_about` text DEFAULT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `pagination_limit` int(11) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `google_analytics` longtext DEFAULT NULL,
  `site_color` varchar(255) DEFAULT NULL,
  `site_font` varchar(255) DEFAULT NULL,
  `layout` int(11) DEFAULT NULL,
  `site_info` int(11) NOT NULL DEFAULT 1,
  `about_info` mediumtext DEFAULT NULL,
  `ind_code` varchar(255) DEFAULT NULL,
  `purchase_code` varchar(255) DEFAULT NULL,
  `enable_captcha` int(11) DEFAULT 0,
  `enable_registration` int(11) DEFAULT 1,
  `enable_email_verify` int(11) DEFAULT 0,
  `enable_paypal` int(11) NOT NULL DEFAULT 0,
  `enable_delete_invoice` int(11) NOT NULL DEFAULT 1,
  `enable_multilingual` int(11) NOT NULL DEFAULT 1,
  `enable_discount` int(11) DEFAULT 0,
  `enable_blog` int(11) NOT NULL DEFAULT 0,
  `enable_faq` int(11) NOT NULL DEFAULT 0,
  `enable_frontend` int(11) DEFAULT 1,
  `captcha_site_key` varchar(255) DEFAULT NULL,
  `captcha_secret_key` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_mode` varchar(255) DEFAULT 'sandbox',
  `paypal_payment` int(11) NOT NULL DEFAULT 0,
  `stripe_payment` int(11) NOT NULL DEFAULT 0,
  `publish_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `razorpay_payment` int(11) DEFAULT 0,
  `razorpay_key_id` varchar(255) DEFAULT NULL,
  `razorpay_key_secret` varchar(255) DEFAULT NULL,
  `mail_protocol` varchar(255) DEFAULT NULL,
  `mail_title` varchar(255) DEFAULT NULL,
  `mail_host` varchar(255) DEFAULT NULL,
  `mail_port` varchar(255) DEFAULT NULL,
  `mail_encryption` varchar(255) DEFAULT 'ssl',
  `mail_username` varchar(255) DEFAULT NULL,
  `mail_password` varchar(255) DEFAULT NULL,
  `currency` varchar(255) NOT NULL DEFAULT 'USD',
  `country` int(11) DEFAULT 178,
  `trial_days` varchar(255) DEFAULT '15',
  `lang` int(11) DEFAULT 1,
  `theme` int(11) NOT NULL DEFAULT 1,
  `time_zone` int(11) DEFAULT 51,
  `rpa_enable` varchar(155) DEFAULT NULL,
  `version` varchar(255) NOT NULL DEFAULT 'v1.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_title`, `favicon`, `logo`, `hero_img`, `keywords`, `description`, `terms_service`, `footer_about`, `admin_email`, `mobile`, `copyright`, `pagination_limit`, `facebook`, `instagram`, `twitter`, `linkedin`, `google_analytics`, `site_color`, `site_font`, `layout`, `site_info`, `about_info`, `ind_code`, `purchase_code`, `enable_captcha`, `enable_registration`, `enable_email_verify`, `enable_paypal`, `enable_delete_invoice`, `enable_multilingual`, `enable_discount`, `enable_blog`, `enable_faq`, `enable_frontend`, `captcha_site_key`, `captcha_secret_key`, `paypal_email`, `paypal_mode`, `paypal_payment`, `stripe_payment`, `publish_key`, `secret_key`, `razorpay_payment`, `razorpay_key_id`, `razorpay_key_secret`, `mail_protocol`, `mail_title`, `mail_host`, `mail_port`, `mail_encryption`, `mail_username`, `mail_password`, `currency`, `country`, `trial_days`, `lang`, `theme`, `time_zone`, `rpa_enable`, `version`) VALUES
(1, 'XENIO', 'XENIO - Start your Neobank today!', 'uploads/thumbnail/logounit_thumb-100x100.png', 'uploads/medium/geeftologo_medium-300x75.png', 'uploads/big/hero-img_big-500x500.png', 'saas,finincial software,accounting software,facturation', 'Unified Wallet, Invoicing & Accounting, Payment Solutions.', '<h2><strong>Terms of service and the law</strong></h2>\r\n\r\n<p>A business organization needs a terms of service agreement on its site while making sure it is also included within customer contracts. It\'s important to make this link and show it to customers so that they understand everything clearly.</p>\r\n\r\n<p>It is also very important to include an additional step where customers can confirm that they\'ve read and that they agree with your terms of service.</p>\r\n\r\n<p>Additionally, for all organizations that offer services or products online, no matter where they are located, it\'s important that their terms of service are compliant with E-commerce Regulations and Consumer Information Regulations.</p>\r\n\r\n<p>On top of that, you should make sure to check the Sale of Goods and Supply of Services Act of 1980 to avoid any legal difficulties and ensure the safety of your business.</p>\r\n\r\n<p>When it comes to Australia, for example, websites are not allowed to misrepresent themselves. The information located on a site should not be deceptive or misleading in any way when talking about services or products. This is how a website can comply with consumer law in Australia.</p>\r\n\r\n<p>There have been a few cases where the law sided with the customers because the terms of service page was simply too large and the court decided that it was very unlikely that anyone would have the time or patience to read the whole thing.</p>\r\n\r\n<p>A different case where terms of service were questioned is where a major retailer didn\'t put them in a visible spot. This is also very important to keep in mind when placing a terms of service section.</p>\r\n', 'XENIO - Start your Neobank today!', 'nirav@xenio.in', '', '© 2021 Xenio All rights reserved.', 0, 'facebook.com', 'facebook.com', '', 'linkedin', '', '', '', 0, 2, 'SW52YWxpZCBMaWNlbnNlIEtleQ==', '123456123456123456123456123456123456', '123456123456123456123456123456123456', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, '6Ld0SpcUAAAAAFpKkQaTwbENLukNG_hMpPpykHt9', '', '', 'sandbox', 0, 0, '', '', 0, '', '', 'mail', '', 'smtp.gmail.com', '465', 'ssl', '', '', 'USD', 178, '0', 1, 1, 194, '0', '2.1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `site_contacts`
--

CREATE TABLE `site_contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `ewallet_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `storename` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `store_products`
--

CREATE TABLE `store_products` (
  `id` int(11) NOT NULL,
  `store_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text COLLATE utf8mb4_bin DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `tag_slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tax`
--

CREATE TABLE `tax` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rate` decimal(10,1) DEFAULT 0.0,
  `number` varchar(255) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `is_invoices` int(11) DEFAULT NULL,
  `is_recoverable` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tax_type`
--

CREATE TABLE `tax_type` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `time_zone`
--

CREATE TABLE `time_zone` (
  `id` int(10) NOT NULL,
  `name` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `time_zone`
--

INSERT INTO `time_zone` (`id`, `name`) VALUES
(1, 'Europe/Andorra'),
(2, 'Asia/Dubai'),
(3, 'Asia/Kabul'),
(4, 'America/Antigua'),
(5, 'America/Anguilla'),
(6, 'Europe/Tirane'),
(7, 'Asia/Yerevan'),
(8, 'Africa/Luanda'),
(9, 'Antarctica/McMurdo'),
(10, 'Antarctica/Casey'),
(11, 'Antarctica/Davis'),
(12, 'Antarctica/DumontDUrville'),
(13, 'Antarctica/Mawson'),
(14, 'Antarctica/Palmer'),
(15, 'Antarctica/Rothera'),
(16, 'Antarctica/Syowa'),
(17, 'Antarctica/Troll'),
(18, 'Antarctica/Vostok'),
(19, 'America/Argentina/Buenos_Aires'),
(20, 'America/Argentina/Cordoba'),
(21, 'America/Argentina/Salta'),
(22, 'America/Argentina/Jujuy'),
(23, 'America/Argentina/Tucuman'),
(24, 'America/Argentina/Catamarca'),
(25, 'America/Argentina/La_Rioja'),
(26, 'America/Argentina/San_Juan'),
(27, 'America/Argentina/Mendoza'),
(28, 'America/Argentina/San_Luis'),
(29, 'America/Argentina/Rio_Gallegos'),
(30, 'America/Argentina/Ushuaia'),
(31, 'Pacific/Pago_Pago'),
(32, 'Europe/Vienna'),
(33, 'Australia/Lord_Howe'),
(34, 'Antarctica/Macquarie'),
(35, 'Australia/Hobart'),
(36, 'Australia/Currie'),
(37, 'Australia/Melbourne'),
(38, 'Australia/Sydney'),
(39, 'Australia/Broken_Hill'),
(40, 'Australia/Brisbane'),
(41, 'Australia/Lindeman'),
(42, 'Australia/Adelaide'),
(43, 'Australia/Darwin'),
(44, 'Australia/Perth'),
(45, 'Australia/Eucla'),
(46, 'America/Aruba'),
(47, 'Europe/Mariehamn'),
(48, 'Asia/Baku'),
(49, 'Europe/Sarajevo'),
(50, 'America/Barbados'),
(51, 'Asia/Dhaka'),
(52, 'Europe/Brussels'),
(53, 'Africa/Ouagadougou'),
(54, 'Europe/Sofia'),
(55, 'Asia/Bahrain'),
(56, 'Africa/Bujumbura'),
(57, 'Africa/Porto-Novo'),
(58, 'America/St_Barthelemy'),
(59, 'Atlantic/Bermuda'),
(60, 'Asia/Brunei'),
(61, 'America/La_Paz'),
(62, 'America/Kralendijk'),
(63, 'America/Noronha'),
(64, 'America/Belem'),
(65, 'America/Fortaleza'),
(66, 'America/Recife'),
(67, 'America/Araguaina'),
(68, 'America/Maceio'),
(69, 'America/Bahia'),
(70, 'America/Sao_Paulo'),
(71, 'America/Campo_Grande'),
(72, 'America/Cuiaba'),
(73, 'America/Santarem'),
(74, 'America/Porto_Velho'),
(75, 'America/Boa_Vista'),
(76, 'America/Manaus'),
(77, 'America/Eirunepe'),
(78, 'America/Rio_Branco'),
(79, 'America/Nassau'),
(80, 'Asia/Thimphu'),
(81, 'Africa/Gaborone'),
(82, 'Europe/Minsk'),
(83, 'America/Belize'),
(84, 'America/St_Johns'),
(85, 'America/Halifax'),
(86, 'America/Glace_Bay'),
(87, 'America/Moncton'),
(88, 'America/Goose_Bay'),
(89, 'America/Blanc-Sablon'),
(90, 'America/Toronto'),
(91, 'America/Nipigon'),
(92, 'America/Thunder_Bay'),
(93, 'America/Iqaluit'),
(94, 'America/Pangnirtung'),
(95, 'America/Atikokan'),
(96, 'America/Winnipeg'),
(97, 'America/Rainy_River'),
(98, 'America/Resolute'),
(99, 'America/Rankin_Inlet'),
(100, 'America/Regina'),
(101, 'America/Swift_Current'),
(102, 'America/Edmonton'),
(103, 'America/Cambridge_Bay'),
(104, 'America/Yellowknife'),
(105, 'America/Inuvik'),
(106, 'America/Creston'),
(107, 'America/Dawson_Creek'),
(108, 'America/Fort_Nelson'),
(109, 'America/Vancouver'),
(110, 'America/Whitehorse'),
(111, 'America/Dawson'),
(112, 'Indian/Cocos'),
(113, 'Africa/Kinshasa'),
(114, 'Africa/Lubumbashi'),
(115, 'Africa/Bangui'),
(116, 'Africa/Brazzaville'),
(117, 'Europe/Zurich'),
(118, 'Africa/Abidjan'),
(119, 'Pacific/Rarotonga'),
(120, 'America/Santiago'),
(121, 'America/Punta_Arenas'),
(122, 'Pacific/Easter'),
(123, 'Africa/Douala'),
(124, 'Asia/Shanghai'),
(125, 'Asia/Urumqi'),
(126, 'America/Bogota'),
(127, 'America/Costa_Rica'),
(128, 'America/Havana'),
(129, 'Atlantic/Cape_Verde'),
(130, 'America/Curacao'),
(131, 'Indian/Christmas'),
(132, 'Asia/Nicosia'),
(133, 'Asia/Famagusta'),
(134, 'Europe/Prague'),
(135, 'Europe/Berlin'),
(136, 'Europe/Busingen'),
(137, 'Africa/Djibouti'),
(138, 'Europe/Copenhagen'),
(139, 'America/Dominica'),
(140, 'America/Santo_Domingo'),
(141, 'Africa/Algiers'),
(142, 'America/Guayaquil'),
(143, 'Pacific/Galapagos'),
(144, 'Europe/Tallinn'),
(145, 'Africa/Cairo'),
(146, 'Africa/El_Aaiun'),
(147, 'Africa/Asmara'),
(148, 'Europe/Madrid'),
(149, 'Africa/Ceuta'),
(150, 'Atlantic/Canary'),
(151, 'Africa/Addis_Ababa'),
(152, 'Europe/Helsinki'),
(153, 'Pacific/Fiji'),
(154, 'Atlantic/Stanley'),
(155, 'Pacific/Chuuk'),
(156, 'Pacific/Pohnpei'),
(157, 'Pacific/Kosrae'),
(158, 'Atlantic/Faroe'),
(159, 'Europe/Paris'),
(160, 'Africa/Libreville'),
(161, 'Europe/London'),
(162, 'America/Grenada'),
(163, 'Asia/Tbilisi'),
(164, 'America/Cayenne'),
(165, 'Europe/Guernsey'),
(166, 'Africa/Accra'),
(167, 'Europe/Gibraltar'),
(168, 'America/Nuuk'),
(169, 'America/Danmarkshavn'),
(170, 'America/Scoresbysund'),
(171, 'America/Thule'),
(172, 'Africa/Banjul'),
(173, 'Africa/Conakry'),
(174, 'America/Guadeloupe'),
(175, 'Africa/Malabo'),
(176, 'Europe/Athens'),
(177, 'Atlantic/South_Georgia'),
(178, 'America/Guatemala'),
(179, 'Pacific/Guam'),
(180, 'Africa/Bissau'),
(181, 'America/Guyana'),
(182, 'Asia/Hong_Kong'),
(183, 'America/Tegucigalpa'),
(184, 'Europe/Zagreb'),
(185, 'America/Port-au-Prince'),
(186, 'Europe/Budapest'),
(187, 'Asia/Jakarta'),
(188, 'Asia/Pontianak'),
(189, 'Asia/Makassar'),
(190, 'Asia/Jayapura'),
(191, 'Europe/Dublin'),
(192, 'Asia/Jerusalem'),
(193, 'Europe/Isle_of_Man'),
(194, 'Asia/Kolkata'),
(195, 'Indian/Chagos'),
(196, 'Asia/Baghdad'),
(197, 'Asia/Tehran'),
(198, 'Atlantic/Reykjavik'),
(199, 'Europe/Rome'),
(200, 'Europe/Jersey'),
(201, 'America/Jamaica'),
(202, 'Asia/Amman'),
(203, 'Asia/Tokyo'),
(204, 'Africa/Nairobi'),
(205, 'Asia/Bishkek'),
(206, 'Asia/Phnom_Penh'),
(207, 'Pacific/Tarawa'),
(208, 'Pacific/Enderbury'),
(209, 'Pacific/Kiritimati'),
(210, 'Indian/Comoro'),
(211, 'America/St_Kitts'),
(212, 'Asia/Pyongyang'),
(213, 'Asia/Seoul'),
(214, 'Asia/Kuwait'),
(215, 'America/Cayman'),
(216, 'Asia/Almaty'),
(217, 'Asia/Qyzylorda'),
(218, 'Asia/Qostanay'),
(219, 'Asia/Aqtobe'),
(220, 'Asia/Aqtau'),
(221, 'Asia/Atyrau'),
(222, 'Asia/Oral'),
(223, 'Asia/Vientiane'),
(224, 'Asia/Beirut'),
(225, 'America/St_Lucia'),
(226, 'Europe/Vaduz'),
(227, 'Asia/Colombo'),
(228, 'Africa/Monrovia'),
(229, 'Africa/Maseru'),
(230, 'Europe/Vilnius'),
(231, 'Europe/Luxembourg'),
(232, 'Europe/Riga'),
(233, 'Africa/Tripoli'),
(234, 'Africa/Casablanca'),
(235, 'Europe/Monaco'),
(236, 'Europe/Chisinau'),
(237, 'Europe/Podgorica'),
(238, 'America/Marigot'),
(239, 'Indian/Antananarivo'),
(240, 'Pacific/Majuro'),
(241, 'Pacific/Kwajalein'),
(242, 'Europe/Skopje'),
(243, 'Africa/Bamako'),
(244, 'Asia/Yangon'),
(245, 'Asia/Ulaanbaatar'),
(246, 'Asia/Hovd'),
(247, 'Asia/Choibalsan'),
(248, 'Asia/Macau'),
(249, 'Pacific/Saipan'),
(250, 'America/Martinique'),
(251, 'Africa/Nouakchott'),
(252, 'America/Montserrat'),
(253, 'Europe/Malta'),
(254, 'Indian/Mauritius'),
(255, 'Indian/Maldives'),
(256, 'Africa/Blantyre'),
(257, 'America/Mexico_City'),
(258, 'America/Cancun'),
(259, 'America/Merida'),
(260, 'America/Monterrey'),
(261, 'America/Matamoros'),
(262, 'America/Mazatlan'),
(263, 'America/Chihuahua'),
(264, 'America/Ojinaga'),
(265, 'America/Hermosillo'),
(266, 'America/Tijuana'),
(267, 'America/Bahia_Banderas'),
(268, 'Asia/Kuala_Lumpur'),
(269, 'Asia/Kuching'),
(270, 'Africa/Maputo'),
(271, 'Africa/Windhoek'),
(272, 'Pacific/Noumea'),
(273, 'Africa/Niamey'),
(274, 'Pacific/Norfolk'),
(275, 'Africa/Lagos'),
(276, 'America/Managua'),
(277, 'Europe/Amsterdam'),
(278, 'Europe/Oslo'),
(279, 'Asia/Kathmandu'),
(280, 'Pacific/Nauru'),
(281, 'Pacific/Niue'),
(282, 'Pacific/Auckland'),
(283, 'Pacific/Chatham'),
(284, 'Asia/Muscat'),
(285, 'America/Panama'),
(286, 'America/Lima'),
(287, 'Pacific/Tahiti'),
(288, 'Pacific/Marquesas'),
(289, 'Pacific/Gambier'),
(290, 'Pacific/Port_Moresby'),
(291, 'Pacific/Bougainville'),
(292, 'Asia/Manila'),
(293, 'Asia/Karachi'),
(294, 'Europe/Warsaw'),
(295, 'America/Miquelon'),
(296, 'Pacific/Pitcairn'),
(297, 'America/Puerto_Rico'),
(298, 'Asia/Gaza'),
(299, 'Asia/Hebron'),
(300, 'Europe/Lisbon'),
(301, 'Atlantic/Madeira'),
(302, 'Atlantic/Azores'),
(303, 'Pacific/Palau'),
(304, 'America/Asuncion'),
(305, 'Asia/Qatar'),
(306, 'Indian/Reunion'),
(307, 'Europe/Bucharest'),
(308, 'Europe/Belgrade'),
(309, 'Europe/Kaliningrad'),
(310, 'Europe/Moscow'),
(311, 'Europe/Simferopol'),
(312, 'Europe/Kirov'),
(313, 'Europe/Astrakhan'),
(314, 'Europe/Volgograd'),
(315, 'Europe/Saratov'),
(316, 'Europe/Ulyanovsk'),
(317, 'Europe/Samara'),
(318, 'Asia/Yekaterinburg'),
(319, 'Asia/Omsk'),
(320, 'Asia/Novosibirsk'),
(321, 'Asia/Barnaul'),
(322, 'Asia/Tomsk'),
(323, 'Asia/Novokuznetsk'),
(324, 'Asia/Krasnoyarsk'),
(325, 'Asia/Irkutsk'),
(326, 'Asia/Chita'),
(327, 'Asia/Yakutsk'),
(328, 'Asia/Khandyga'),
(329, 'Asia/Vladivostok'),
(330, 'Asia/Ust-Nera'),
(331, 'Asia/Magadan'),
(332, 'Asia/Sakhalin'),
(333, 'Asia/Srednekolymsk'),
(334, 'Asia/Kamchatka'),
(335, 'Asia/Anadyr'),
(336, 'Africa/Kigali'),
(337, 'Asia/Riyadh'),
(338, 'Pacific/Guadalcanal'),
(339, 'Indian/Mahe'),
(340, 'Africa/Khartoum'),
(341, 'Europe/Stockholm'),
(342, 'Asia/Singapore'),
(343, 'Atlantic/St_Helena'),
(344, 'Europe/Ljubljana'),
(345, 'Arctic/Longyearbyen'),
(346, 'Europe/Bratislava'),
(347, 'Africa/Freetown'),
(348, 'Europe/San_Marino'),
(349, 'Africa/Dakar'),
(350, 'Africa/Mogadishu'),
(351, 'America/Paramaribo'),
(352, 'Africa/Juba'),
(353, 'Africa/Sao_Tome'),
(354, 'America/El_Salvador'),
(355, 'America/Lower_Princes'),
(356, 'Asia/Damascus'),
(357, 'Africa/Mbabane'),
(358, 'America/Grand_Turk'),
(359, 'Africa/Ndjamena'),
(360, 'Indian/Kerguelen'),
(361, 'Africa/Lome'),
(362, 'Asia/Bangkok'),
(363, 'Asia/Dushanbe'),
(364, 'Pacific/Fakaofo'),
(365, 'Asia/Dili'),
(366, 'Asia/Ashgabat'),
(367, 'Africa/Tunis'),
(368, 'Pacific/Tongatapu'),
(369, 'Europe/Istanbul'),
(370, 'America/Port_of_Spain'),
(371, 'Pacific/Funafuti'),
(372, 'Asia/Taipei'),
(373, 'Africa/Dar_es_Salaam'),
(374, 'Europe/Kiev'),
(375, 'Europe/Uzhgorod'),
(376, 'Europe/Zaporozhye'),
(377, 'Africa/Kampala'),
(378, 'Pacific/Midway'),
(379, 'Pacific/Wake'),
(380, 'America/New_York'),
(381, 'America/Detroit'),
(382, 'America/Kentucky/Louisville'),
(383, 'America/Kentucky/Monticello'),
(384, 'America/Indiana/Indianapolis'),
(385, 'America/Indiana/Vincennes'),
(386, 'America/Indiana/Winamac'),
(387, 'America/Indiana/Marengo'),
(388, 'America/Indiana/Petersburg'),
(389, 'America/Indiana/Vevay'),
(390, 'America/Chicago'),
(391, 'America/Indiana/Tell_City'),
(392, 'America/Indiana/Knox'),
(393, 'America/Menominee'),
(394, 'America/North_Dakota/Center'),
(395, 'America/North_Dakota/New_Salem'),
(396, 'America/North_Dakota/Beulah'),
(397, 'America/Denver'),
(398, 'America/Boise'),
(399, 'America/Phoenix'),
(400, 'America/Los_Angeles'),
(401, 'America/Anchorage'),
(402, 'America/Juneau'),
(403, 'America/Sitka'),
(404, 'America/Metlakatla'),
(405, 'America/Yakutat'),
(406, 'America/Nome'),
(407, 'America/Adak'),
(408, 'Pacific/Honolulu'),
(409, 'America/Montevideo'),
(410, 'Asia/Samarkand'),
(411, 'Asia/Tashkent'),
(412, 'Europe/Vatican'),
(413, 'America/St_Vincent'),
(414, 'America/Caracas'),
(415, 'America/Tortola'),
(416, 'America/St_Thomas'),
(417, 'Asia/Ho_Chi_Minh'),
(418, 'Pacific/Efate'),
(419, 'Pacific/Wallis'),
(420, 'Pacific/Apia'),
(421, 'Asia/Aden'),
(422, 'Indian/Mayotte'),
(423, 'Africa/Johannesburg'),
(424, 'Africa/Lusaka'),
(425, 'Africa/Harare');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `image` text COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(500) COLLATE utf8mb4_bin NOT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `phone_authentication` tinyint(1) NOT NULL DEFAULT 0,
  `roles` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT 'person',
  `entity_type` enum('individual','company') COLLATE utf8mb4_bin NOT NULL DEFAULT 'individual',
  `mothers_name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `contact_type` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT 'personal',
  `line_1` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `line_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `line_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `state` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `state_code` varchar(2) COLLATE utf8mb4_bin DEFAULT NULL,
  `country` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_bin DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `currency_symbol` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `canton` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `district` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `identification_type` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `identification_number` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `date_of_birth` date NOT NULL,
  `kyc_reference_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `kyc_status` tinyint(1) DEFAULT NULL,
  `verification_status` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ewallet_reference_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `contact_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `card_id` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `business_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `card_status` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `kuda_reference_id` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `kuda_account_number` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `verification_key` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `link_generated_on` timestamp NULL DEFAULT NULL,
  `is_email_verified` enum('Yes','No') COLLATE utf8mb4_bin DEFAULT NULL,
  `parent_wallet` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `is_admin`, `first_name`, `last_name`, `image`, `email`, `password`, `phone_number`, `phone_authentication`, `roles`, `type`, `entity_type`, `mothers_name`, `contact_type`, `line_1`, `line_2`, `line_3`, `city`, `state`, `state_code`, `country`, `country_code`, `currency`, `currency_symbol`, `zip`, `canton`, `district`, `identification_type`, `identification_number`, `date_of_birth`, `kyc_reference_id`, `kyc_status`, `verification_status`, `created_at`, `ewallet_reference_id`, `contact_id`, `ewallet_id`, `card_id`, `business_id`, `card_status`, `updated_at`, `kuda_reference_id`, `kuda_account_number`, `verification_key`, `link_generated_on`, `is_email_verified`, `parent_wallet`, `parent_id`) VALUES
(6, 1, 'Nirav', 'Shah', 'https://omniups.money/storage/296047IMG_20200227_101951_844.jpg', 'nash81@gmail.com', '0c48ee3585d17e637f7e7e83777058548960c32e9ca4b99b97a797b9428ccf010ca4f77105f85d92f38926cac2c49e3b096578a6def96955326174921d3bb06a7GA1uLB00dzo/u9IWSvbzlFc73TOKtY0Km9k33vQSSc=', '+18156383993', 1, 'user', 'person', 'individual', 'Kik', 'personal', '120 W 21st Street', 'NA', 'A 604 Teerth Towers', 'New York', 'New York', 'NY', 'United States', 'US', 'USD', '₹', '10011', '', '', '', '', '2000-07-03', '', 1, '', '2021-06-11 02:29:09', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'ewallet_b43aed61d43f74d82b022422cfa26e22', '', '', '', '2021-06-11 02:29:09', 'KUDA_1625050679629', '2000386072', NULL, '2021-10-31 07:45:58', 'Yes', NULL, NULL),
(7, 1, 'Mohammed', 'Altaf', 'https://mophy.dexignzone.com/xhtml/images/profile/17.jpg', 'mdaltaf.tech@mailinator.com', 'mbWiks+EENfx8bn5CVf49g==', '+16546546544', 1, 'user', 'person', 'individual', 'Kik', 'personal', '120 W 21st Street', 'NA', 'Madiwala', 'New York', 'New York', 'NY', 'United States', 'US', 'USD', '₹', '10011', '', '', '', '', '2000-07-03', '', NULL, '', '2021-06-12 14:31:21', 'GEEFTO466813', 'GEEFTO466813', 'GEEFTO466813', '', '', '', '2021-06-12 14:31:21', NULL, NULL, NULL, NULL, 'Yes', NULL, NULL),
(21, NULL, 'Mohammed', 'Arbaz', '', 'mdarbaz228@mailinator.com', 'fe68057d2e6ac15004c5dd38a2c3eeed93eb92273967a4dc221fc4fcf67e964460abd6fee9560425c98594bd46ac86420473b63861427aca5006401cb21a9c09eJZwPaIK4rFKj6mEQVic4YtjaAAlYJrKm/8Nw3oWGQk=', '+17867860001', 1, 'user', 'company', 'individual', 'Kik', 'personal', '120 W 21st Street', 'NA', 'Santa Ana', 'New York', 'New York', 'NY', 'United States', 'US', 'USD', '$', '10011', '', '', '', '', '2000-07-03', '', NULL, '', '2021-06-16 19:21:43', 'GEEFTO466813', 'GEEFTO466813', 'GEEFTO466813', '', '', '', '2021-06-16 19:21:43', NULL, NULL, NULL, '2021-07-26 16:12:20', 'Yes', NULL, NULL),
(25, NULL, 'Business', 'shah', 'https://xenio.in/storage/149815logounit.png', 'business2@xenio.in', '1be8c1ec933048bc35176b618710e8c5d064c68ed19abac0e2c6a244f9f91e78097cf304a5cbc86631b3860f79d1cc697f11f83c2538d54130314a2180d19e8eqDMaN1LSGDJKKXwb3csSvKwcBGe1JxDeHKGiz3CYYDg=', '+12243359185', 1, 'user', 'company', 'company', 'Kik', 'personal', '120 W 21st Street', 'NA', 'A 604 Teerth Towers', 'New York', 'New York', 'NY', 'United States', 'US', 'USD', '$', '10011', '', '', '', '', '2000-07-03', '', NULL, '', '2021-06-22 02:15:53', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'crd_102ee0773cf49e7f', '', 'ACT', '2021-06-22 02:15:53', 'KUDA_1634308317901', '2018562794', NULL, NULL, 'Yes', NULL, NULL),
(159, NULL, 'Nirav', 'Shah', '', 'nash81@xenio.in', 'ea16a66553a06d9d080f2331e2f785871fbe3b72e9c87990dc158c633a18efd0fd106618917c544fc852bc21631299f69df1d4ddc77063d6a7369a764c90a858tKKMCQ6luBQQjO2ztukSSYzl/62wOh15T0ZYIIbsKDI=', '+919326601610', 1, 'user', 'person', 'individual', 'Parul Shah', 'personal', 'A 604 Teerth Towers', 'NA', NULL, 'Pune', 'Maharashtra', 'MH', 'India', 'IN', 'INR', NULL, '411045', '', '', '', '', '1979-12-17', '', NULL, '', '2021-10-16 13:49:59', 'XENIO574328', 'XENIO574328', 'XENIO574328', '', NULL, '', '2021-10-16 13:49:59', NULL, NULL, NULL, NULL, 'Yes', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(100) DEFAULT 'user',
  `account_type` varchar(255) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT 'registered',
  `phone` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `layouts` varchar(255) NOT NULL DEFAULT 'style1',
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `paypal_payment` int(11) DEFAULT 1,
  `stripe_payment` int(11) DEFAULT 1,
  `paypal_email` varchar(255) DEFAULT NULL,
  `publish_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `razorpay_payment` int(11) DEFAULT 0,
  `razorpay_key_id` varchar(255) DEFAULT NULL,
  `razorpay_key_secret` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `email_verified` int(11) DEFAULT NULL,
  `verify_code` varchar(255) DEFAULT NULL,
  `hit` int(11) DEFAULT 0,
  `trial_expire` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `title`, `slug`, `email`, `user_name`, `password`, `role`, `account_type`, `user_type`, `phone`, `address`, `country`, `city`, `state`, `postcode`, `layouts`, `image`, `thumb`, `paypal_payment`, `stripe_payment`, `paypal_email`, `publish_key`, `secret_key`, `razorpay_payment`, `razorpay_key_id`, `razorpay_key_secret`, `status`, `email_verified`, `verify_code`, `hit`, `trial_expire`, `created_at`) VALUES
(1, NULL, NULL, 'admin', 'nirav@xenio.in', 'admin', '$2y$10$25kwfqERamT2KutCnZ.dPeVfFas4Sz2VFuoPCLC.dPw1eIYSr8mGW', 'admin', NULL, 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, NULL, 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, NULL, 0, NULL, NULL),
(2, 'Nirav Shah', NULL, 'nirav-shah', 'nash81@gmail.com', 'nirav-shah', '$2y$10$2agSyQK9jT3e14qkFGItFugCDPLI11UXTXdy/wvGH0cxoDH2WPiQ.', 'user', 'pro', 'registered', '', '', 178, '', '', '', 'style1', NULL, 'assets/front/img/avatar.png', 1, 1, NULL, 'pk_test_51HIDcMFjgYMbRuS3QSg1DybLubJ6hBkq5D0rorBgpqzB0eA1ONq2Vw4QEJL2cWNqz1sUPWD0LxMICh2x1D4wITSH00z9bCpmPw', 'sk_test_51HIDcMFjgYMbRuS3nO5NBxrH42fkXWX5mCAU73h0ZRG28cWtYsU73DCCzDVABNnQNl5eP45h3IBHIAYpXlxO3mLz00q9YYFSXh', 0, NULL, NULL, 1, NULL, '84f7e69969dea92a925508f7c1f9579a', 0, '0000-00-00', '2021-07-15 16:28:09'),
(4, 'Accounts-Test', NULL, 'Accounts', 'accounts@xenio.in', 'Accounts', 'a001e305bdeffbf7089264490e517f77d084f6ccb03311347634ccdfdbc15993e181d6edca30bf7b50be51b017b4f86fc99d01ba30d4a34c7d0a95e0099777ecsPnL7iv6JW6w75CZNgyPytQjJhlaEDAo+l0mr/mYykA=', 'user', 'pro', 'registered', '', '', 79, '', '', '', 'style1', 'uploads/medium/logotextbk_medium-706x341.png', 'uploads/thumbnail/logotextbk_thumb-150x72.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c058f544c737782deacefa532d9add4c', 0, '0000-00-00', '2021-07-15 19:11:07'),
(5, 'Rafik Ismail-Bakali', NULL, 'Rafik Ismail', 'rafikismail@mailinator.com', 'Rafik Ismail', 'f930ef875a51ec7db7e168276c6d19e8b0c06ec086c10288e3c6dca1f60b719bc240d57e1bae0d5551fd12a1e891a40f544e54a520c1f15e59f1db238eb8e195xa6WApfUdqQzEAuBwMzwVncoc/orsAyEjL6Q4sLYmns=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ef575e8837d065a1683c022d2077d342', 0, '2021-07-29', '2021-07-29 23:59:46'),
(6, 'John-Doe', NULL, 'John', 'mdarbaz2290@mailinator.com', 'John', '9868221bce6cd680f10f42a5d5847d9c637b04fb6805b042cf838d5fa69c4ec880fa656c725051d5bcd511a41d3310739c2a05e0468b19a5da92c6c77f1bfa11mGrdo+nfeQprEDwXtr/KBIQF2HWcxynrjt9wfzK+in4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd490d7b4576290fa60eb31b5fc917ad1', 0, '2021-07-30', '2021-07-30 18:35:44'),
(7, 'George-Oluwaboro', NULL, 'George', 'techforhumanity@gmail.com', 'George', '37a02fd086147d3d2fd983cc9f9c2f2544577663252d3b470b4ce77e54780bb685b4f1cc9cd05e9dc5bd92c8fa34d93876430890d1b563ac00c26400758c65edn4HLd7sGuKeReb6BybDLEpuPOdSZ/d3xLQ56qZ6RdGM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '44c4c17332cace2124a1a836d9fc4b6f', 0, '2021-08-06', '2021-08-06 07:55:44'),
(8, 'Ayo-Adejugbe', NULL, 'Ayo', 'marvinade@yahoo.com', 'Ayo', '766e50498629f878d5daaae582631b9f3c9c6f75290fd4cd9ae70390fcb15fd82f704bcb43604fea4059fae1f2fc26af154b14eebd14c85957be759cb8b478f0b2i9WlfvdeQEkM10o94koZ2rLlp5tJQtQhagfeOArRE=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '4b04a686b0ad13dce35fa99fa4161c65', 0, '2021-08-07', '2021-08-07 12:28:04'),
(9, 'Kemi-Oluwaboro', NULL, 'Kemi', 'kemioluwaboro@gmail.com', 'Kemi', '7d43f1e4e0bc56da9a6d2c07a6b2db45b44dec38900ed92f8b12d6b64d3541817bc398da635d02b73b31fd8add237026234751bf5c3c95f4f84aafe7aad013ddtJC0N70y3qMXsHDe7TP5SLtD2DCSgklyF5RdT6ezAJQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '42e77b63637ab381e8be5f8318cc28a2', 0, '2021-08-07', '2021-08-07 21:02:45'),
(10, 'Chika-Mika', NULL, 'Chika', 'chika@xenio.in', 'Chika', 'eb424a6ee128f9520f30c39414072658dd8b4af0afbfa6de66c2e47b2b011a5eb7b0403700dd5700788930ccaba5869cf7403c343fbb64a0e3b1b29f25c028d9c5XwQQG3MTyKYgxyvGBOX+uKW65bnspnJ3pyhfg0qZ0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '4e0cb6fb5fb446d1c92ede2ed8780188', 0, '2021-08-08', '2021-08-08 10:38:07'),
(11, 'Aishat-Yusuf', NULL, 'Aishat', 'aishaayusuf@yahoo.com', 'Aishat', '7db991b0fbe8021d66ad9673118ff7e7bfd3a6e7f36fd4eb7f8cad6c1687b9d0444c0bed6269e94655269ffe9318b7cf2a1043d911630ab25e9c99ac2081f2819D598kOmBTdlQhMEsj9nP9ZG1+XIXmjVkbgMAleEFhI=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'b0b183c207f46f0cca7dc63b2604f5cc', 0, '2021-08-08', '2021-08-08 10:43:48'),
(12, 'George-Brickstone', NULL, 'George', 'brickstonecpa@gmail.com', 'George', 'fd5ce23b89ce72826bebc0f4fab37212b2167986a57b806c47ccd71873934ff0a3b28ebba6f9d3c58f3a1089168a92e74db112350b7b50b337146b0e56896bbeWQcKn9v+QHTKekGs7Q09UxX+n2pPZEMSAalyr+JSUFM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '6ea9ab1baa0efb9e19094440c317e21b', 0, '2021-08-08', '2021-08-08 13:32:47'),
(13, 'Abdulkadir -Yusuf', NULL, 'Abdulkadir ', 'dul_boi@icloud.com', 'Abdulkadir ', '6bf200cb6316dee0c0519ae8f0e7262c37d4cb9454b4dc13e6cd605a61b51cf663aaa5c67c5ea86e9c40814dd1914a80862ba3e108a5ac94461cee029da5bc3eH39lqI0UIiaU3PdEkQgKdigR+pVkW6eBvnJoLY0T0rk=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c4ca4238a0b923820dcc509a6f75849b', 0, '2021-08-08', '2021-08-08 14:46:13'),
(14, 'Abdulkadir -Yusuf', NULL, 'Abdulkadir ', 'abdulkadiryusuf778@gmail.com', 'Abdulkadir ', 'f10449d181710893ccfe875ac0bd15929da8bd2ddc9870bb41a8fc0557cc653a63e36d56fa1f3bcccc2c82fa12bbe1cb17ae7ecebe8b4f9767d8bc880499f6f9BFoC5+TlnLtTW8FL+hJ3IkAVwuwNHb9EQNgagURcs7I=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '49c9adb18e44be0711a94e827042f630', 0, '2021-08-08', '2021-08-08 16:02:20'),
(15, 'Jean-Fogham', NULL, 'Jean', 'jboscoamad@gmail.com', 'Jean', '61676665e065d63e373e5d841fc2135fcf4214f957585d9244db6580431b9b5fe57f834968feb76adce71c01f4dffee40a1036c555df3f79ad134b92e3959401N7qVGewWUgR3boU40BkvgBPI0Yb0oU33MAC2cykM4Fs=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'afd4836712c5e77550897e25711e1d96', 0, '2021-08-08', '2021-08-08 16:49:00'),
(16, 'Abdul-Aliyu', NULL, 'Abdul', 'abdullahibabaaliyu@gmail.com', 'Abdul', '96323df3af7628860dfe627ff9fd65d73d0f0ac0e8e88c2c61e663875cc5834fd0c07cbed0a13d75dbd71762d9c0cfda18f4d9c802a2d3e9cad8a52029da484cGkcb3CaizvXPto21gnOHc+LbvJwI19Msgf/yer08Rvw=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2ba596643cbbbc20318224181fa46b28', 0, '2021-08-08', '2021-08-08 20:09:56'),
(17, 'Damian-Crowe', NULL, 'Damian', 'damianjcrowe@gmail.com', 'Damian', 'be423d69e74419f1fbc13f06d1c7220a02d229a248b402861c9dd2941b618c49a941096a53e7ae7c90676adf874d1f2d9b8610b0aa56ea90b10daac62e4f223eahEkRR37QEPU4adHOyUMaCF1txyUyOnH03PZVqD1ibs=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2838023a778dfaecdc212708f721b788', 0, '2021-08-09', '2021-08-09 01:53:19'),
(18, 'Damian-Crowe', NULL, 'Damian', 'damian@obillex.com.au', 'Damian', '42de6536f8255249f8289613cf3d0feb4fb289ade3e768756953b75f516b6b58d933cd959b98940286fd1cd738923b1e8a0376dbb5a4eba96891442d94b52eb6SrXt+BD2ng3I9q4CHj3Yz+HTwPlOVB4+MKDXvJN1CXA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '1e056d2b0ebd5c878c550da6ac5d3724', 0, '2021-08-09', '2021-08-09 02:08:17'),
(19, 'Ore-Tayo-Funsho', NULL, 'Ore-Tayo', 'ofunsho@prophasisconsults.com', 'Ore-Tayo', '9e4eb69567137cb40648d0930d01ee5764f5f2bee5f7630efe52c9ae4f37e8fc2d4c9e7460bcaa367e8d82c519404ca175cdae8816f33c0ab08cfef2123f4ef5eI6l8kJ48zVZ8yrNRwqu62IuVPfyvpl65kjQla71vW8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '248e844336797ec98478f85e7626de4a', 0, '2021-08-09', '2021-08-09 18:53:54'),
(20, 'Olamide-Funsho', NULL, 'Olamide', 'tirofunsho@gmail.com', 'Olamide', 'd1156367f8fe81076875434b3cc5d67236cc500d3b8e35e00cf22e3c77d804e5f3a2b083984269f80f3086504d2f17ab1e5f360160f0f295e4fb77f31ae9a4d1DsqsKdaQcsBx3d1Ewdh3I6Ayfn2ZYBibTNN3pHOanO4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'f4f6dce2f3a0f9dada0c2b5b66452017', 0, '2021-08-09', '2021-08-09 20:54:35'),
(21, 'Michael-Evans', NULL, 'Michael', 'myrewardsclub@yahoo.com', 'Michael', '34dded7a6b4cfc135d0d6f441c16d5bff561639bc301409b5be8c3481489d6ffeb685169931869a0157e29f91ceb17f137c061240e1859e4e6cab44bccb4d29aoZhcio8qq9fXI3EVsASkkwj8e6z3n2m1ogwpRsOAoT0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '3dd48ab31d016ffcbf3314df2b3cb9ce', 0, '2021-08-09', '2021-08-09 22:20:36'),
(22, 'sylvester-Otiji', NULL, 'sylvester', 'snotiji@aol.com', 'sylvester', '5c7c7fbb11222634691bd53b397995688729bdc3e89dada3057d9b7bf5ff54e26762a6ab43c70b280ec38246d9f7e4b4198d1616bb436a0e563d65cae8bea9d4B3oiiBz48jZ2H3bM9CeYAj/d7ntXASijVmiWyCeqBpQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'b73ce398c39f506af761d2277d853a92', 0, '2021-08-09', '2021-08-09 23:42:08'),
(23, 'Similolu-Akinnusi', NULL, 'Similolu', 'simi.akinnusi@mintft.com', 'Similolu', '8582a4bd2c79414a1b40ee940be7b59c8469c752365a0198db82cc026836bae53e7ed4b923aa1f48e3e5b6deb5dc65092dd98e6f2099cc483d81fec7ef20b10bgXFCthddu02paBiIdt2GuAPURG3M4GJ+FT1Lqehikgjc5YkGTKLJyQ/WXAWgLIuh', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c24cd76e1ce41366a4bbe8a49b02a028', 0, '2021-08-10', '2021-08-10 05:13:18'),
(24, 'Kolawole-Akinmuyiwa', NULL, 'Kolawole', 'Kola@prowheelsmag.com', 'Kolawole', 'f3e0c723432d5d2c685df6124743de323ec78244ebd479545da6eb97a598a201a2fa174f7df52ee06c1dab0038f186aafe41a09262df9da5c78538cedc745b28lCcxq58PYmgvdrONVX+Ul+o+h9SHGb67R7JmDJjhV10=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '34ed066df378efacc9b924ec161e7639', 0, '2021-08-10', '2021-08-10 07:51:02'),
(25, 'kolapo-ogungbile', NULL, 'kolapo', 'kogungbile@gmail.com', 'kolapo', 'c0470c0145bf5f3dd43974cf64064056155f27f93d75b38b85d0e020f687744d94008abf72b3fae2a72a96d47eebe0b38c07b0e15e09ea2697220075b177eaa7YTB9SIgcSNECIX559X3j1R//xH1jHcnwM0Epgrs27AM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2b24d495052a8ce66358eb576b8912c8', 0, '2021-08-10', '2021-08-10 11:57:32'),
(26, 'Kofo-Coker', NULL, 'Kofo', 'kofocoker@gmail.com', 'Kofo', 'd74de7d869adfbe8ac4d4d9fd4737629935582b3dd0d0378e36c784ec75589bac686d7937ac3725429cb5b2c6131c7ce6946495d964fd2525d935a8dc6fbbd9eELnglmgA3eUUxT7k2keviVqMs1gyBg6mlyAs3tLH4jU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '35cf8659cfcb13224cbd47863a34fc58', 0, '2021-08-10', '2021-08-10 17:01:51'),
(27, 'Ana-Everett', NULL, 'Ana', 'solutionsae@yahoo.com', 'Ana', '6d24ea7fd61223b1333bb6f1b5c94d30af741cfe8291bc75c028a3dee8b057f8c9908f894f7abefe92ad2cad8ab2130efd73b8325ad6ed678174cc4c90b5cf1c84WldWazLqKVK3g5BBHO8fudcSpS6GVFr9lV3KcETak=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ec8ce6abb3e952a85b8551ba726a1227', 0, '2021-08-11', '2021-08-11 10:39:20'),
(28, 'Godfrey-Phillips', NULL, 'Godfrey', 'sharebanker@hotmail.com', 'Godfrey', '868f8024de38b2993ee9d37b8e7d7f1614469feab1c1c2b9bf2fdb2ae2618e690a5cfd63104dc3a6973eb895dcf39fb8efb2873a9055375233ea61052e7cbda3Zbvwz1btJ7K5Y0cLlMgunObNRced6Nq3KxHFz6RsEbA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '38913e1d6a7b94cb0f55994f679f5956', 0, '2021-08-12', '2021-08-12 01:10:04'),
(29, 'Gwen-ABIOLA-OLOKE', NULL, 'Gwen', 'gwenabiolaoloke@gmail.com', 'Gwen', '7fd20a42e0734929f80e7e4840fdb27cc2f2e1c38e5cee0328cddf1278e5ac43b1a2aa1d9e3551621ec8e1fac7c13e91239c474171f0af8532a30093cbc50baaTD8Z88H+z19fTKSVbv3gvgfYbUdiXcyNAnEl9ViBlXA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '0537fb40a68c18da59a35c2bfe1ca554', 0, '2021-08-12', '2021-08-12 04:19:20'),
(30, 'Gbola-Adiat', NULL, 'Gbola', 'hhgconsult@gmail.com', 'Gbola', 'd616c9e503fde5ab1125c9806e7e13dd333b6c5f69ebf8a73adc6094b2c83f7e906ccdfcafe087f44bb8ac48a2d88353597a24ab017dbb44e278b48beb6e4a10Kwi6O2+LrF2P+OlEeu6gNHB/sqfqGpxs58m9mKflpyTfd+GkG1rG2Kj6DpgWmWwJ', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '4e4b5fbbbb602b6d35bea8460aa8f8e5', 0, '2021-08-12', '2021-08-12 11:00:46'),
(31, 'Ibukunoluwapo-Oluwaboro', NULL, 'Ibukunoluwapo', 'enochibk@gmail.com', 'Ibukunoluwapo', 'dea029e2c16ec2f45a884a9eabaab289678f91212f51feee613a4dccabb17dd9fefe60248ac30904ee93536eadd9e1993e49bc310baf88a90b8660eb318fc5b0pCtAFIFg0oB+bJbAjexlujrcqDu0pTmEGaN0s2Zx7GU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '45c48cce2e2d7fbdea1afc51c7c6ad26', 0, '2021-08-12', '2021-08-12 11:36:02'),
(32, 'Olugbenga-Wahab', NULL, 'Olugbenga', 'wahabolugbenga@gmail.com', 'Olugbenga', 'd679c68056dc68e96710ad542dda14b159cf1f8eb810b3515d141b0b8d06609d2d386ea0a1f8ce2ff32482dd6a38d735dfa251030f6237bf0f32981c113a64e1rAj+J7HeFSpV9d2dbWgFWQBwoUMVcMY0Zc5U9Aq9LUg=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '02a32ad2669e6fe298e607fe7cc0e1a0', 0, '2021-08-13', '2021-08-13 09:23:55'),
(33, 'Ayotunde-Adebayo', NULL, 'Ayotunde', 'ceo@globalmaxremit.com', 'Ayotunde', 'b58b73724f923a9c5355916141a3d0135966d2da17d998cc8100dc8ad483c2b6ce91201146444c5ff462dacb4de085fea4115f6784339aeb4c273b0ea84135492rqclfUe8fxZLgdT0J90bVuINCdNJJVO56Ji3DO0B5s=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '19bc916108fc6938f52cb96f7e087941', 0, '2021-08-13', '2021-08-13 22:13:31'),
(34, 'Tunji -Fakunmoju ', NULL, 'Tunji ', 'nhgcg1@gmail.com', 'Tunji ', '437a473ded3a50211f3485f649a24917fd7e8e92e94d785df0844272f55e2c3ad0a4fc52c53e821e50ebec98d3cc2fda2255da8c65a5a1916d6677dbc03725813TroiTcLAGKQiSg3h1Nn3RKVeWNjJRlKGbg/4c4XisI=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '38913e1d6a7b94cb0f55994f679f5956', 0, '2021-08-14', '2021-08-14 01:17:38'),
(35, 'Tunji -Fakunmoju ', NULL, 'Tunji ', 'Tfakus@gmail.com', 'Tunji ', '547fc9aa582df188b6b14c396e7d3e314834edc24a2507de4290ef0ddd01542682f16db86eca088876d8856a4d6b36b1567131caeff533291f46dbcc34eff8a3Ti9PVVIIUIECIDHZKEbb7r6bvuMlO7phgDiwe7zmX0c=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ce78d1da254c0843eb23951ae077ff5f', 0, '2021-08-14', '2021-08-14 16:11:24'),
(36, 'Abiodun-Olasanoye', NULL, 'Abiodun', 'abiodunolasanoye@gmail.com', 'Abiodun', '87a76b638c0cc285cce28bfbf2272af94dc87b14573804d13ebbd610806242608631ae4e2410d8435007b8d4bd33191602eb989e54d9c4cbc8213591d53ad76c1GRHJ+ZgLu1PKM47/Acs6PRTIbblOsLMj7swb9ET4czf4UTQJngvY2qpJpSWFe2f', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '32bb90e8976aab5298d5da10fe66f21d', 0, '2021-08-15', '2021-08-15 14:45:29'),
(37, 'JULIUS-OKUNOLA', NULL, 'JULIUS', 'onwardahipping@yahoo.com', 'JULIUS', 'b4c36173323b290010792b6f9578b20b1973bf4aa9a22b675c08ea395258745ab5b9fd2a3178f9044dd7728924b7715c8f33f5c84de0bfc99968526e03538ec2qdBMnnRY0pNwWfsF3q+B7bIWrvE2evTRriwCWH+9pqA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '45c48cce2e2d7fbdea1afc51c7c6ad26', 0, '2021-08-16', '2021-08-16 19:09:07'),
(38, 'JULIUS-OKUNOLA', NULL, 'JULIUS', 'onwardshipping@yahoo.com', 'JULIUS', '35fc1d1439de09cc564d3eb8d53fb16aa1daf0b25d9c1e9bdc265dd6cc461c696dec5b5cf5c88154d5981d5bb8413254945dfe4de82b6bd127ea0302d385b259MwvKD78DHNa7w1YUnK3XL0dA2Yjk0vMyxBEDDMwbXdY=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e8c0653fea13f91bf3c48159f7c24f78', 0, '2021-08-16', '2021-08-16 19:14:49'),
(39, 'Abiodun-Durosinmi ', NULL, 'Abiodun', 'durob2012@gmail.com', 'Abiodun', 'd81764d5abcefaf728f62d898b7d9dc70dc0afb94961158e868e1e16acadc82f4e9349bdbd1c355b807643d01b069e5f5b345a65dfb70d5b474fe3aec47791a0K7wRCVvfX6q+/bPcyh4FaCuIO600U75yfRg2rJrpMHk=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '0336dcbab05b9d5ad24f4333c7658a0e', 0, '2021-08-16', '2021-08-16 21:31:27'),
(40, 'John-Doe', NULL, 'John', 'johnlombela@hotmail.com', 'John', '9a7c6de2397976b0a138a1591e6ded6d48fcf646ce47338853745357d2c7e5b5c0aebbb524a6e824e993c6aa7eac51bb801f72ea453ed3e6420a73660b7403728AgXtwQIaDQUm6RMcVXTt1bdrgVQivh0wY3LqSSadk4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '8757150decbd89b0f5442ca3db4d0e0e', 0, '2021-08-16', '2021-08-16 21:31:35'),
(41, 'Olutoye -Bello', NULL, 'Olutoye ', 'toyebello@bandbllc.com', 'Olutoye ', '0886bad031e1222e38662c7c66a78ebb9798eb292a42d2edbc8036c76593592ead52c46c4678a836df896bf69b2a04838aee087911a8e9a24506464ee730a235adw+kOBqsXat5Xr70OChs28Fe+EWq6V7GZDPwD4+ziU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e205ee2a5de471a70c1fd1b46033a75f', 0, '2021-08-17', '2021-08-17 16:02:35'),
(42, 'Donald-Chapman', NULL, 'Donald', 'dchapman7@babson.edu', 'Donald', '0ebabe258f019f855932d9886e2fe658b17775183caa201b32b5b8cac2e88f6305e6b821ca1cc153eaa4080f763d31090f23e9d1a64d84f1f54911c841c57982jrONZBinZWHG+7GLzGF47HzTlzp2tdEDIeijacMDKNM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '950a4152c2b4aa3ad78bdd6b366cc179', 0, '2021-08-18', '2021-08-18 11:53:13'),
(43, 'Peter-Ojo', NULL, 'Peter', 'peter@peterojo.com', 'Peter', 'fff5a10dd70bc0aa674a253e8f8dec33c06ff31c91283018d23edb20cc55407838b44ebd7bd3809834261a459637c71ba8b2b731d4aba2cd115f27a5732e51c2G39YMB/ln9okKPX0bvgaH84t7FKIdYaB1Z1oCMMH5Vc=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '96da2f590cd7246bbde0051047b0d6f7', 0, '2021-08-18', '2021-08-18 14:19:42'),
(44, 'Abdulfatah -Suleiman ', NULL, 'Abdulfatah ', 'abdulsulemann1234@gmail.com', 'Abdulfatah ', 'b933ddb210cf37b24064015eba814de3426b2aa56fdf53ad348e84a6aaa1f3064d9a7331d4321f9060646fce6896a2ea0992888295efbd503604140190efa8c9Ti+2/ICP0H7/LcoR8t3c5QR7nl3fBsgJK1qthiP8e4M=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '019d385eb67632a7e958e23f24bd07d7', 0, '2021-08-19', '2021-08-19 05:11:45'),
(45, 'Abdulfatah-Suleiman', NULL, 'Abdulfatah', 'abdulsuleymann1234@icloud.com', 'Abdulfatah', 'f31dd0eb06fafa19293d45effbccfe458b701c7307ba69f686c2707e75a8fe1f2fe6b1558dea3796554d775f4809fce9770c16e5e258257865db0fc0d2dafa3bj9pQtXHH92fIgN+GT+ecp/TAMlwjrXmIbdAB/j1ceyA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'b337e84de8752b27eda3a12363109e80', 0, '2021-08-20', '2021-08-20 10:44:46'),
(46, 'ADEBANKE-OLUFEMI', NULL, 'ADEBANKE', 'BFUNSHO@YAHOO.COM', 'ADEBANKE', '4585b17a97a0ec47e33ef2a3c19cab44e3225d735728a89a42a807f2068f78e5a2d9b86fc7150f2a23f698168991a769e078f0c281ac880ca8c430872734176fR7ydv257MZY4/pitaBondrDVG2dbNTMY2Fq7Gtl1zCU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd1c38a09acc34845c6be3a127a5aacaf', 0, '2021-08-20', '2021-08-20 16:37:51'),
(47, 'Aothman-Ladan', NULL, 'Aothman', 'aothmanladan@gmail.com', 'Aothman', '449c3bcfd18648834d7848d14e56c4dc02a6663658cd4be3bfce3d7135608de004e5f861ca0651cf390b110b905055344bb3ddcd4f95663a8b9eb7d95d9ed6d6DWIvfDrmZtC7LWTTJPOAHPBPZEcpAAA3J6kne/rkqQ4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'a5771bce93e200c36f7cd9dfd0e5deaa', 0, '2021-08-20', '2021-08-20 22:49:06'),
(48, 'Kolawole-Akinmuyiwa', NULL, 'Kolawole', 'kola@prowheelsmag.com', 'Kolawole', '55ba78e848e9b65970cfc8afd5cf712bfd44e50ac8a231f1a8f4f9217d25ec1e231aafb22f48342aaabe4615bb21c53f08d93fedb5cc24ac9d73cd58314074dbyOTurMMDOnw+ZSUdbzJYKQYf31Xv5aJ773C6KLL34I8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e369853df766fa44e1ed0ff613f563bd', 0, '2021-08-21', '2021-08-21 20:22:27'),
(49, 'Taiwo Oluyomi-Adejumo', NULL, 'Taiwo Oluyomi', 'toadejumo@gmail.com', 'Taiwo Oluyomi', 'fb1e3829ea37545cd7807a82bcd52c302f50771383fa1c4de171297066d75bf824431473a907f7a855b192d4e09370dfbf5f9cf22f139028858c7dd4ed3b15abxOp+SN1I71kWEdYvQUOiP3D8HuDmTNBLusbRT/CjG2Y=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fa83a11a198d5a7f0bf77a1987bcd006', 0, '2021-08-22', '2021-08-22 00:57:43'),
(50, 'Olusegun -Palmer ', NULL, 'Olusegun ', 'alabapalma@gmail.com', 'Olusegun ', '4aacf44933f1a14a9a88078a5122c562ecb0660106ba65d73b35a8c6a5f2ade33fe7afc636770644fbebb1c07bc1990dfb05a83795c56775077b466f2f5e9b33eTapQUMjplliBMU4KfJIXk0bdu0YsBeJllpL1AfpqGg=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e6cb2a3c14431b55aa50c06529eaa21b', 0, '2021-08-22', '2021-08-22 16:56:10'),
(51, 'Godfrey-Phillips', NULL, 'Godfrey', 'phillipsgodfrey1@gmail.com', 'Godfrey', 'd73065401158ac8f54e15fe0cb2f3fc7fa4c94df233379e9dfdad8c7d7a14f68b2af3720a40888c80ede395ca41ebea156549708ad7c829878441c35ab59253axrXnI6qNTIIHiOnB2S3YEML3V/loCd4tGuCcX+sOFfY=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '13f9896df61279c928f19721878fac41', 0, '2021-08-23', '2021-08-23 05:36:32'),
(52, 'Xaviour-Aluku', NULL, 'Xaviour', 'alukuxaviour@gmail.com', 'Xaviour', '49648adc8b417b52bd67d643b0dd8d967869930a552787093282e5687d4227f275498e4c831b24ad0260e3f581c0e99d5bd227b8e06a758712da5e2cbe4c0d9bnnLK6P/3vuSL0kokh6HTyhKBJz6cvKFHolfMkxTt+x8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e820a45f1dfc7b95282d10b6087e11c0', 0, '2021-08-23', '2021-08-23 14:21:16'),
(53, 'Ekunda-Wonodi', NULL, 'Ekunda', 'eowonodi@gmail.com', 'Ekunda', '01f7fd949efa2bf81190945e819785c264d2163258fbf3f1c9eb72e201359e265eb896bdbb29d15711f3113e9c774284fa4e14b4703c3e67979efa7aff9a5b3aDPMCa1ZR3xWUcQ5wMezkjOmx7RLF0OrrurtUFj6rASo=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e0c641195b27425bb056ac56f8953d24', 0, '2021-08-23', '2021-08-23 20:10:51'),
(54, 'Tunde -Adegboye', NULL, 'Tunde ', 'tndadegboye@att.net', 'Tunde ', '539b91a5dce90876c231b8cc6c5126a74d8d7eba05cdaabab51b0d7c7ff624e9e5c986791c9237606656f915f8e5ac333ea91759b063ba0686b39838861ab897AeK4s4YEoFqAXjJyq4do9u4zoB2RD6SK4zvjjwc9HjU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '959a557f5f6beb411fd954f3f34b21c3', 0, '2021-08-24', '2021-08-24 05:56:21'),
(55, 'Gifted-Steppers', NULL, 'Gifted', 'giftedsteppersdance@gmail.com', 'Gifted', 'b0b1a3a5156acd3c66ad7af58969f0b3ad96bfb55cde95a9d224f5905afac93f9b3b15c5c847c63d5163f060478843aaf8479ac27f432b3df706e8806c931e60sBRXUo3onN5N6DbWeXtVDYFxW+w5LSARuZyPBreWB/zMnBLuJZOfCX+UyIjW9JXd', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2f885d0fbe2e131bfc9d98363e55d1d4', 0, '2021-08-24', '2021-08-24 06:24:10'),
(56, 'Ihuoma-Harrison', NULL, 'Ihuoma', 'harisonoma@gmail.com', 'Ihuoma', '858e1481b8a6e2ac3075810be249d7349a31db22b0496d9707a9f8b960a6774eb14ad3d00e4665035c1f18e2b155472ebc4048611bcb9c5504e7a1086e7a0e89qr0O8+jzUZ/IQqy44czz6U6g7o4Xij3iOR8/71EHmCI=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '605ff764c617d3cd28dbbdd72be8f9a2', 0, '2021-08-24', '2021-08-24 08:45:37'),
(57, 'Babajide-Abatan', NULL, 'Babajide', 'jidronk210@yahoo.com', 'Babajide', '2ff03b656b1d85407874ba2324a56d420e6904d91e3396106a097f1831007c0b0761ec2ebab11ce656712782e50009254c412e6f46bf80dcdc73ea3dee41ffaegaIyefchQZk0hg+4RY+s1i8oOQn0qDZXan5qLgu/1b8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '8c7bbbba95c1025975e548cee86dfadc', 0, '2021-08-24', '2021-08-24 17:47:37'),
(58, 'ola-famuyiwa', NULL, 'ola', 'olareal@gmail.com', 'ola', '2959eaedfa52d41bbb827b82b2fe83dc2788b2937e7343eb5d79d66bca5db39e2f9afa78bca8eff75844de51d6c78391f2b6634391a32e9295ea35211f775c24I5qVE+N/N7C0El2dCib3QjGAaq/ZFB5OvLo5s7iBtTo=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ff4d5fbbafdf976cfdc032e3bde78de5', 0, '2021-08-24', '2021-08-24 20:04:27'),
(59, 'Chukwunonso-Arinze', NULL, 'Chukwunonso', 'chukwunonsoarinze93@gmail.com', 'Chukwunonso', '8d3447aef3cca9876ae4fb399e8a15312d5fe7870dca01ab858bf1edfaf55122ebe6112f80ad962b668679b8a948c3430f4ee98ce25cda76d3eddcd048213aee6QyrghaVJp/c+sa50OS/Dny+WOaFXfYDe+XQ8RhbJK0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '0a09c8844ba8f0936c20bd791130d6b6', 0, '2021-08-26', '2021-08-26 06:01:25'),
(60, 'Nas-Sh', NULL, 'Nas', 'ns@xenio.in', 'Nas', '4f62ee608f8989bc4f399d0b12033a77925525084949c45e3e3fb07fa0f6177ecba524df4acf8ebe46518d2c06eee7dfdf28085bf40ff194a8757e14ca8c648aG/Anca551SuLkvMW5JppfqJ9bkXmAgB6/FYsKLg0qvs=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'dc5689792e08eb2e219dce49e64c885b', 0, '2021-08-26', '2021-08-26 07:11:41'),
(61, 'Darwin-Carreno', NULL, 'Darwin', 'mr.darwincarreno@gmail.com', 'Darwin', 'e6d824d184b5928fbae3497d765085f81d6788ad0cc8e4ae53fa4d74b182d1dae436dfb7568e524d5621742847c29f2a21eeb54d7a7410d68b912975b94eedc5uxwAJWY/Yqb+YbbpBRkOmXKIb2UxTa3lbM6N9Lo3aF0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd93ed5b6db83be78efb0d05ae420158e', 0, '2021-08-26', '2021-08-26 10:04:36'),
(62, 'Gideon-Adegbile', NULL, 'Gideon', 'gsadegbile@yahoo.com', 'Gideon', '01dc472787d5cd5f5c973f47d1a7e1095575da1e9f3dbab826a21739640539e46744431bf5f26f072bc18f6eaf3af24a841876ba044f74cccf4a65fefa1809f2noZaL0pk28pHrC8MGc5e3vmhQPHLkBqwOTzdvuYVwxo=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '8a0e1141fd37fa5b98d5bb769ba1a7cc', 0, '2021-08-26', '2021-08-26 21:28:50'),
(63, 'Akinlolu -Oluboro ', NULL, 'Akinlolu ', 'aoluboro@gmail.com', 'Akinlolu ', '3c9b68e6e23f3e04fd38ce3ba9a300e2bced52be4ed22a4a76104db2754e2b2b4650c0c4b630a17254dc962e5bc52aef3e8d244c266e6c75cedb379370c02c128Y8shGZ7pKH+9OGlPoQQrBmg4vSGRkOvjHew2AW77v0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '01f78be6f7cad02658508fe4616098a9', 0, '2021-08-27', '2021-08-27 08:13:29'),
(64, 'Joel-Phillips', NULL, 'Joel', 'jojophil1357@hotmail.com', 'Joel', '932092cee34de1081d34d41f4de4a9fa62a0ae44d0381978b0bcef0b50e8fc2f6cb1329319ab1e1cf7bdde8d7f239d086132e014617f74f1f84f4d48911717bbM3uWPfMj/NCdvcsp7RYlIg0OQHZM8GFrCgUFtiH0GcQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '1700002963a49da13542e0726b7bb758', 0, '2021-08-27', '2021-08-27 08:37:52'),
(65, 'Julius-Akpojiyovwi', NULL, 'Julius', 'vote27002@yahoo.co.uk', 'Julius', 'ec16ae9296a0561b30df89c394e1217c206efe35830609c1b88b07b01b4c1ce78a1d95f64afbb41b016cfd2e4335571a6758ac34c4894dbeb0c1a1998a4a95e3rchMjxJDvn+TJ6eCMsIhQaK0wREpREF6YbTibTZkxIk=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '8dd48d6a2e2cad213179a3992c0be53c', 0, '2021-08-27', '2021-08-27 09:35:49'),
(66, 'Anthony-Rumuna', NULL, 'Anthony', 'tyjindustries@hotmail.com', 'Anthony', 'fc2dd0642a93857677e66983c00a047cd86b08703a5b315c97052cfd15217fee0b9b36ef08d8ac8de6492198c2f983e5e9dd7077d278a90d685cdefcf0c2cfbaPQjwinGGx0zGCiH5UoapzhoIHqgfCYtXW+KxKCCML5E=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '959a557f5f6beb411fd954f3f34b21c3', 0, '2021-08-27', '2021-08-27 10:17:59'),
(67, 'Abosede-Popoola', NULL, 'Abosede', 'bosepopoola1@gmail.com', 'Abosede', 'f87779967304ebaf69e3a9812de58e813adcec2520b2ada978ee020404f9ce1859b8d2f278d123eba7c4e50bb6ee0dd04f548d88a34414e4defe1799c928247eBYfa1u/bH18XPgp4T9sAqsuqM003SrLnoaurtn0sxn8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '7f39f8317fbdb1988ef4c628eba02591', 0, '2021-08-27', '2021-08-27 10:38:13'),
(68, 'Olukunle-Obadina', NULL, 'Olukunle', 'kunleobadina@yahoo.com', 'Olukunle', 'a450d44dd2d3de9ad357b4bb1e731f5763cfc3fb23bb9b4e391f360e1b799019d6de4ecb289311d223d9bf7e956f6113740c05b387a340f3f5487f673a867131KKEzJYxwSdR4V+wxI1cSrLyoBFoLlQZNzdrIZiiHJTU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '6081594975a764c8e3a691fa2b3a321d', 0, '2021-08-27', '2021-08-27 13:52:13'),
(69, 'Akinlolu-Oluboro ', NULL, 'Akinlolu', 'olayinka@gmail.com', 'Akinlolu', 'd7c352c990c8fa3d48d08d2de93fb65fd70cb74c6384039346bdb79abdc44f791181c2688542bd4f632a7a2692912e9bbb71b4d16244dee67db0a3023113b09fdCQ/OWccuhDwfItYo4tjXzO6gBRrATAR4+E50CVw7SQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '19b650660b253761af189682e03501dd', 0, '2021-08-28', '2021-08-28 06:58:30'),
(70, 'Akinlolu-Oluboro ', NULL, 'Akinlolu', 'sakinlolu@gmail.com', 'Akinlolu', '$2y$10$fF9tot9xtPl0Cr4bgGyatOn.8k16388oJEgbp4v/s3witDh0ZpvHi', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '3c7781a36bcd6cf08c11a970fbe0e2a6', 0, '2021-08-28', '2021-08-28 07:26:46'),
(71, 'Mohammed-Altaf', NULL, 'Mohammed', 'mdarbaz123@mailinator.com', 'Mohammed', '914e98e475185f0cf4e66e4f2758503245b751797487326e6fca4516fc1826b083a970907b668f8d6da2663dd88981acdcd791ca2baedaa9d426a5c791955cb4pgV/NMh27CNkb+WhiMkcBsPTQajxJpFjI5UYVRxPM0c=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '98b297950041a42470269d56260243a1', 0, '2021-08-28', '2021-08-28 11:26:37'),
(72, 'Titilayo -Oluboro', NULL, 'Titilayo ', 'kadijamotunrayo@gmail.com', 'Titilayo ', '1519c1a88bc55d1db37fd0261b342797405cd229bc03836e2893986dfafc6d46c04bcdab220cd6bc968602daf88d13de93b73f865d4cd2940f58e7e064790acf31jpFlz1Xlizvy+di757d4vRl5TR/TwX5AlsAGlxj1Q=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fc8001f834f6a5f0561080d134d53d29', 0, '2021-08-28', '2021-08-28 17:10:33'),
(73, 'Richards-Afonja', NULL, 'Richards', 'aareonakakanfo@mac.com', 'Richards', '65b7bcfc6e8a9a00c214b771c505f4e8a7615bff956615915a925cbba61cfea3fcec65ba221b6374fba7c8dd7a96467eef0ccc2f6e0864af3342441bf6d8f476YTISbzi6aZ9mCFV02PNHiaoJpBr8LfvYXtDIqX194ew=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '182be0c5cdcd5072bb1864cdee4d3d6e', 0, '2021-08-29', '2021-08-29 22:20:32'),
(74, 'Ayotunde-Owoborode', NULL, 'Ayotunde', 'ayotundeowo@gmail.com', 'Ayotunde', 'f829690ca04cf0406307f8b0ede282f76bdfa47eb5a768135ea1f6287e67fe84b1b3657b3cfe8675895c049b3911e4ec72341c593b894369508e5501078d949fPCMVZndH02KUD6d+SV5H6BU7zs4j1F1eb9nfmzkstqA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c203d8a151612acf12457e4d67635a95', 0, '2021-08-29', '2021-08-29 22:43:52'),
(75, 'Frank -Alarapon', NULL, 'Frank ', 'ariesfrank2001@yahoo.com', 'Frank ', 'ee3b7ea1c9929d861e18f9ce4380d50190c1885086985b076bb48cc183b3abbb09f3d53839d7da2449ae4d46dafe530883b972f1d5dc8d8385355b20bbf1bca5wwbpDpQ24/pXQkRe6fSffnA3dpVs7o2pPUnJDs++8+I=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '061412e4a03c02f9902576ec55ebbe77', 0, '2021-08-29', '2021-08-29 23:41:23'),
(76, 'Wale-Olajubu', NULL, 'Wale', 'waleolajubu@gmail.com', 'Wale', 'cbaced28e1e62d4f8cdf6bf3f6d96f660f124f5b1daedb34a2a8a1b364485827f6123869a2a432eebcd0b34805cb56064feb3c25f483decf45b1fa44de03748daQc3WOgaumu6lTXg0vUpvm/TDE0iJmzEGW8IijpS5W4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2d6cc4b2d139a53512fb8cbb3086ae2e', 0, '2021-08-30', '2021-08-30 07:54:19'),
(77, 'Moji-Renner', NULL, 'Moji', 'catheer@gmail.com', 'Moji', 'f3495ca63c01abdb1524343ec2e7fcefa159b731e355303c725b91729b234b0c0a5f848ec54334512010addd81f48cd9c20701b2531900c7c6c3559a7c86530bOx0TZll+HK5MWKL6ficodD8ijdfkaFhNCi1FWNroeK0=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '04025959b191f8f9de3f924f0940515f', 0, '2021-08-30', '2021-08-30 20:43:05'),
(78, 'Matthew-Daniel', NULL, 'Matthew', 'matthew.daniel32@gmail.com', 'Matthew', '755ee43e17ed2a40453b961a0cdbd48f0fd100edc01438e61610599e344e9155a0303fc9c347228545a9f5738401a2bd68952e555db1a34638f3004a95c9778f+QqMoS42NXy9pq0K6zDMQ/8HRYcImHmq1ikcdPUye2I=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fe7ee8fc1959cc7214fa21c4840dff0a', 0, '2021-09-01', '2021-09-01 11:17:53'),
(79, 'Ademola-Adelaja', NULL, 'Ademola', 'aadelaja1@yahoo.com', 'Ademola', '530b1be6ef7a1f4b7313ff99a416d0f44ae9fc5dd07aef3389a5cc09da419af123858dd4f8984eccf504bbaf7f342f33f8aab805f4135246f3b6e250223b10ffKkFgq1gtDXKnvueBT93Sz9JY8FCIV7IQldw1JmJ3iiI=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '233509073ed3432027d48b1a83f5fbd2', 0, '2021-09-01', '2021-09-01 12:14:13'),
(80, 'Rick-May', NULL, 'Rick', 'rick@metou.com', 'Rick', '7e73add5d2d82458e669e070f6545b6e9079cf21aa57ad107805c7df16485a16286fb0ad4e142dca81d4ef5ec30254fae43c9e3d34f9f88952b121abaeb093d6vdhMOt7XZE/u/L8t95RXkk01xb/oAI21HBszMCa/JaQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'b6edc1cd1f36e45daf6d7824d7bb2283', 0, '2021-09-01', '2021-09-01 16:21:15'),
(81, 'Ashish-Shrestha', NULL, 'Ashish', 'ashish@machnetinc.com', 'Ashish', '40ae144d9c414cb17a548bcdc590002e1f3e7d5c3d0759aafac889af38e4569eef2f7648fa1927fab336cd814404a723efae866da7cbb7177e1e426471d1d8c8MLxW66hOCpzm+4kCUTVdYw7TZmLgzzjnuqsBd27YDHg=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2a79ea27c279e471f4d180b08d62b00a', 0, '2021-09-03', '2021-09-03 16:36:38'),
(82, 'Remi-Duyile', NULL, 'Remi', 'remiduyilessa@gmail.com', 'Remi', '49fa4848fb305cd9c44aacc3df23c65b918eb026c01f4bba2afeb8da0fc5ae77cf51fcb0437fc26cb2a2d09289bb2e181b4374a32e701f3a3aca30743d3edec9oMYGIRj+1TOC0067mlMvzQNWHPR5/dMM3k6KoSRdTXE=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '30ef30b64204a3088a26bc2e6ecf7602', 0, '2021-09-04', '2021-09-04 21:11:47'),
(83, 'Dale-Wafer', NULL, 'Dale', 'DEWAFER@AOL.COM', 'Dale', 'b935c4791e99d92701c7dfec2068191123c65523f823b25694c8d9f960722d80713ba30918b6b22f02e0d651f46f399ac1f74280b3eb0fb393c1869dacf090bavnNI5epUPgoqg+7tq87W5eBHj9gG4l7h0iC7LgWov9c=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '605ff764c617d3cd28dbbdd72be8f9a2', 0, '2021-09-05', '2021-09-05 02:30:40'),
(84, 'Dr Roussan-Etienne Jr.', NULL, 'Dr Roussan', 'info@roumarketing.com', 'Dr Roussan', '06d44e8f376855f42e552d92dbf639435cbd6985e1ec9c32fa1623e5296e08ff67ba0071a0284755d54ead8cbadd68721827c98e44cb748389447da00de35c98aLwYy+JMj6saQwpbQpV/y4kYJWC/IMs7o1TebWhW5lEwjtcahb8tXVMQsS1Gc2+y', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '3c59dc048e8850243be8079a5c74d079', 0, '2021-09-05', '2021-09-05 07:27:54'),
(85, 'Dr Roussan-Etienne Jr.', NULL, 'Dr Roussan', 'rou@roumarketing.com', 'Dr Roussan', '25318a9f8e021546481309f882bbcb20d5a9a79e60cb996d9c49f6ce7c5abc13cffc30cfdf54d45e52e27d3a86e1af3a21e2e36ae246f1c254e38d006fb803992sNlQ/FbvrnCfQZLTt0yHeaT/ASz8WoKgr3CZqSpn7xAHBIth9J43fA0Yq5QBdR/', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '3df1d4b96d8976ff5986393e8767f5b2', 0, '2021-09-05', '2021-09-05 07:43:30'),
(86, 'Amani -Talbot', NULL, 'Amani ', 'cashoutdre59@gmail.com', 'Amani ', '829f06c7a9bdc8ff1ca3d50df5e79d1acf1f08934863e1f43f8f3a239504e9757480428bd9ff2a24ed987392eb4e96d94742df32e8151c49b28f0af497f7b723C5iawFjt1dRzGvY4DRGgLVHN1cv1xfh0leQs8kcj9/Q=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '38b3eff8baf56627478ec76a704e9b52', 0, '2021-09-05', '2021-09-05 13:02:13'),
(87, 'Eva-Thorne', NULL, 'Eva', 'cocoref@gmail.com', 'Eva', 'bdc136a5e4de70e7a2847b8c6d00fb8ff0443d0e602f7ae70009809ba1f6c12b9101d827a0462c9a35073bc7c16b4288c5ed690cd8378498c59eef814b33733630pETJdkaoJ5GHexmJoe31WUOZYU+psF5WwbPkfZvXc=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '9fd81843ad7f202f26c1a174c7357585', 0, '2021-09-05', '2021-09-05 13:21:31'),
(88, 'Hassan-Foipon', NULL, 'Hassan', 'fhgolnett@gmail.com', 'Hassan', '6555f69bd8df6506c554a00bbd300ebbbdff1793a9ac37c889c157c63938f2d09ad2523abafde2e373c73f7afef3a6cfd965dbe50e31922959690b91640ea887eI3VYSE16CNcXw5/pvw0Lcl4TjV4ZsTkvhUgY+1o/Wc=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fe8c15fed5f808006ce95eddb7366e35', 0, '2021-09-05', '2021-09-05 13:44:59'),
(89, 'Mario-Jenkins', NULL, 'Mario', 'marrj12@gmail.com', 'Mario', 'af6151c66091ee764581c58cd9b3c6302fbe613f27bc5eda203eea552c3f025e685d9b5863d31e132148470d8ab701fbfff778adee1ff58db786a19b061d5901vxiLFyd7ilFteiFS0ADwvicpCeN74rPBD6QXQElhTaQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fa3a3c407f82377f55c19c5d403335c7', 0, '2021-09-06', '2021-09-06 10:30:32'),
(90, 'Frank-Obasohan', NULL, 'Frank', 'fosagie@aol.com', 'Frank', 'b5c5dc5b64b080e5e30290cd8bcf32eeaef8a8d1064bcb236a2d8f0a82b4f97a8e90a46699a43191c7e46cf44598291b2f6529b8e0a5ac80019744ccb3a32c49aHMK+ZJt2DkziYGxfzUzgRGdPu/JooCPZMv7kr0jt9E=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd645920e395fedad7bbbed0eca3fe2e0', 0, '2021-09-06', '2021-09-06 11:54:43'),
(91, 'Dale-Wafer', NULL, 'Dale', 'dewafer@aol.com', 'Dale', 'e87597e5fe639eb3f48ab2130113e119b76236579c50e2cfcc949ac3e23f063b855341a4af8fd3d6a7b5ed031fd061998a28b8853182160783c719653106f3eb8YKN/LI5SPGOGO4uE7c9xhTIx9p9ASwP6IiKu+cO9E4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '5751ec3e9a4feab575962e78e006250d', 0, '2021-09-06', '2021-09-06 16:18:48'),
(92, 'George-Oluwaboro', NULL, 'George', 'goluwaboro@gmail.com', 'George', '5440c1f049497540687c8e5752b915c42afd57b3a1d236274d9bcd061fc755bee6afaa690c9df37d932a10e323e85ae18d35c203917472fa7fcf8c45422969643dH+hTonVy+vvXufyPuijri/aR19F2yTKtwXe+784FA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '1f50893f80d6830d62765ffad7721742', 0, '2021-09-06', '2021-09-06 23:58:36'),
(93, 'Kunle-Kuponiyi', NULL, 'Kunle', 'kunlekuponiyi@yahoo.com', 'Kunle', '2726f3a37a8f4ca9d25814b5122be440af9342e908301a3b04fcbc896f5495086253b80430d928913d3ef771d59c35c05c160db95e2e1d918c164989063ce7c7mujEFgJWFi8/UbBS08INGMiZBC4faN8VH0U3ouo/TI8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '621461af90cadfdaf0e8d4cc25129f91', 0, '2021-09-08', '2021-09-08 13:37:56'),
(94, 'Waziri -Ibrahim ', NULL, 'Waziri ', 'wazconsultant2@gmail.com', 'Waziri ', '1628e45f6868a598bfd3272af267b51d6451f0eb6182e420894758ce07c5c467f4960bae76bc227daf0fc46cf926487bfac7606d2ccb3b1f888673465e3129f1YOUiUc1YPkERUp/PtUndzHlt3Kjhzhj3mRiMfCGN450=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '36660e59856b4de58a219bcf4e27eba3', 0, '2021-09-12', '2021-09-12 14:13:44'),
(95, 'Daouda -Moustapha', NULL, 'Daouda ', 'msgroupllc@outlook.com', 'Daouda ', '867e9c978b46e80cb76121d036cc1a1c1e1f0764478022c3785633bb67ce4d8cef3722c16b6c42bbac2a468a4161648695b119f743386b9f86e6b36f08cfbfcd8kr0fKITQNRFn3V8/GjZ2JFkmKjaTe/NI39V/5zEAlQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '847cc55b7032108eee6dd897f3bca8a5', 0, '2021-09-15', '2021-09-15 11:47:07'),
(96, 'Alexander -Ayanru', NULL, 'Alexander ', 'alex@sandiainternational.com', 'Alexander ', '85887831bccf290b4576497081a85e6e46e4275730dbec2f5fc585f8f3b437f103a4e1dcac9a6253826e8bf7e29bd20a039999fac6e7d30ea6d855918a32ae0c1EK87ezHLANlTNRdSShVc7FSTzhvBt/3+z/ssLPbkmk=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '357a6fdf7642bf815a88822c447d9dc4', 0, '2021-09-16', '2021-09-16 19:33:35'),
(97, 'Abu-Bah', NULL, 'Abu', 'abubah74@gmail.com', 'Abu', '8efad1951bedfeb707a667a4b357aeb7c351286e1711724661ee4a16de3b27297096ecbd46f21a9d4b3ba7979dc4e9d399bb3b2d165457e7c78ebc134f7dd401IvH0l/Mv/cW9A7jMVJwm6CHZLaEClWBcJ156J/LEMP4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd707329bece455a462b58ce00d1194c9', 0, '2021-09-18', '2021-09-18 12:20:06'),
(98, 'Olusegun Edward -Ojo', NULL, 'Olusegun Edward ', 'usojoolusegunfunmiojo195666@gmail.com', 'Olusegun Edward ', 'c5b1c02221431ade7ddbc60a437590b4974f75bbb70ae19712fa9bffb6431cc922c002ac5c0cabaa4c1c41794c7e0dfe5fbc5a9a2f855528c72049274ec73b07XLv68l/l3MIiw/nYIm/kMvH9mfx3i3gWwdcz+7k2++E=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '7f1171a78ce0780a2142a6eb7bc4f3c8', 0, '2021-09-19', '2021-09-19 08:36:45'),
(99, 'FAFOWORA -KEHINDE JOSHUA ', NULL, 'FAFOWORA ', 'mkennyjoshua@yahoo.com', 'FAFOWORA ', '54f63a4583410d4e666f088d5346140d30c045b2953c36c4f5c085437d97125f5c116cd1e9ec323c50b2faae2611f11e8a0f932a13493cc41edaa2516256b907OH5RGf13oelmSJsLWpyJmsuNi29kRglJ4nJlB1FRlSU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '0d3180d672e08b4c5312dcdafdf6ef36', 0, '2021-09-19', '2021-09-19 12:09:32'),
(100, 'Kayode-Idowu', NULL, 'Kayode', 'bishopcay@gmail.com', 'Kayode', 'd058c4223b4b395f19e242a2545ff62b9c35d003aa12db016c4b0c64b522350e4dc34f0e9171aff4a515564f187233c0ed0c03cef27d438a88e9ee540e429c5cy37i9a8llmhKIw47uZhE8DBaLkgaWW1+pDEKNML7Sds=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '4c56ff4ce4aaf9573aa5dff913df997a', 0, '2021-09-19', '2021-09-19 13:00:07'),
(101, 'Kayode-Idowu', NULL, 'Kayode', 'bishopcay@gmail.com', 'Kayode', 'a558249b314ee6a2696421f25a9bd910e0283798e0df8fb440104f57aa8d26c6bf5c8640adc40c9de522ec66e233764b9210ba9714100447fb8676e28607d960yqmYXVdOTasyeYfWwy2Q/WIGmhShxc8l6oAKm3vsgTs=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'a5bfc9e07964f8dddeb95fc584cd965d', 0, '2021-09-19', '2021-09-19 13:00:20');
INSERT INTO `users` (`id`, `name`, `title`, `slug`, `email`, `user_name`, `password`, `role`, `account_type`, `user_type`, `phone`, `address`, `country`, `city`, `state`, `postcode`, `layouts`, `image`, `thumb`, `paypal_payment`, `stripe_payment`, `paypal_email`, `publish_key`, `secret_key`, `razorpay_payment`, `razorpay_key_id`, `razorpay_key_secret`, `status`, `email_verified`, `verify_code`, `hit`, `trial_expire`, `created_at`) VALUES
(102, 'Adesina-Akinjokun', NULL, 'Adesina', 'aaakanjijokun@gmail.com', 'Adesina', '5a0e79d9600633b288e2bbe2fa34694643a75f388a46072a7aab0aa91f20b192bb0f1fff2b4bd35b3ba3c35401677858a4efee89de7ab2868f76896abdbf7ab3eeSxW+n3uKc4g4WXUDVG/wSH1b05zPwIVrEDzyt+BI4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c2aee86157b4a40b78132f1e71a9e6f1', 0, '2021-09-20', '2021-09-20 05:08:12'),
(103, 'Olatunji -Faboro ', NULL, 'Olatunji ', 'ofaboro@yahoo.com', 'Olatunji ', '966197a6b66eba3ce2fc8c198fcac09633430f0dbd40eb7bf585ec940f5e6b461ae7f548ba228faf6ee5e3968df911786ec5e7f7e1022cd9521221f93bbf420f/H9G4cE0I/ZG99tCd5CyrcpXiJjc9HmmCootZKqVZbc=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '6602294be910b1e3c4571bd98c4d5484', 0, '2021-09-21', '2021-09-21 14:17:45'),
(104, 'Nicholas-Phillips', NULL, 'Nicholas', 'nicholas1phillips@hotmail.com', 'Nicholas', 'b1d0c396e3f13a18c4d1cf3262403f65bbeed368d69039df4652d022be1904c836a9ec0864f9b688c6047c0749e45e429455337ad7232147f77fc4e7a49e29b3GyUQQ3VotdI4fJ/OvlOuhvOD9eUs2w3biEEkSVTpaik=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '4f4adcbf8c6f66dcfc8a3282ac2bf10a', 0, '2021-09-25', '2021-09-25 14:02:06'),
(105, 'Abigail-Phillips', NULL, 'Abigail', 'abigail1698@outlook.com', 'Abigail', '6fc648808084db98cbcdb92818d6441564f5a2065ef0df6bc1a4f227991770f1606f593eb9dea2a6f7bab31835801a46de64b2168f8d15cb622544ebd3615290b/NTZ53MUg8RF0FuEzwvuyfKf1Khq/89LYENv5hwrFQ=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ca75910166da03ff9d4655a0338e6b09', 0, '2021-09-25', '2021-09-25 14:12:12'),
(106, 'Obinna -Anusiem', NULL, 'Obinna ', 'bizmen@hotmail.com', 'Obinna ', '236b559b76fceb784bd91ed6e341c7d86d105fef61e0bde00cb03696141f4203e0a882b68832a41f778aef1fd7030157576d4fb46499b6733df95eafd1a2a9e3vFnfv/QwJ+BDddv6hIy3ljU8hT/14734g5l/0F0hWrk=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '1534b76d325a8f591b52d302e7181331', 0, '2021-09-27', '2021-09-27 15:50:18'),
(107, '-', NULL, '', NULL, '', '6ba51e9db3cd74fadbf02a298bd8e95de7b1d83d74228010cc94802562cfaaed8fac0e1be13da789fbbf029a48175cbf6719c6f37d1696c4e047b41ba8967a79Kzdq4XEDXa/1IldRA6qWIgrfhWRnz7f+iPmT+7SYmbY=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c2626d850c80ea07e7511bbae4c76f4b', 0, '2021-09-27', '2021-09-27 16:58:06'),
(108, '-', NULL, '', NULL, '', 'f849da8151f4fb9017bfa1fd9e1f78b63baceb9bdf7991b1969e5bd054faa87c5396bf169cbb65d71afbf8b679e50591ca1976c56cdd81bfdfb32253becc9175HKis8PXcKJgkvL+njHVey2YCv4opSk1t9Ovy/shM2Pw=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c3e878e27f52e2a57ace4d9a76fd9acf', 0, '2021-09-27', '2021-09-27 17:05:35'),
(109, '-', NULL, '', NULL, '', '25d5af429c20f0d9a615a9a73f981fda67c37718994e53401a07604236ae65144e9dc1851e5790853d1ca7c938357ff798bbd20baecc6ce8826913c79a153f1fgA729qOvUaPpaLPOXOGlNL8hhHZzDwupRjCPS4Zcbsg=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c399862d3b9d6b76c8436e924a68c45b', 0, '2021-09-27', '2021-09-27 17:19:25'),
(110, '-', NULL, '', NULL, '', 'cfd25d06efd8fd460451143230f256027be27f7c172f138fd4a2e0cc1db6ab6fefb97bd83b0f7623c106c6d3b81e20e3a84d2a737a5b2cc60086a027ba866cbcDKdOjr80cAA+wd14ll0cFjTwYXnakHkOe/Q84bAZpIU=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '8d34201a5b85900908db6cae92723617', 0, '2021-09-27', '2021-09-27 18:14:28'),
(111, '-', NULL, '', NULL, '', '7db8949773d283ed593eca4b722abbcabf06b92a0a85d9b69c4620ab873e89767570e845bb31edbc02e413d61a28233c392ec5d746d60ebe07d70a500029c033dC/OVQ08ymqQ+PdBcTLnVcBgw9n6hJE8tXFuUyV7q2I=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'f7664060cc52bc6f3d620bcedc94a4b6', 0, '2021-09-27', '2021-09-27 19:20:21'),
(112, '-', NULL, '', NULL, '', '5dc88f11fa8aaf185f9e64a1a015ba067bf6fce1f645067b5ae09d78b0d495ec5b2a5ad4007031e696160274f6503b6e4ee7fdf6d9c22484cf6f8d726eeb0e1049F42YFrpigzyXasN50c+6JbRzyosx9nq9P0+sz9ZdI=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ff4d5fbbafdf976cfdc032e3bde78de5', 0, '2021-09-27', '2021-09-27 19:49:49'),
(113, 'Mark-Boswell', NULL, 'Mark', 'mboswell05@yahoo.com', 'Mark', 'e2d75a48cc4718d141816adca9df0b8f358a635385d4a33b2c4f8f507f5f94254428cb8ce3f7f0337747258c5f46ec621ae5d4346ec101698edb4aa1b60a2701LRV9m0jru2Yi3AO0xqvg08+ypoS6XCb5nlbZjWQGP1U=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'd14220ee66aeec73c49038385428ec4c', 0, '2021-10-04', '2021-10-04 10:51:08'),
(114, 'Philip-Ikodor', NULL, 'Philip', 'philikod@gmail.com', 'Philip', '2258c91db3286079e7a183362fc38943f3b83ae53b758e3fdea62982ceaf53f0b862eb2dc0b65f0d6098df48f561851effadd6a26d5ef211bf1194c304a70283aQMyndEgQxdY9gU2WCkby9MZORk613CzNHhMdCeGyg4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'f0adc8838f4bdedde4ec2cfad0515589', 0, '2021-10-05', '2021-10-05 14:19:53'),
(115, 'Mark-Boswell', NULL, 'Mark', 'Mboswell05@yahoo.com', 'Mark', '01a75c127c738c344a3f4d2e26b3e2d9f304a7c7f3e7cfa0a8132e44fdc578403fb4a7c4fbf0f60bf8f4bdcefe10f8cc8dbc11302db10eb7bc4ce97d458fe6699WnjXwUKM+kfzgABgYcR5D3ZJaS+gDlil8Gr7dGvIso=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'a1140a3d0df1c81e24ae954d935e8926', 0, '2021-10-05', '2021-10-05 17:28:56'),
(116, 'Mark-Boswell', NULL, 'Mark', 'trayteboswell1@yahoo.com', 'Mark', '1749fed999b178b5b6df1d15b73077cdc95089d95a1cf64279dd82ffd6118c9d1deaf0e851f720f6469404efb2314ad556948d728aa18c76be8888fdd06030c5B3cyeDYD21QICUWBDvKSjpMyN3G950/jHO6O3o8joUA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'dc912a253d1e9ba40e2c597ed2376640', 0, '2021-10-05', '2021-10-05 17:39:44'),
(117, 'Catherine-Ngongoseke', NULL, 'Catherine', 'catherinengongoseke@gmail.com', 'Catherine', '30e980c5119b8a4ee0a96182422d91862b05b1b2f4cb9b6ed2355aefe1aca2c4a8b8f5bf631b0b90ec3eaddb93462f101d53707186c8acd7e153eb358192a169NtCc60ET/ICkryqth9qdyk/ttx8SqMOZJjKp/vnt8lKUKhR1zlmKVyFwgdX92kEN', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '47d1e990583c9c67424d369f3414728e', 0, '2021-10-05', '2021-10-05 19:06:33'),
(118, 'Blessing-Okolie', NULL, 'Blessing', 'tomiokolie@gmail.com', 'Blessing', '38f945f2f127bf86f33ccb7e882258cae539f027cbc792ef7059e1054aa9f9e974094cf44786ce5a0318c25f4f11ceb18926e302a8057806c248231b9829c07c7uH0OAlx+eTEp0amMEAHfiiPdppooZRoonoBDgnmeuo=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '437d7d1d97917cd627a34a6a0fb41136', 0, '2021-10-07', '2021-10-07 20:52:51'),
(119, 'George-Olu', NULL, 'George', 'george@psacpa.com', 'George', '07aaf1db37cfaa402c3cb06a08f77853092a757d3b80b361da090da4211755edafee3c8683256cda9411d5f02f4b7c942f9090eed6690989802f2929135efab03yIg1j+Naj1/X/7aNZDaQ30JsjuTWFaYYqloai/Zrw8=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '67c6a1e7ce56d3d6fa748ab6d9af3fd7', 0, '2021-10-08', '2021-10-08 10:19:13'),
(120, 'Kitan-Ayeni', NULL, 'Kitan', 'kitanayeni@hotmail.co.uk', 'Kitan', '953bbadace06731cced35668743a2285da147363cee89bebe0f3a2477ba5b27114683d07d35b788ad0e139b94c273621ec0976f4debd677d178ee6c16d6801e4cSLsHJAhnhjfpGxFDaLjSCuRvGXF/vK8cx+VWZNYWag=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c8ed21db4f678f3b13b9d5ee16489088', 0, '2021-10-10', '2021-10-10 12:35:33'),
(121, 'Jide-Oluwadeyi', NULL, 'Jide', 'jideoluwadeyi@gmail.com', 'Jide', 'c151766e0cde55e57f77141c0d4f0ad3e379d3477f63052efcc2c461c2d9a5b8925eb5cc5f6eedaa6f2fc03f29fa72de8393dc5a3eb84c794c2a41e97d2546a2aocVtqsdT8J0tjbURt4uJa01jG0rlA1Tn8IVGpiqAOM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '53fde96fcc4b4ce72d7739202324cd49', 0, '2021-10-10', '2021-10-10 13:52:27'),
(122, 'Olayinka Abiola-Lawson', NULL, 'Olayinka Abiola', 'iyunola@yahoo.com', 'Olayinka Abiola', 'b5a57bc2d84afd587fc8b3e66ced267d36aaf445ada86da7eb8fab654e73cb31d21e22296e7557910b3ab9d0893a968078168b7abb12a2d61d4f61d67067aa77kSFOyeMuNzLqqDyId8DaTo3VNIXjfa9ozebcB9jb7sA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '140f6969d5213fd0ece03148e62e461e', 0, '2021-10-10', '2021-10-10 14:40:12'),
(123, 'Olusegun Edward-Ojo', NULL, 'Olusegun Edward', 'olusegunfunmiojo1991@yahoo.co.uk', 'Olusegun Edward', 'f1c8f34d588460a2d063d74d2f0134ca866c631ccc7fe9588710e88823a91ac9b6c9e483ba119d724dd8bb33ac80e4f836a1b83495f34310a6d91c1cb32d5cadH2+tZ4F0PDo+9zHx8hSI52nPA5tAAuW1pmWvsTNZC7k=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '2dace78f80bc92e6d7493423d729448e', 0, '2021-10-10', '2021-10-10 16:19:34'),
(124, 'Janine-Van Throo', NULL, 'Janine', 'janine69@gmail.com', 'Janine', 'd1538d99133a7312d03fadc0f6b6767fab3c7a2dad5f8fc18087ab765e2713c2989b359ab46b0d38f6aa6aff743148837dc75ec7d5dd9b65d3222f64135319621z57xfECgfXG6gZqdi1YFJ96DWtXEGfv+eCtp+PXE2o=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '84f7e69969dea92a925508f7c1f9579a', 0, '2021-10-11', '2021-10-11 02:13:06'),
(125, 'Janine-Van Throo', NULL, 'Janine', 'janine69@gmail.com', 'Janine', '5dee7b11c4185ae4ae4891097c620c5b753b5e034dfaf3d7122c59feb86f542a2529faebd09450c3a24e86c8bef2ad6f8278db89db41a247c6e091ef56a25e0bfgdrHU26222KCBnlNmyVCuVMw47xjV7BrH0JXeX15oo=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'e44fea3bec53bcea3b7513ccef5857ac', 0, '2021-10-11', '2021-10-11 02:14:16'),
(126, 'Janine-Van Throo', NULL, 'Janine', 'janine69@gmail.com', 'Janine', 'd678985f0622c289f8bac0993b801367c868b2b44199b67bbd2cc25809d55a3ee989152cae336f569cac56b8906ce39f97ba7a687622dda754f78aee532c7b52OjuMF+b81l3O0ppVXeCr9lfjINnuJjHkpHBmTdpBAFM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'eb160de1de89d9058fcb0b968dbbbd68', 0, '2021-10-11', '2021-10-11 02:18:00'),
(127, 'Janine-Van Throo', NULL, 'Janine', 'janine69@gmail.com', 'Janine', '1b56e539de105feb6a0091d69d07d6a8d4286f18d0df8f281d247f37f9edb2ec74863b2e24154b3b8125db581b8dfd80b51d0214777362a44c85e8d071b87d7claxvhSedIx1ToiUXzFcgvJb99aUA6D3qJwlmub4OheM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '0f49c89d1e7298bb9930789c8ed59d48', 0, '2021-10-11', '2021-10-11 02:35:51'),
(128, 'Janine-Van Throo', NULL, 'Janine', 'janine69@gmail.com', 'Janine', 'f02942f9702098f7067871a3a731b86920e13fcccd30d059b0f3b112816b46517eb0d9e528ce62cd25307dfff1bba6669eaea25ca5f679732119718c7720c60dVPrfmLyz6hFhMXh0MmVj8edmhWKSzPBnG3rnYn/dmj4=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'ccb1d45fb76f7c5a0bf619f979c6cf36', 0, '2021-10-11', '2021-10-11 02:36:04'),
(129, 'Simon-Tiemtore', NULL, 'Simon', 'Simon@liliumcapital.com', 'Simon', 'e47e9c89655a7378909f64314cf9a390dbc6a71e25f21135bbb8798f6b5bc84a79644f0d4d1a24a4d90d7a4ff180d4511391bb5b949c04b9d8ffacc8d199eb70WsBz3D0FDnlzzuHDyFFSyeXSB2vIyiPabD5UEF5pHbA=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'fa14d4fe2f19414de3ebd9f63d5c0169', 0, '2021-10-11', '2021-10-11 08:41:54'),
(130, 'JOSEPH THIERNO -LY ', NULL, 'JOSEPH THIERNO ', 'joedmoz@gmail.com', 'JOSEPH THIERNO ', 'a5cc3df56f42ccaf50695ba99c63a3248dc43530e5158d7f04ea388d97c503dd4cb653c7bc47ca85829cb8d3767ce52b8998ec6be0ee145fbea5930fd8987dc17qA9yzZHOo6ctgZ/4AVFBdKt1scweFGRyzNa+eWZpKc=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '5a4b25aaed25c2ee1b74de72dc03c14e', 0, '2021-10-11', '2021-10-11 09:25:39'),
(131, 'Alex-Gillette', NULL, 'Alex', 'alexgillette1@gmail.com', 'Alex', '60c81e3c742089c66146b80b736e8ab9bca985cbff52b6bac25afea7fd19530d0a71c929b4a0a5b53495d77cd2764b018b6c897bbf06b7d2fd4b1ccf456dcd3602PINA2uDTLhXnfHwHPliIDt8YB2gY8V00oKhucWGII=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'c3e878e27f52e2a57ace4d9a76fd9acf', 0, '2021-10-13', '2021-10-13 12:17:40'),
(132, 'Elsie -Ezekiel ', NULL, 'Elsie ', 'elsieezy4real@gmail.com', 'Elsie ', '5df057d09193e55888faab0b6c06e89159be2840a99a81558bf8280e2aee91d7eeb03b6171accaf6599ab6673d91590e10d6ac27c4933fc3515036f50c6adf55spYtl/ZqIZHmYhSa40RuJcZlII6D+RiEFXc5mjBs/oM=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'f4552671f8909587cf485ea990207f3b', 0, '2021-10-14', '2021-10-14 10:54:36'),
(133, 'Samuel-Bedford ', NULL, 'Samuel', 'paakojo_gh@yahoo.com', 'Samuel', 'e581857ae3c0ab8bda4bf78410b30b1fc9c7ebf28508292cc3c93a7b3bc6ea6d258762842bf49a6a2fb42699c81323676a8032d15d759471aac2da62481474a0XNvf1HzNSPr8EcpLhrMJsi2759QjcMSAFxVPt4FjMEg=', 'user', 'pro', 'registered', NULL, NULL, NULL, NULL, NULL, NULL, 'style1', NULL, 'accounts/assets/front/img/avatar.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '7f5d04d189dfb634e6a85bb9d9adf21e', 0, '2021-10-14', '2021-10-14 21:20:55'),
(134, 'Nirav-Shah', NULL, 'Nirav', 'nash81@xenio.in', 'Nirav', 'ea16a66553a06d9d080f2331e2f785871fbe3b72e9c87990dc158c633a18efd0fd106618917c544fc852bc21631299f69df1d4ddc77063d6a7369a764c90a858tKKMCQ6luBQQjO2ztukSSYzl/62wOh15T0ZYIIbsKDI=', 'user', 'pro', 'registered', '', '', 0, '', '', '', 'style1', 'uploads/medium/logounit_medium-300x300.png', 'uploads/thumbnail/logounit_thumb-150x150.png', 1, 1, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, '093f65e080a295f8076b1c5722a46aa2', 0, '2021-10-16', '2021-10-16 09:49:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_role`
--

CREATE TABLE `users_role` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `country` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `is_send_invoice` varchar(255) DEFAULT NULL,
  `approve` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_role_feature`
--

CREATE TABLE `users_role_feature` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users_role_feature`
--

INSERT INTO `users_role_feature` (`id`, `name`, `slug`) VALUES
(1, 'Customers', 'customers'),
(2, 'Products', 'products'),
(3, 'Estimates', 'estimates'),
(4, 'Invoices', 'invoices'),
(5, 'Expenses', 'expenses'),
(6, 'Bills', 'bills'),
(7, 'Reports', 'reports');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_role_feature_assign`
--

CREATE TABLE `users_role_feature_assign` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `business_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `feature_slug` varchar(255) DEFAULT NULL,
  `view_only` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_kyc`
--

CREATE TABLE `user_kyc` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reference_id` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `poi_type` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `poi_number` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `poi_softcopy` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `poa_type` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `poa_number` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `poa_softcopy` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `kyc_status` varchar(25) COLLATE utf8mb4_bin NOT NULL,
  `narration` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `last_modified_by` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `last_modified_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `company_proof` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `user_kyc`
--

INSERT INTO `user_kyc` (`id`, `user_id`, `reference_id`, `poi_type`, `poi_number`, `poi_softcopy`, `photo`, `poa_type`, `poa_number`, `poa_softcopy`, `kyc_status`, `narration`, `last_modified_by`, `last_modified_on`, `company_proof`) VALUES
(7, 6, 'KYC-1628432351468', 'Driving Licence', '12312312321', 'kyc/404698_664420.png', 'kyc/404698_6644202.png', 'Driving Licence', '12312312321', 'kyc/404698_6644201.png', 'Approved', 'Your KYC has been approved.', 'nash81@gmail.com', '2021-08-24 02:23:36', NULL),
(8, 52, 'KYC-1628562591730', 'Driving Licence', 'A1488164', 'kyc/822440_659419.jpg', 'kyc/822440_6594192.jpg', 'Driving Licence', 'A1488164', 'kyc/822440_6594191.jpg', 'Approved', 'Your KYC has been approved.', 'nash81@gmail.com', '2021-08-24 02:23:36', NULL),
(9, 25, 'KYC-1628634791539', 'Passport', '1234567890', 'kyc/609312_677264.png', 'kyc/609312_6772642.png', 'Driving Licence', '9876543210', 'kyc/609312_6772641.png', 'Approved', 'Your KYC has been approved.', 'nash81@gmail.com', '2021-08-24 02:23:36', NULL),
(10, 76, 'KYC-1629513645116', 'Passport', 'A07602201', 'kyc/500164_910023.jpeg', 'kyc/500164_9100232.jpeg', 'Passport', 'A07602201', 'kyc/500164_9100231.jpeg', 'Approved', 'Your KYC has been approved.', 'nash81@gmail.com', '2021-08-24 02:23:36', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendors`
--

CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `virtual_account_customer`
--

CREATE TABLE `virtual_account_customer` (
  `id` int(11) NOT NULL,
  `email` varchar(75) COLLATE utf8mb4_bin DEFAULT NULL,
  `phoneNumber` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `lastName` varchar(75) COLLATE utf8mb4_bin DEFAULT NULL,
  `firstName` varchar(75) COLLATE utf8mb4_bin DEFAULT NULL,
  `trackingReference` varchar(75) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `message` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `response` text COLLATE utf8mb4_bin DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `last_updated_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` bigint(20) NOT NULL,
  `transaction_id` varchar(25) COLLATE utf8mb4_bin NOT NULL,
  `checkout_session_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `amount` double NOT NULL,
  `currency` varchar(5) COLLATE utf8mb4_bin NOT NULL,
  `multiplier` int(11) NOT NULL,
  `amount_subtotal` double DEFAULT NULL,
  `amount_total` double DEFAULT NULL,
  `ewallet_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `customer_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `payment_intent_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `payment_status` varchar(25) COLLATE utf8mb4_bin DEFAULT NULL,
  `url` text COLLATE utf8mb4_bin DEFAULT NULL,
  `transaction_status` enum('Initiated','Processing','Completed','Failed') COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `transaction_type` enum('Debit','Credit') COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `wallet_transactions`
--

INSERT INTO `wallet_transactions` (`id`, `transaction_id`, `checkout_session_id`, `user_id`, `created_at`, `updated_at`, `amount`, `currency`, `multiplier`, `amount_subtotal`, `amount_total`, `ewallet_id`, `customer_id`, `customer_email`, `payment_intent_id`, `payment_status`, `url`, `transaction_status`, `description`, `transaction_type`) VALUES
(64, '4511628163229654', 'cs_test_a1ywUsc4SeOGjre0rRlHZvM2G6f4Wjlrc3VQQhA49jBkWj8BWgyPthv5e2', 6, '2021-08-05 11:33:49', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_1JL4peFjgYMbRuS3ZM56xd9g', 'unpaid', 'https://checkout.stripe.com/pay/cs_test_a1ywUsc4SeOGjre0rRlHZvM2G6f4Wjlrc3VQQhA49jBkWj8BWgyPthv5e2#fidkdWxOYHwnPyd1blpxYHZxWjA0TUxBZkhDb2JcSGdXcFY2VFZiNEF8Z0lwZ08zbUdudDBBNXdqd0didXR%2FRzVgRDRKS3Q3U3IxVEBPSTdmUkt0fzR2UFVSQTVJfUhMRm03fTRBMXJMUVZNNTV%2FPGdGdWhVcicpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(65, '8131628163465322', 'cs_test_a1a04P19i8XVJ3lsF51yNq7XXV4CkPKpMNyhuQQ1Hktwm6KWya28AlZGMl', 6, '2021-08-05 11:37:45', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_1JL4tRFjgYMbRuS33riqe1G8', 'unpaid', 'https://checkout.stripe.com/pay/cs_test_a1a04P19i8XVJ3lsF51yNq7XXV4CkPKpMNyhuQQ1Hktwm6KWya28AlZGMl#fidkdWxOYHwnPyd1blpxYHZxWjA0TUxBZkhDb2JcSGdXcFY2VFZiNEF8Z0lwZ08zbUdudDBBNXdqd0didXR%2FRzVgRDRKS3Q3U3IxVEBPSTdmUkt0fzR2UFVSQTVJfUhMRm03fTRBMXJMUVZNNTV%2FPGdGdWhVcicpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(66, '2481628164378871', NULL, 6, '2021-08-05 11:52:58', NULL, 1, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(67, '4131628164471722', NULL, 6, '2021-08-05 11:54:31', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(68, '4691628164498459', NULL, 6, '2021-08-05 11:54:58', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(69, '5861628164503207', NULL, 6, '2021-08-05 11:55:03', NULL, 1, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(70, '7741628164618189', NULL, 6, '2021-08-05 11:56:58', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(71, '7621628164660334', NULL, 6, '2021-08-05 11:57:40', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(72, '9531628164688731', NULL, 6, '2021-08-05 11:58:08', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(73, '2901628164708897', NULL, 6, '2021-08-05 11:58:28', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(74, '5301628166129960', NULL, 6, '2021-08-05 12:22:09', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(75, '2551628166258956', NULL, 6, '2021-08-05 12:24:18', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(76, '3461628166484474', NULL, 6, '2021-08-05 12:28:04', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(77, '6311628166670273', NULL, 6, '2021-08-05 12:31:10', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(78, '1361628166886648', NULL, 6, '2021-08-05 12:34:46', NULL, 10, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(79, '9111628167002773', 'cs_live_a1FE4RvHjmXZ8NnmDIt7Bzb29dYaK4DjSM9f0RzBc3moPGL1eSazjgPAFA', 6, '2021-08-05 12:36:42', NULL, 10, 'USD', 100, 1000, 1000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JL5oXGQbVPqJtjT1d54Gp85', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1FE4RvHjmXZ8NnmDIt7Bzb29dYaK4DjSM9f0RzBc3moPGL1eSazjgPAFA#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(80, '3001628168149314', 'cs_live_a1fCcPpnQXFFeJzz6wJFwtQiRgYjhgQsmwvIt4eo0PtoEN6G4jj8y1f5Re', 6, '2021-08-05 12:55:49', NULL, 1, 'USD', 100, 100, 100, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JL670GQbVPqJtjT1RaK0l1u', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1fCcPpnQXFFeJzz6wJFwtQiRgYjhgQsmwvIt4eo0PtoEN6G4jj8y1f5Re#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(81, '6131628171843123', 'cs_live_a1bwhH68qzhWCXEXimWEVlX6JsISe4kt4n2ffvyjIp9vSsvRaaWp8RzuO1', 6, '2021-08-05 13:57:23', NULL, 300, 'USD', 100, 30000, 30000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JL74aGQbVPqJtjT3ABGKhXr', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1bwhH68qzhWCXEXimWEVlX6JsISe4kt4n2ffvyjIp9vSsvRaaWp8RzuO1#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(82, '9721628182307381', 'cs_live_a1x2trExpPyLDpnDLXMtGf7dpkdStU623a2i2UU83Uv2TjzIXo1uRAJrAv', 6, '2021-08-05 16:51:47', NULL, 1, 'USD', 100, 100, 100, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JL9nMGQbVPqJtjT3adtI9G4', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1x2trExpPyLDpnDLXMtGf7dpkdStU623a2i2UU83Uv2TjzIXo1uRAJrAv#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(83, '7211628287251812', 'cs_live_a1dqE8REN1RXw5vEwPZOTt1YRCMSAEJWNOS7HgLzQaS6AKdQbkENeE8tKL', 38, '2021-08-06 22:00:51', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', 'pi_3JLb5zGQbVPqJtjT2EvdIMMz', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1dqE8REN1RXw5vEwPZOTt1YRCMSAEJWNOS7HgLzQaS6AKdQbkENeE8tKL#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(84, '4311628292754724', 'cs_live_a1uVnA1fAIHgXoqlBVJtkDC933TdZdMx0MWUjvt32B3MhaYT6Ownt5h5xL', 25, '2021-08-06 23:32:34', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', 'pi_3JLcWlGQbVPqJtjT2RBnve5a', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1uVnA1fAIHgXoqlBVJtkDC933TdZdMx0MWUjvt32B3MhaYT6Ownt5h5xL#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(85, '3271628292832792', 'cs_live_a1Rw54fn4wHdShJn14AT9V9eBqaxZNSGSiUCEoinxVRh95c3YNtNsbjycd', 25, '2021-08-06 23:33:52', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', 'pi_3JLcY0GQbVPqJtjT27X8UxBC', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1Rw54fn4wHdShJn14AT9V9eBqaxZNSGSiUCEoinxVRh95c3YNtNsbjycd#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(86, '3431628298292241', 'cs_live_a1fbd85flundQnsRif68xaJhDIj62gPa8P5ZSk73u3q2MIdgqOvoI7Y4ci', 38, '2021-08-07 01:04:52', '2021-08-07 01:07:12', 20, 'USD', 100, 2000, 2000, 'GEEFTO784151', 'cus_JzdGxiDjGMCPT9', 'techforhumanity@gmail.com', 'pi_3JLdy5GQbVPqJtjT1ywxixoM', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(87, 'fees_1628298432187', NULL, 38, '2021-08-07 01:07:12', NULL, -0.94, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 3431628298292241', 'Debit'),
(88, '7951628313071252', 'cs_live_a1dik7ZxqyQoIoNeQ86FlaKf38CJy2xwvZLn1c0FhpOsIKAL9BXa88A0jY', 6, '2021-08-07 05:11:11', NULL, 10, 'USD', 100, 1000, 1000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JLhoSGQbVPqJtjT35wIfJPI', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1dik7ZxqyQoIoNeQ86FlaKf38CJy2xwvZLn1c0FhpOsIKAL9BXa88A0jY#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(89, '5371628313236116', 'cs_live_a1vkaAWo4UcCz6FbjJ5TMWrtBLwO1BB2DWtOaw58SfMTY4wlbMesofjctA', 6, '2021-08-07 05:13:56', '2021-08-07 05:16:35', 5, 'USD', 100, 500, 500, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'cus_JzhIJunvxTjEwK', 'nash81@gmail.com', 'pi_3JLhr7GQbVPqJtjT2GOlNCjG', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(90, 'fees_1628313395543', NULL, 6, '2021-08-07 05:16:35', NULL, 0, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 5371628313236116', 'Debit'),
(91, '2511628315573612', 'cs_live_a19cQbIGlztciPivCg9QMMrq78Xwm6s71Xv1lrNFJuAkUyzMe1CXWGEnau', 6, '2021-08-07 05:52:53', NULL, 100, 'USD', 100, 10000, 10000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_3JLiSoGQbVPqJtjT1bvQebPs', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a19cQbIGlztciPivCg9QMMrq78Xwm6s71Xv1lrNFJuAkUyzMe1CXWGEnau#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(92, '9521628315616104', 'cs_live_a1oUsw02KfpIkuDDfcVmUoDkRlEDMeKVoOyuNuoL3b5Yhz4d7LfYKxLUwD', 6, '2021-08-07 05:53:36', '2021-08-07 05:54:21', 5, 'USD', 100, 500, 500, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'cus_Jzht3YSn2WBiVL', 'nash81@gmail.com', 'pi_3JLiTVGQbVPqJtjT1LSonrq6', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(93, 'fees_1628315661156', NULL, 6, '2021-08-07 05:54:21', NULL, -0.18, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 9521628315616104', 'Debit'),
(96, '1727605743943710', '1727605743943710', 6, '2021-08-08 03:14:44', '2021-08-08 03:14:44', -2, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', '6', NULL, '1727605743943710', 'paid', NULL, 'Completed', NULL, 'Debit'),
(97, '1362758005229615', '1362758005229615', 6, '2021-08-08 03:15:59', '2021-08-08 03:15:59', -2, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', '6', NULL, '1362758005229615', 'paid', NULL, 'Completed', NULL, 'Debit'),
(98, '2173997282162781', '2173997282162781', 6, '2021-08-08 03:23:21', '2021-08-08 03:23:21', -1, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', '6', NULL, '2173997282162781', 'paid', NULL, 'Completed', 'For Virtual Vard Issuance', 'Debit'),
(99, '6531628448813584', 'cs_live_a1XvISsnqgZTdl7SAicpaE59oyAAFZWpAKflXXyzJqXlmmR2EtwFabCnHU', 44, '2021-08-08 18:53:33', NULL, 100, 'USD', 100, 10000, 10000, 'GEEFTO300690', NULL, 'dul_boi@icloud.com', 'pi_3JMH7qGQbVPqJtjT3vkpRdIj', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1XvISsnqgZTdl7SAicpaE59oyAAFZWpAKflXXyzJqXlmmR2EtwFabCnHU#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(100, '8231628448967469', 'cs_live_a1Ghs09BD3xPlAjg0Y1isIVsC8tq1ZuZZxqZSRb4pl8h9RuhDudNE2RbZk', 44, '2021-08-08 18:56:07', '2021-08-08 18:57:07', 5, 'USD', 100, 500, 500, 'GEEFTO300690', 'cus_K0HkYpvVkVBw98', 'dul_boi@icloud.com', 'pi_3JMHAKGQbVPqJtjT0g8Ymr2K', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(101, 'fees_1628449027937', NULL, 44, '2021-08-08 18:57:07', NULL, -0.18, 'USD', 100, NULL, NULL, 'GEEFTO300690', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 8231628448967469', 'Debit'),
(102, '4521628552290885', 'cs_live_a1lU2wxbC1UMlo1cgqXfB6qZcwNoM9Qgfgxra07quJQgH4eOcJFPSZrtTG', 46, '2021-08-09 23:38:10', NULL, 10, 'USD', 100, 1000, 1000, 'GEEFTO391042', NULL, 'jboscoamad@gmail.com', 'pi_3JMi2qGQbVPqJtjT1GBrtP2E', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1lU2wxbC1UMlo1cgqXfB6qZcwNoM9Qgfgxra07quJQgH4eOcJFPSZrtTG#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(103, '3901628611377160', 'cs_live_a1mlKLSHnMf3gkNqY92dja6yb5kS1ok1LddouRSGdW9Jv51DLXeFDhXWWI', 56, '2021-08-10 16:02:57', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO306438', NULL, 'kogungbile@gmail.com', 'pi_3JMxPqGQbVPqJtjT0Nv4bU1I', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1mlKLSHnMf3gkNqY92dja6yb5kS1ok1LddouRSGdW9Jv51DLXeFDhXWWI#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(104, '2061628646323100', NULL, 38, '2021-08-11 01:45:23', NULL, 10, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(105, '4241628784335980', 'cs_live_a13v7lRepTGhHXhkFJXzl5nEuaD1dAY3PhinHASGAJbvV4Vve3mE4tmuQp', 62, '2021-08-12 16:05:35', NULL, 10, 'USD', 100, 1000, 1000, 'GEEFTO618489', NULL, 'enochibk@gmail.com', 'pi_3JNgPTGQbVPqJtjT1s7EJivW', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a13v7lRepTGhHXhkFJXzl5nEuaD1dAY3PhinHASGAJbvV4Vve3mE4tmuQp#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(106, '2221628964505573', 'cs_live_a1pcGE5Ypml07q1QU3KidAhddNxT7AyMTC0awSX1bplHSZbBt3WNCZ4BUD', 38, '2021-08-14 18:08:25', NULL, 100, 'USD', 100, 10000, 10000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', 'pi_3JORHSGQbVPqJtjT3QXwhB6K', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1pcGE5Ypml07q1QU3KidAhddNxT7AyMTC0awSX1bplHSZbBt3WNCZ4BUD#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(107, '6441629164113966', 'cs_live_a1T1eaJIAvdtIbPFm2uCvwm88IHmbN1DblsaSo528cQ0VN4RqzeSAIVm43', 71, '2021-08-17 01:35:13', NULL, 500, 'USD', 100, 50000, 50000, 'GEEFTO765490', NULL, 'johnlombela@hotmail.com', 'pi_3JPHCvGQbVPqJtjT0Bv5CoOr', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1T1eaJIAvdtIbPFm2uCvwm88IHmbN1DblsaSo528cQ0VN4RqzeSAIVm43#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(108, '3481629311109375', 'cs_live_a10UcfYCBj4rVHvU7UBCIpROiRpzZwKiLMWaSQ0oMVceCvg8oVmYdN2rMr', 74, '2021-08-18 18:25:09', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO691034', NULL, 'peter@peterojo.com', 'pi_3JPtRqGQbVPqJtjT1CGHI4zP', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a10UcfYCBj4rVHvU7UBCIpROiRpzZwKiLMWaSQ0oMVceCvg8oVmYdN2rMr#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(109, '8591629311133531', 'cs_live_a18OVV4FPNOOuUYN5U3kYNCtbecyhT7WNK13PvkHnpriwA7AxTRzQMZQ6S', 74, '2021-08-18 18:25:33', '2021-08-18 18:26:14', 10, 'USD', 100, 1000, 1000, 'GEEFTO691034', 'cus_K41VxEjENkp9Rm', 'peter@peterojo.com', 'pi_3JPtSEGQbVPqJtjT1khhx52X', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(110, 'fees_1629311174262', NULL, 74, '2021-08-18 18:26:14', NULL, -0.36, 'USD', 100, NULL, NULL, 'GEEFTO691034', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 8591629311133531', 'Debit'),
(111, '5031629311338633', 'cs_live_a1npkSViMwCIONgjaSjou3xgd6c2ZDIqgAEsjlrfY0ABvtrQ1rnVmYc05n', 44, '2021-08-18 18:28:58', '2021-08-18 18:30:29', 10, 'USD', 100, 1000, 1000, 'GEEFTO300690', 'cus_K41akVBMBVBlyL', 'dul_boi@icloud.com', 'pi_3JPtVXGQbVPqJtjT3RtDUlxR', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(112, 'fees_1629311429357', NULL, 44, '2021-08-18 18:30:29', NULL, -0.36, 'USD', 100, NULL, NULL, 'GEEFTO300690', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 5031629311338633', 'Debit'),
(113, '3971629319656568', 'cs_live_a15EoU8Gt8yBMFtGAWT6iyi8KTu4f1pPNqUnhmFwPZxcD6BzdYUiuR1atq', 44, '2021-08-18 20:47:36', NULL, 10, 'USD', 100, 1000, 1000, 'GEEFTO300690', NULL, 'dul_boi@icloud.com', 'pi_3JPvfgGQbVPqJtjT2TYqTnSF', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a15EoU8Gt8yBMFtGAWT6iyi8KTu4f1pPNqUnhmFwPZxcD6BzdYUiuR1atq#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(117, '7111629404327636', '7281629404327482', 6, '2021-08-19 20:18:47', '2021-08-19 20:18:47', -1, 'USD', 100, 100, 100, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', '118', 'debited', '', 'Completed', 'Wallet Transfer to OMNI477998', 'Debit'),
(118, '7281629404327482', NULL, 37, '2021-08-19 20:18:47', '2021-08-19 20:18:47', 1, 'USD', 100, 100, 100, 'OMNI477998', NULL, 'mdarbaz2290@mailinator.com', '117', 'credited', '', 'Completed', 'Wallet Transfer from ewallet_b43aed61d43f74d82b022422cfa26e22', 'Credit'),
(119, '2481629448944390', 'bal_d29a216eae8c78e8', 38, '2021-08-20 08:42:24', '2021-08-20 08:42:25', -10, 'USD', 100, 1000, 1000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, 'Card funded', '', 'Completed', 'Funds Loaded to geefto card', 'Credit'),
(120, '1471629449605792', 'cs_live_a1mD4dYTIPPof1sU9b2iERLKbJxbBobb41KyoAsaYqS9uAYjJAzqqKsXcr', 38, '2021-08-20 08:53:25', '2021-08-20 08:58:45', 50, 'USD', 100, 5000, 5000, 'GEEFTO784151', 'cus_K4cmwQlBtOYtG9', 'techforhumanity@gmail.com', 'pi_3JQTTdGQbVPqJtjT1iMB6cdq', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(121, 'fees_1629449925752', NULL, 38, '2021-08-20 08:58:45', NULL, -1.8, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 1471629449605792', 'Debit'),
(122, '2741629450096804', 'bal_d29a216eae8c78e8', 38, '2021-08-20 09:01:36', '2021-08-20 09:01:37', -20, 'USD', 100, 2000, 2000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, 'Card funded', '', 'Completed', 'Funds Loaded to geefto card', 'Credit'),
(123, '6821629454269321', '4071629454269781', 38, '2021-08-20 10:11:09', '2021-08-20 10:11:09', -10, 'USD', 100, 1000, 1000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', '124', 'debited', '', 'Completed', 'Wallet Transfer to GEEFTO691034', 'Debit'),
(124, '4071629454269781', NULL, 74, '2021-08-20 10:11:09', '2021-08-20 10:11:09', 10, 'USD', 100, 1000, 1000, 'GEEFTO691034', NULL, 'peter@peterojo.com', '123', 'credited', '', 'Completed', 'Wallet Transfer from GEEFTO784151', 'Credit'),
(125, '7181629471433983', 'cs_live_a1pJXzT5RIph8ebs8vD65rTxsN3qobyHEFXMVG0NyFFgE29SDsHYnBtYzh', 76, '2021-08-20 14:57:13', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', 'pi_3JQZ9hGQbVPqJtjT01Rc0PX7', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1pJXzT5RIph8ebs8vD65rTxsN3qobyHEFXMVG0NyFFgE29SDsHYnBtYzh#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(126, '4311629472515333', NULL, 38, '2021-08-20 15:15:15', NULL, -10, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, 'Processing', 'Airtime Topup for 4311629472515333', 'Debit'),
(127, '3241629473159393', NULL, 38, '2021-08-20 15:25:59', NULL, -10, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, 'Processing', 'Airtime Topup for 3241629473159393', 'Debit'),
(128, '3631629473306182', NULL, 38, '2021-08-20 15:28:26', NULL, -5, 'USD', 100, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, 'Processing', 'Airtime Topup for 3631629473306182', 'Debit'),
(129, '9251629473357722', '3414338', 38, '2021-08-20 15:29:17', '2021-08-20 15:29:19', -5, 'USD', 100, 500, 500, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', '2021082016312842007945732', 'recharged', '', 'Completed', 'Airtime Topup for 9251629473357722', 'Debit'),
(130, '4871629473461722', '3414357', 38, '2021-08-20 15:31:01', '2021-08-20 15:31:03', -5, 'USD', 100, 500, 500, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', '2021082016311456402802992', 'recharged', '', 'Completed', 'Airtime Topup for 4871629473461722', 'Debit'),
(131, '9901629512473320', 'cs_live_a1Y2tz7vWDAwz02U603jV4YaALeNBkTFHpt6gupDHXB8AYHAiu0ghGDNuD', 76, '2021-08-21 02:21:13', '2021-08-21 02:22:33', 5, 'USD', 100, 500, 500, 'GEEFTO696878', 'cus_K4te6Sygt5AwSk', 'abdulsuleymann1234@icloud.com', 'pi_3JQjpeGQbVPqJtjT2QF77MYf', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(132, 'fees_1629512553131', NULL, 76, '2021-08-21 02:22:33', NULL, -0.18, 'USD', 100, NULL, NULL, 'GEEFTO696878', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 9901629512473320', 'Debit'),
(133, '8211629515682635', 'cs_live_a1k1dCuuTpNRnbxXv8nDZY1jzfVLustYHASwEIhIYP2kXPG9iJDTRLBNIc', 78, '2021-08-21 03:14:42', NULL, 20, 'USD', 100, 2000, 2000, 'GEEFTO256530', NULL, 'aothmanladan@gmail.com', 'pi_3JQkfOGQbVPqJtjT1aKgZocN', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1k1dCuuTpNRnbxXv8nDZY1jzfVLustYHASwEIhIYP2kXPG9iJDTRLBNIc#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(134, '8621629515699391', 'cs_live_a1bvt8foUEUtJ8B1iKVz291bhwvtqef7wbopj1bUPs4YpuPUkWKbBcZq5Q', 78, '2021-08-21 03:14:59', NULL, 20, 'USD', 100, 2000, 2000, 'GEEFTO256530', NULL, 'aothmanladan@gmail.com', 'pi_3JQkfgGQbVPqJtjT2fI3w7Ne', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1bvt8foUEUtJ8B1iKVz291bhwvtqef7wbopj1bUPs4YpuPUkWKbBcZq5Q#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(135, '4391629660430666', NULL, 6, '2021-08-22 19:27:10', NULL, 500, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(136, '1781629660525894', 'cs_test_a1Rdu3Hj9uznHml7q9AyOOvUzYLisPZZ1foaygGgP6KwAcryItf2nDb6Xk', 6, '2021-08-22 19:28:45', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_1JRMLbFjgYMbRuS3o5d3CJ7A', 'unpaid', 'https://checkout.stripe.com/pay/cs_test_a1Rdu3Hj9uznHml7q9AyOOvUzYLisPZZ1foaygGgP6KwAcryItf2nDb6Xk#fidkdWxOYHwnPyd1blpxYHZxWjA0TUxBZkhDb2JcSGdXcFY2VFZiNEF8Z0lwZ08zbUdudDBBNXdqd0didXR%2FRzVgRDRKS3Q3U3IxVEBPSTdmUkt0fzR2UFVSQTVJfUhMRm03fTRBMXJMUVZNNTV%2FPGdGdWhVcicpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(137, '3841629661455426', 'cs_test_a1qhKQu3WAd2INjNmhXoTCfUhOMOiCSVKlqPQz30YIggUOu78IA5RdckCf', 6, '2021-08-22 19:44:15', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_1JRMaaFjgYMbRuS3l52XteZl', 'unpaid', 'https://checkout.stripe.com/pay/cs_test_a1qhKQu3WAd2INjNmhXoTCfUhOMOiCSVKlqPQz30YIggUOu78IA5RdckCf#fidkdWxOYHwnPyd1blpxYHZxWjA0TUxBZkhDb2JcSGdXcFY2VFZiNEF8Z0lwZ08zbUdudDBBNXdqd0didXR%2FRzVgRDRKS3Q3U3IxVEBPSTdmUkt0fzR2UFVSQTVJfUhMRm03fTRBMXJMUVZNNTV%2FPGdGdWhVcicpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(138, '5121629661739369', 'cs_test_a1iMGiJ0fEFbaMWxTrHimIvOGOAzPnJQ9s63lxB1f2dFMc9ZwI6RKo1PtQ', 6, '2021-08-22 19:48:59', NULL, 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', 'pi_1JRMfBFjgYMbRuS3EqYHSrtd', 'unpaid', 'https://checkout.stripe.com/pay/cs_test_a1iMGiJ0fEFbaMWxTrHimIvOGOAzPnJQ9s63lxB1f2dFMc9ZwI6RKo1PtQ#fidkdWxOYHwnPyd1blpxYHZxWjA0TUxBZkhDb2JcSGdXcFY2VFZiNEF8Z0lwZ08zbUdudDBBNXdqd0didXR%2FRzVgRDRKS3Q3U3IxVEBPSTdmUkt0fzR2UFVSQTVJfUhMRm03fTRBMXJMUVZNNTV%2FPGdGdWhVcicpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(139, '9671629661931293', 'cs_test_a1ktpqQPZcVK3YMgPP0lQYavJYgHLjU53jbV79PvsYSH0lS0cAwHxmj6Mx', 6, '2021-08-22 19:52:11', '2021-08-22 19:52:56', 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'cus_K5XoX6qLG7uded', 'nash81@gmail.com', 'pi_1JRMiHFjgYMbRuS3nP8zROQ4', 'paid', NULL, 'Completed', ' mdaltaf.tech@gmail.com', 'Credit'),
(140, '6911629662133365', 'cs_test_a1ONiY0vgXdhwCnFitkGHDv7JW06vuW3FBX0iZD5x4Fha8j6GpYpXttQCI', 6, '2021-08-22 19:55:33', '2021-08-22 19:56:18', 500, 'USD', 100, 50000, 50000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'cus_K5XrUgRnykbozY', 'nash81@gmail.com', 'pi_1JRMlWFjgYMbRuS3Qka5XvDL', 'paid', NULL, 'Completed', ' mdaltaf.tech@gmail.com', 'Credit'),
(141, 'fees_1629662178487', NULL, 6, '2021-08-22 19:56:18', NULL, -23, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, NULL, NULL, 'paid', NULL, 'Completed', 'Transaction Charges for 6911629662133365', 'Debit'),
(142, '2051629768444867', 'cs_test_a15Rcvq4fqddeCW9ITAWqMyzgFNoQkMChegir9EoFOkGfGOLkzY6b0wnPK', 6, '2021-08-24 01:27:24', '2021-08-24 01:28:42', 6000, 'USD', 100, 600000, 600000, 'ewallet_b43aed61d43f74d82b022422cfa26e22', 'cus_K60SK2T1Vph2uV', 'nash81@gmail.com', 'pi_1JRoQCFjgYMbRuS3jIxXNkFi', 'paid', NULL, 'Completed', ' nirav@xenio.in', 'Credit'),
(143, 'fees_1629768522120', NULL, 6, '2021-08-24 01:28:42', NULL, -282, 'USD', 100, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, NULL, NULL, 'paid', NULL, 'Completed', 'Transaction Charges for 2051629768444867', 'Debit'),
(144, '1141629850545530', 'cs_live_a1eSrKL6UbtfarcwaDTqE5Ky45lfLMTtkYwxvFPd10xDleWhtLCthkomPO', 89, '2021-08-25 00:15:45', '2021-08-25 00:18:28', 50, 'USD', 100, 5000, 5000, 'GEEFTO657088', 'cus_K6MYnbpfHDayBZ', 'olareal@gmail.com', 'pi_3JS9mQGQbVPqJtjT2HqvLsWK', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(145, 'fees_1629850708543', NULL, 89, '2021-08-25 00:18:28', NULL, -1.8, 'USD', 100, NULL, NULL, 'GEEFTO657088', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 1141629850545530', 'Debit'),
(146, '6331629851250473', '3455675', 89, '2021-08-25 00:27:30', '2021-08-25 00:27:32', -5, 'USD', 100, 500, 500, 'GEEFTO657088', NULL, 'olareal@gmail.com', '2021082501270828401948789', 'recharged', '', 'Completed', 'Airtime Topup for 6331629851250473', 'Debit'),
(147, '8171629974325419', 'cs_live_a10hCa8g172XQfECHEzPVeee2vGBxlIe8X2K9oWHram3suVDxMSOs9gDUX', 90, '2021-08-26 10:38:45', '2021-08-26 10:39:56', 1, 'USD', 100, 100, 100, 'GEEFTO846824', 'cus_K6tnuggHqhJNwy', 'chukwunonsoarinze93@gmail.com', 'pi_3JSfysGQbVPqJtjT1eTn2jw2', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(148, 'fees_1629974396106', NULL, 90, '2021-08-26 10:39:56', NULL, -0.04, 'USD', 100, NULL, NULL, 'GEEFTO846824', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 8171629974325419', 'Debit'),
(149, '8591630156827674', 'cs_live_a1UufT4qyTmeTfNr9aJWNyMK2EN00ei2tgYLt0Chjwdb4f08J0tiq0jfrT', 101, '2021-08-28 13:20:27', NULL, 125, 'USD', 100, 12500, 12500, 'GEEFTO859052', NULL, 'sakinlolu@gmail.com', 'pi_3JTRSSGQbVPqJtjT3ItDRL9D', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1UufT4qyTmeTfNr9aJWNyMK2EN00ei2tgYLt0Chjwdb4f08J0tiq0jfrT#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(150, '4641630199879386', '3495853', 76, '2021-08-29 01:17:59', '2021-08-29 01:18:02', -1, 'USD', 100, 100, 100, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', 'R210829.0218.220002', 'recharged', '', 'Completed', 'Airtime Topup for 4641630199879386', 'Debit'),
(151, '9361630291802247', 'cs_live_a1mtSYewKWJFeS51qCwhKCpOwkDFpZSvLV9JBlcrzScLEphVqzlUizidhA', 105, '2021-08-30 02:50:02', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO615150', NULL, 'ayotundeowo@gmail.com', 'pi_3JU0ZSGQbVPqJtjT2HhxL3Kc', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1mtSYewKWJFeS51qCwhKCpOwkDFpZSvLV9JBlcrzScLEphVqzlUizidhA#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(152, '4961630862586926', 'cs_live_a13kJMVbkKWhqQUX3XWFNFvQSPBxTrcdKjv7eJ50roq2Z8dxM759pvlnKl', 117, '2021-09-05 17:23:06', NULL, 200, 'USD', 100, 20000, 20000, 'GEEFTO186925', NULL, 'cashoutdre59@gmail.com', 'pi_3JWP3eGQbVPqJtjT1ureGeFH', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a13kJMVbkKWhqQUX3XWFNFvQSPBxTrcdKjv7eJ50roq2Z8dxM759pvlnKl#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(153, '3221630937023563', 'cs_live_a1SndaJCL8Vep5J5LcM7swV1wiqTIlXnGOF5rsGe4AnjEyJII9KovkdKVw', 38, '2021-09-06 14:03:43', NULL, 50, 'USD', 100, 5000, 5000, 'ewallet_3f12273e31fcaf27e8021e4f79191273', NULL, 'techforhumanity@gmail.com', 'pi_3JWiQGGQbVPqJtjT0H1JCgrw', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1SndaJCL8Vep5J5LcM7swV1wiqTIlXnGOF5rsGe4AnjEyJII9KovkdKVw#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(154, '3871630937458415', 'cs_live_a1vaufD6DQXoEmHUYAwlEoqVmMruJsc7FCTIXYd2IXF0H77DwF9MxSuo2X', 38, '2021-09-06 14:10:58', '2021-09-06 14:17:32', 50, 'USD', 100, 5000, 5000, 'ewallet_3f12273e31fcaf27e8021e4f79191273', 'cus_KB4nDESFYNMcLL', 'techforhumanity@gmail.com', 'pi_3JWiXGGQbVPqJtjT1obeAyMw', 'paid', NULL, 'Completed', 'Wallet Topup', 'Credit'),
(155, 'fees_1630937852755', NULL, 38, '2021-09-06 14:17:32', NULL, -1.8, 'USD', 100, NULL, NULL, 'ewallet_3f12273e31fcaf27e8021e4f79191273', NULL, NULL, NULL, NULL, NULL, 'Completed', 'Transaction Charges for 3871630937458415', 'Debit'),
(156, '7281630954470792', 'cs_live_a1n91dASFUACelpmFip3jViSEvhpSNRRpYIf4w8L8aMyqfDqJLE2NBgE6W', 119, '2021-09-06 18:54:30', NULL, 200, 'USD', 100, 20000, 20000, 'GEEFTO452180', NULL, 'fhgolnett@gmail.com', 'pi_3JWmxeGQbVPqJtjT1Jt798BD', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1n91dASFUACelpmFip3jViSEvhpSNRRpYIf4w8L8aMyqfDqJLE2NBgE6W#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(157, '3761630954688922', 'cs_live_a1aHK7nX8hvyExzheF2Do84t1YZEuLBcfITVmqb23LTnR1wiLCBgcaXgJw', 119, '2021-09-06 18:58:08', NULL, 200, 'USD', 100, 20000, 20000, 'GEEFTO452180', NULL, 'fhgolnett@gmail.com', 'pi_3JWn1AGQbVPqJtjT1jGjQLzF', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1aHK7nX8hvyExzheF2Do84t1YZEuLBcfITVmqb23LTnR1wiLCBgcaXgJw#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(158, '8651631584247236', 'cs_live_a1lbISuxgsUyxcVrth3ABHigShjVTzxIddgw4XqyBCJORhl2b8RZj7Q7ES', 38, '2021-09-14 01:50:47', NULL, 50, 'USD', 100, 5000, 5000, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', 'pi_3JZQnMGQbVPqJtjT2GvsK1wc', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1lbISuxgsUyxcVrth3ABHigShjVTzxIddgw4XqyBCJORhl2b8RZj7Q7ES#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(159, '4861631621901644', 'PAYID-MFAJGDQ4GY976852S8981156', 25, '2021-09-14 12:18:21', '2021-09-14 16:18:21', 200, 'USD', 1, 200, 200, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFAJGDQ4GY976852S8981156/execute', 'Processing', NULL, 'Credit'),
(160, '6181631622052650', 'PAYID-MFAJHJI0D009015PP867912R', 25, '2021-09-14 12:20:52', '2021-09-14 12:21:07', 1000, 'USD', 1, 1000, 1000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'DYQ8GUTYSCKZC', 'business2@xenio.in', NULL, 'approved', 'https://api.sandbox.paypal.com/v1/payments/sale/5ME30256RA131782B/refund', 'Completed', 'Wallet Funds Added', 'Credit'),
(161, 'fees_1631622067295', NULL, 25, '2021-09-14 12:21:07', '2021-09-14 12:21:07', -36, 'USD', 1, -36, -36, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, 'Completed', 'Transaction Charges for 6181631622052650', 'Debit'),
(162, '7871631622143935', 'bal_18cbce4ec9ee768b', 25, '2021-09-14 12:22:23', '2021-09-14 12:22:24', -64, 'USD', 100, 6400, 6400, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'Card funded', '', 'Completed', 'Funds Loaded to geefto card', 'Credit'),
(163, '4391631626255683', NULL, 25, '2021-09-14 13:30:55', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(164, '7011631627053618', NULL, 25, '2021-09-14 13:44:13', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(165, '8691631627678432', NULL, 25, '2021-09-14 13:54:38', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(166, '5441631627746888', NULL, 25, '2021-09-14 13:55:46', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(167, '2311631627952117', NULL, 25, '2021-09-14 13:59:12', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(168, '6721631627975683', NULL, 25, '2021-09-14 13:59:35', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(169, '6181631628066754', NULL, 25, '2021-09-14 14:01:06', NULL, 1000, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(170, '3461631629880888', 'PAYID-MFALEOI4SR8716703731024G', 25, '2021-09-14 14:31:20', '2021-09-14 14:31:39', 1000, 'USD', 1, 1000, 1000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'DYQ8GUTYSCKZC', 'business2@xenio.in', NULL, 'approved', 'https://api.sandbox.paypal.com/v1/payments/sale/1J1167590J1540710/refund', 'Completed', 'Wallet Funds Added', 'Credit'),
(171, 'fees_1631629899428', NULL, 25, '2021-09-14 14:31:39', '2021-09-14 14:31:39', -36, 'USD', 1, -36, -36, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, 'Completed', 'Transaction Charges for 3461631629880888', 'Debit'),
(172, '4381631636256501', NULL, 38, '2021-09-14 16:17:36', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(173, '2381631636275203', NULL, 38, '2021-09-14 16:17:55', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(174, '5761631636337645', NULL, 38, '2021-09-14 16:18:57', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(175, '7101631636376355', NULL, 38, '2021-09-14 16:19:36', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(176, '3491631636514976', NULL, 25, '2021-09-14 16:21:54', NULL, 200, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(177, '4001631636539901', NULL, 38, '2021-09-14 16:22:19', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(178, '1491631636630681', NULL, 38, '2021-09-14 16:23:50', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(179, '4491631636637827', NULL, 25, '2021-09-14 16:23:57', NULL, 200, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(180, '9681631636682467', NULL, 38, '2021-09-14 16:24:42', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(181, '8861631636718846', NULL, 38, '2021-09-14 16:25:18', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(182, '5791631636726868', NULL, 38, '2021-09-14 16:25:26', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(183, '1161631636778714', NULL, 38, '2021-09-14 16:26:18', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(184, '3431631636845935', NULL, 38, '2021-09-14 16:27:25', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(185, '9171631636864214', NULL, 38, '2021-09-14 16:27:44', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(186, '4291631636919438', NULL, 38, '2021-09-14 16:28:39', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(187, '8881631637124527', NULL, 38, '2021-09-14 16:32:04', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(188, '5051631637295854', NULL, 25, '2021-09-14 16:34:55', NULL, 200, 'USD', 1, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(189, '2891631637309252', NULL, 38, '2021-09-14 16:35:09', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(190, '1691631637313953', NULL, 38, '2021-09-14 16:35:13', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(191, '7181631637316543', NULL, 38, '2021-09-14 16:35:16', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(192, '6181631637321107', NULL, 38, '2021-09-14 16:35:21', NULL, 20, 'USD', 1, NULL, NULL, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(193, '1611631637334612', 'PAYID-MFAM6VY3VN88542P8256102S', 25, '2021-09-14 16:35:34', '2021-09-14 20:35:35', 200, 'USD', 1, 200, 200, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFAM6VY3VN88542P8256102S/execute', 'Processing', NULL, 'Credit'),
(194, '6591631637340272', 'PAYID-MFAM6XI1GA95265JP158842F', 38, '2021-09-14 16:35:40', '2021-09-14 20:35:41', 10, 'USD', 1, 10, 10, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFAM6XI1GA95265JP158842F/execute', 'Processing', NULL, 'Credit'),
(195, '5421631637391479', 'PAYID-MFAM7EA5JN157952T268690S', 38, '2021-09-14 16:36:31', '2021-09-14 20:36:32', 50, 'USD', 1, 50, 50, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFAM7EA5JN157952T268690S/execute', 'Processing', NULL, 'Credit'),
(196, '7741631637491450', 'PAYID-MFAM75A6M907987ND4962054', 38, '2021-09-14 16:38:11', '2021-09-14 20:38:12', 10, 'USD', 1, 10, 10, 'GEEFTO784151', NULL, 'techforhumanity@gmail.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFAM75A6M907987ND4962054/execute', 'Processing', NULL, 'Credit'),
(197, '2711631722002186', 'PAYID-MFBBUEY51G45592B0394513U', 126, '2021-09-15 16:06:42', '2021-09-15 20:06:43', 66, 'USD', 1, 66, 66, 'GEEFTO766244', NULL, 'msgroupllc@outlook.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFBBUEY51G45592B0394513U/execute', 'Processing', NULL, 'Credit'),
(198, '6711631746802591', 'PAYID-MFBHV4Y968038944E966953D', 76, '2021-09-15 23:00:02', '2021-09-16 03:00:02', 1, 'USD', 1, 1, 1, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFBHV4Y968038944E966953D/execute', 'Processing', NULL, 'Credit'),
(199, '5161631747490135', '3709532', 76, '2021-09-15 23:11:30', '2021-09-15 23:11:32', -1, 'USD', 100, 100, 100, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', 'R210916.0011.23004f', 'recharged', '', 'Completed', 'Airtime Topup for 5161631747490135', 'Debit'),
(200, '2661631747627437', 'PAYID-MFBH4LA77G50954NP826505V', 76, '2021-09-15 23:13:47', '2021-09-16 03:13:48', 10, 'USD', 1, 10, 10, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFBH4LA77G50954NP826505V/execute', 'Processing', NULL, 'Credit'),
(201, '5091631827296508', '3720421', 76, '2021-09-16 21:21:36', '2021-09-16 21:21:37', -1, 'USD', 100, 100, 100, 'GEEFTO696878', NULL, 'abdulsuleymann1234@icloud.com', '2021091622213731402720719', 'recharged', '', 'Completed', 'Airtime Topup for 5091631827296508', 'Debit'),
(202, '3791631983297338', 'PAYID-MFDBNQQ47D730168C804441K', 128, '2021-09-18 16:41:37', '2021-09-18 20:41:38', 10, 'USD', 1, 10, 10, 'GEEFTO961750', NULL, 'abubah74@gmail.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFDBNQQ47D730168C804441K/execute', 'Processing', NULL, 'Credit'),
(203, '1471632061019615', 'PAYID-MFDUMXA48M08534CU715261P', 129, '2021-09-19 14:16:59', '2021-09-19 18:16:59', 50000, 'USD', 1, 50000, 50000, 'GEEFTO769772', NULL, 'usojoolusegunfunmiojo195666@gmail.com', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFDUMXA48M08534CU715261P/execute', 'Processing', NULL, 'Credit'),
(204, '8341632164277783', 'cs_live_a1TzkRWsP9P2FHJsGJYQr4zOTpTlrN4LHmJci7Uu832DMDRXTBhxUWUeit', 25, '2021-09-20 18:57:57', NULL, 50, 'USD', 100, 5000, 5000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', 'pi_3JbrgfGQbVPqJtjT3lFYQyO6', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1TzkRWsP9P2FHJsGJYQr4zOTpTlrN4LHmJci7Uu832DMDRXTBhxUWUeit#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(205, '6401632164394572', 'cs_live_a1xYoTKoFI68C2KBaB5vGhD5WroYvxGw1fOOOIo1WS8fTj50oqjrK3LGuB', 25, '2021-09-20 18:59:54', NULL, 50, 'USD', 100, 5000, 5000, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', 'pi_3JbriYGQbVPqJtjT0uOFC252', 'unpaid', 'https://checkout.stripe.com/pay/cs_live_a1xYoTKoFI68C2KBaB5vGhD5WroYvxGw1fOOOIo1WS8fTj50oqjrK3LGuB#fidkdWxOYHwnPyd1blppbHNgWjA0T05fPVdCVGdTVXRPcW9RXTVvVzNGPXFkdVN2RGNrXHNfdmtgVFBNdU89YHFhXDVffEgxM0M9fWBAamp1PW5HMmJ9UX88QGwzPHJhS1NKQzR9UUtPYjwwNTVifVdTMWxxdycpJ2N3amhWYHdzYHcnP3F3cGApJ2lkfGpwcVF8dWAnPyd2bGtiaWBabHFgaCcpJ2BrZGdpYFVpZGZgbWppYWB3dic%2FcXdwYHgl', 'Processing', NULL, 'Credit'),
(206, '8901632485260173', 'PAYID-MFG37DI430933536L2968606', 25, '2021-09-24 12:07:40', '2021-09-24 16:07:41', 1, 'USD', 1, 1, 1, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.paypal.com/v1/payments/payment/PAYID-MFG37DI430933536L2968606/execute', 'Processing', NULL, 'Credit'),
(207, '4921632545779225', 'PAYID-MFHKX5A5U839674EY035110J', 42, '2021-09-25 04:56:19', '2021-09-25 04:58:40', 10, 'USD', 1, 10, 10, 'GEEFTO365378', 'BXRTYDCK4AKHN', 'aishaayusuf@yahoo.com', NULL, 'approved', 'https://api.paypal.com/v1/payments/sale/1Y079261AG045704W/refund', 'Completed', 'Wallet Funds Added', 'Credit'),
(208, 'fees_1632545920328', NULL, 42, '2021-09-25 04:58:40', '2021-09-25 04:58:40', -0.36, 'USD', 1, -0.36, -0.36, 'GEEFTO365378', NULL, 'aishaayusuf@yahoo.com', NULL, NULL, NULL, 'Completed', 'Transaction Charges for 4921632545779225', 'Debit'),
(209, '7361634271756865', NULL, 38, '2021-10-15 04:22:36', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO466813', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(210, '9091634271784775', NULL, 38, '2021-10-15 04:23:04', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO466813', NULL, 'techforhumanity@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(211, '2741634293844424', NULL, 25, '2021-10-15 10:30:44', NULL, 50, 'USD', 1, NULL, NULL, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(212, '7731634295062402', NULL, 25, '2021-10-15 10:51:02', NULL, 100, 'USD', 1, NULL, NULL, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(213, '8001634295495408', 'PAYID-MFUV5SA4EC06104PL122593B', 25, '2021-10-15 10:58:15', '2021-10-15 14:58:16', 100, 'USD', 1, 100, 100, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUV5SA4EC06104PL122593B/execute', 'Processing', NULL, 'Credit'),
(214, '5881634295600337', NULL, 25, '2021-10-15 11:00:00', NULL, 100, 'USD', 1, NULL, NULL, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(215, '1101634297357525', 'PAYID-MFUWMEA5RE310922W265383C', 25, '2021-10-15 11:29:17', '2021-10-15 15:29:20', 50, 'USD', 1, 50, 50, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUWMEA5RE310922W265383C/execute', 'Processing', NULL, 'Credit');
INSERT INTO `wallet_transactions` (`id`, `transaction_id`, `checkout_session_id`, `user_id`, `created_at`, `updated_at`, `amount`, `currency`, `multiplier`, `amount_subtotal`, `amount_total`, `ewallet_id`, `customer_id`, `customer_email`, `payment_intent_id`, `payment_status`, `url`, `transaction_status`, `description`, `transaction_type`) VALUES
(216, '4141634298076377', 'PAYID-MFUWRXI4SK93154GE589044P', 25, '2021-10-15 11:41:16', '2021-10-15 15:41:17', 50, 'USD', 1, 50, 50, 'GEEFTO466813', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUWRXI4SK93154GE589044P/execute', 'Processing', NULL, 'Credit'),
(217, '1821634298578566', 'PAYID-MFUWVUY47S712653N504792A', 38, '2021-10-15 11:49:38', '2021-10-15 15:49:39', 50, 'USD', 1, 50, 50, 'GEEFTO466813', NULL, 'techforhumanity@gmail.com', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUWVUY47S712653N504792A/execute', 'Processing', NULL, 'Credit'),
(218, '3741634304405638', NULL, 6, '2021-10-15 13:26:45', NULL, 50, 'BMD', 1, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(219, '7271634304657700', NULL, 6, '2021-10-15 13:30:57', NULL, 50, 'BMD', 1, NULL, NULL, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Credit'),
(220, '9871634304676670', 'PAYID-MFUYFJI0E382718T53726111', 6, '2021-10-15 13:31:16', '2021-10-15 17:31:17', 100, 'USD', 1, 100, 100, 'ewallet_b43aed61d43f74d82b022422cfa26e22', NULL, 'nash81@gmail.com', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUYFJI0E382718T53726111/execute', 'Processing', NULL, 'Credit'),
(221, '6481634308083664', 'PAYID-MFUY75A4CP22632MS797562E', 25, '2021-10-15 14:28:03', '2021-10-15 18:28:04', 50, 'USD', 1, 50, 50, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFUY75A4CP22632MS797562E/execute', 'Processing', NULL, 'Credit'),
(222, '8071634354149728', 'PAYID-MFVEHZQ7MA17116JL549622U', 25, '2021-10-16 03:15:49', '2021-10-16 07:15:49', 200, 'USD', 1, 200, 200, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFVEHZQ7MA17116JL549622U/execute', 'Processing', NULL, 'Credit'),
(223, '9021634354493437', 'PAYID-MFVEKPQ2VD94872X5164473M', 25, '2021-10-16 03:21:33', '2021-10-16 07:21:34', 100, 'USD', 1, 100, 100, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'created', 'https://api.sandbox.paypal.com/v1/payments/payment/PAYID-MFVEKPQ2VD94872X5164473M/execute', 'Processing', NULL, 'Credit'),
(224, '8961634354800732', 'PAYID-MFVEM4I0NH11030BX855415P', 25, '2021-10-16 03:26:40', '2021-10-16 03:26:53', 100, 'USD', 1, 100, 100, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', 'DYQ8GUTYSCKZC', 'business2@xenio.in', NULL, 'approved', 'https://api.sandbox.paypal.com/v1/payments/sale/70345654YB210853J/refund', 'Completed', 'Wallet Funds Added', 'Credit'),
(225, 'fees_1634354813471', NULL, 25, '2021-10-16 03:26:53', '2021-10-16 03:26:53', -3.6, 'USD', 1, -3.6, -3.6, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, 'Completed', 'Transaction Charges for 8961634354800732', 'Debit'),
(226, '9101634354937873', NULL, 25, '2021-10-16 03:28:57', NULL, -1112.95, 'USD', 100, NULL, NULL, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, NULL, NULL, 'Processing', 'Airtime Topup for 9101634354937873', 'Debit'),
(227, '2481634355017960', '21279', 25, '2021-10-16 03:30:17', '2021-10-16 03:30:18', -74, 'USD', 100, 7400, 7400, 'ewallet_712965cbc2bdac303dfbfd322eaf183f', NULL, 'business2@xenio.in', NULL, 'recharged', '', 'Completed', 'Airtime Topup for 2481634355017960', 'Debit'),
(228, '9321634392954213', 'PAYID-MFVNW7A37B68875GY7479402', 159, '2021-10-16 14:02:34', '2021-10-16 14:02:56', 200, 'USD', 1, 200, 200, 'XENIO574328', 'DYQ8GUTYSCKZC', 'nash81@xenio.in', NULL, 'approved', 'https://api.sandbox.paypal.com/v1/payments/sale/5YJ908058X543505R/refund', 'Completed', 'Wallet Funds Added', 'Credit'),
(229, 'fees_1634392976603', NULL, 159, '2021-10-16 14:02:56', '2021-10-16 14:02:56', -7.2, 'USD', 1, -7.2, -7.2, 'XENIO574328', NULL, 'nash81@xenio.in', NULL, NULL, NULL, 'Completed', 'Transaction Charges for 9321634392954213', 'Debit');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `apto_card`
--
ALTER TABLE `apto_card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`ewallet_id`);

--
-- Índices para tabela `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `blog_category`
--
ALTER TABLE `blog_category`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `business`
--
ALTER TABLE `business`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `business_category`
--
ALTER TABLE `business_category`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `configuration`
--
ALTER TABLE `configuration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `variable_name` (`variable_name`);

--
-- Índices para tabela `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Índices para tabela `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `google_fonts`
--
ALTER TABLE `google_fonts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `invoice_payment_record`
--
ALTER TABLE `invoice_payment_record`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `invoice_taxes`
--
ALTER TABLE `invoice_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `lang_values`
--
ALTER TABLE `lang_values`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `master_config`
--
ALTER TABLE `master_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `field_name` (`field_name`),
  ADD UNIQUE KEY `description` (`description`);

--
-- Índices para tabela `master_group`
--
ALTER TABLE `master_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_name` (`group_name`);

--
-- Índices para tabela `master_wallet_balance`
--
ALTER TABLE `master_wallet_balance`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `meeting_schedule`
--
ALTER TABLE `meeting_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `myreferal`
--
ALTER TABLE `myreferal`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `package_features`
--
ALTER TABLE `package_features`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `paylink`
--
ALTER TABLE `paylink`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `payment_advance`
--
ALTER TABLE `payment_advance`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `payment_records`
--
ALTER TABLE `payment_records`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `product_services`
--
ALTER TABLE `product_services`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `product_tax`
--
ALTER TABLE `product_tax`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `referal`
--
ALTER TABLE `referal`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `site_contacts`
--
ALTER TABLE `site_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `store_products`
--
ALTER TABLE `store_products`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tax_type`
--
ALTER TABLE `tax_type`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `time_zone`
--
ALTER TABLE `time_zone`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_zone_name` (`name`);

--
-- Índices para tabela `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `kuda_reference_id` (`kuda_reference_id`,`kuda_account_number`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_role`
--
ALTER TABLE `users_role`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_role_feature`
--
ALTER TABLE `users_role_feature`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_role_feature_assign`
--
ALTER TABLE `users_role_feature_assign`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `user_kyc`
--
ALTER TABLE `user_kyc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Índices para tabela `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `virtual_account_customer`
--
ALTER TABLE `virtual_account_customer`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `apto_card`
--
ALTER TABLE `apto_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de tabela `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `blog_category`
--
ALTER TABLE `blog_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `business`
--
ALTER TABLE `business`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `business_category`
--
ALTER TABLE `business_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `configuration`
--
ALTER TABLE `configuration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de tabela `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT de tabela `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `google_fonts`
--
ALTER TABLE `google_fonts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `invoice_payment_record`
--
ALTER TABLE `invoice_payment_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `invoice_taxes`
--
ALTER TABLE `invoice_taxes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `language`
--
ALTER TABLE `language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `lang_values`
--
ALTER TABLE `lang_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=715;

--
-- AUTO_INCREMENT de tabela `master_config`
--
ALTER TABLE `master_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de tabela `master_group`
--
ALTER TABLE `master_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `master_wallet_balance`
--
ALTER TABLE `master_wallet_balance`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `meeting_schedule`
--
ALTER TABLE `meeting_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `myreferal`
--
ALTER TABLE `myreferal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT de tabela `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de tabela `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `package_features`
--
ALTER TABLE `package_features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `paylink`
--
ALTER TABLE `paylink`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `payment_advance`
--
ALTER TABLE `payment_advance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `payment_records`
--
ALTER TABLE `payment_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `product_services`
--
ALTER TABLE `product_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `product_tax`
--
ALTER TABLE `product_tax`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `rates`
--
ALTER TABLE `rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT de tabela `referal`
--
ALTER TABLE `referal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de tabela `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
